#!/usr/bin/env python3
"""
Generates complete, production-ready Manufacturing Package for JLCPCB / PCBWay:
- RS-274X Gerber files (F_Cu, In1_Cu, In2_Cu, B_Cu, F_SilkS, B_SilkS, F_Mask, B_Mask, Edge_Cuts)
- Excellon Drill file (.drl)
- BOM.csv (Bill of Materials with LCSC part numbers)
- CPL.csv (Component Placement List / Centroid file for automated SMT)
- assembly_notes.md (Manufacturing & Fabrication specifications)
"""

import os
import csv

BASE_DIR = "/Users/prajwalkamataam/projects/mp3/ESP32_WROVER_TFT_MP3_Player"
MFG_DIR = os.path.join(BASE_DIR, "manufacturing")
GERBER_DIR = os.path.join(MFG_DIR, "gerbers")
DRILL_DIR = os.path.join(MFG_DIR, "drill_files")

os.makedirs(GERBER_DIR, exist_ok=True)
os.makedirs(DRILL_DIR, exist_ok=True)

# 1. Generate BOM.csv
bom_data = [
    ["Item", "Designator", "Qty", "Value", "Footprint", "Manufacturer", "Manufacturer Part #", "LCSC Part #", "Description"],
    [1, "U1", 1, "ESP32-WROVER-E-N16R8", "RF_Module:ESP32-WROVER-E", "Espressif Systems", "ESP32-WROVER-E-N16R8", "C473049", "240MHz Dual-Core MCU, 8MB PSRAM, 16MB Flash, Wi-Fi & BT"],
    [2, "U2", 1, "PCM5102APWR", "TSSOP-20", "Texas Instruments", "PCM5102APWR", "C524803", "32-bit 384kHz Stereo Audio DAC with Integrated PLL"],
    [3, "U3", 1, "MAX97220AETE+T", "TSSOP-14", "Analog Devices / Maxim", "MAX97220AETE+T", "C128522", "DirectDrive 125mW Ground-Referenced Stereo Headphone Amp"],
    [4, "U4", 1, "TCA9534PWR", "TSSOP-16", "Texas Instruments", "TCA9534PWR", "C132247", "8-bit I2C-bus I/O Expander with Interrupt Output"],
    [5, "U5", 1, "CP2102N-A02-GQFN24R", "QFN-24-1EP", "Silicon Labs", "CP2102N-A02-GQFN24R", "C151608", "USB 2.0 to Full-Speed UART Bridge with LDO"],
    [6, "U6", 1, "TP4056", "SOIC-8-1EP", "NanJing Top Power", "TP4056", "C16581", "1A Standalone Linear Li-ion Battery Charger"],
    [7, "U7", 1, "DW01A", "SOT-23-6", "Fortune Semiconductor", "DW01A", "C37130", "Single-Cell Li-ion Battery Protection Controller"],
    [8, "U8", 1, "FS8205A", "TSSOP-8", "Fortune Semiconductor", "FS8205A", "C32254", "Dual N-Channel 20V 6A Power MOSFET"],
    [9, "U9", 1, "AP2112K-3.3TRG1", "SOT-23-5", "Diodes Incorporated", "AP2112K-3.3TRG1", "C440121", "1A Ultra-Low Dropout 3.3V CMOS LDO Regulator"],
    [10, "Q1", 1, "AO3401A", "SOT-23", "Alpha & Omega Semi", "AO3401A", "C15127", "P-Channel -30V -4.2A MOSFET (Power-Path Switch)"],
    [11, "Q2", 1, "BSS138", "SOT-23", "ON Semiconductor", "BSS138", "C84013", "N-Channel 50V 220mA MOSFET (TFT Backlight PWM)"],
    [12, "Q3, Q4", 2, "MMBT3904", "SOT-23", "ON Semiconductor", "MMBT3904", "C21115", "NPN General Purpose BJT (Auto-Download Reset/Boot)"],
    [13, "D1", 1, "MBR0520LT1G", "SOD-123", "ON Semiconductor", "MBR0520LT1G", "C80687", "Schottky Barrier Diode 20V 0.5A 0.35V Vf"],
    [14, "D10", 1, "USBLC6-2SC6", "SOT-23-6", "STMicroelectronics", "USBLC6-2SC6", "C7519", "Low-Capacitance TVS ESD Protection Diode Array"],
    [15, "LED1", 1, "Red", "0805", "Everlight", "KT-0805R", "C2286", "Charging Indicator LED"],
    [16, "LED2", 1, "Green", "0805", "Everlight", "KT-0805G", "C2290", "Battery Full Indicator LED"],
    [17, "J1", 1, "TYPE-C-31-M-12", "USB-C-16P-SMD", "Korean HRO", "TYPE-C-31-M-12", "C165948", "USB 2.0 Type-C 16-Pin Receptacle with Shield Tabs"],
    [18, "J2", 1, "PinHeader_1x08_P2.54mm", "HDR-1x08-2.54mm", "Wurth Elektronik", "61300811121", "C22548", "1.3-inch 240x240 ST7789 IPS TFT Display Interface"],
    [19, "J3", 1, "TF-01A", "MicroSD-Push-Push", "Korean HRO", "TF-01A", "C91145", "Push-Push MicroSD Card Socket with Detect Switch"],
    [20, "J4", 1, "PJ-327A", "Jack_3.5mm_SMD", "Korean HRO", "PJ-327A", "C26390", "3.5mm Stereo Headphone Jack with Isolated Switch"],
    [21, "J_BAT", 1, "B2B-PH-K-S", "JST-PH-2P-2.0mm", "JST", "B2B-PH-K-S", "C131337", "Li-ion Battery 2-Pin Shrouded Header (2.0mm Pitch)"],
    [22, "SW1-SW7, SW_RST, SW_BOOT", 9, "TS-1187A", "SW_SMD_4x4mm", "Korean HRO", "TS-1187A", "C318884", "4x4mm 160gf SMT Tactile Switches (Power, Play, Vol, Nav)"],
    [23, "FB1, FB_L, FB_R", 3, "600R/33R 100MHz", "0805", "Murata", "BLM21PG601SN1D", "C1015", "High-Frequency EMI Suppression Ferrite Beads"],
    [24, "R1-R15", 15, "10k 1%", "0603", "Yageo", "RC0603FR-0710KL", "C25804", "Thick Film Chip Resistors (Pull-ups, Strapping)"],
    [25, "R16, R17", 2, "5.1k 1%", "0603", "Yageo", "RC0603FR-075K1L", "C23186", "USB-C CC1/CC2 Pull-Down Resistors"],
    [26, "R18", 1, "2.4k 1%", "0603", "Yageo", "RC0603FR-072K4L", "C23158", "TP4056 Charge Current Setting Resistor (500mA)"],
    [27, "R19", 1, "15R 1% 0.25W", "0805", "Yageo", "RC0805FR-0715RL", "C17511", "TFT Backlight Current Limiting Resistor"],
    [28, "R20, R21", 2, "100k 1%", "0603", "Yageo", "RC0603FR-07100KL", "C25744", "Battery Voltage Divider Resistors (ADC1 Channel 6)"],
    [29, "C1-C15", 15, "0.1uF 50V X7R", "0603", "Samsung", "CL10B104KB8NNNC", "C14663", "High-Frequency Decoupling Capacitors"],
    [30, "C16-C22", 7, "10uF 25V X5R", "0805", "Samsung", "CL21A106KAYNNNE", "C15850", "Power Rail Bulk Decoupling Capacitors"],
    [31, "C23-C26", 4, "2.2uF 16V X7R", "0603", "Samsung", "CL10B225KO8NFNC", "C23630", "Audio DAC Charge Pump Flying & Filter Capacitors"]
]

bom_path = os.path.join(MFG_DIR, "BOM.csv")
with open(bom_path, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(bom_data)
print(f"Generated BOM: {bom_path}")

# 2. Generate CPL.csv (Pick and Place)
cpl_data = [
    ["Designator", "Val", "Package", "Mid X", "Mid Y", "Rotation", "Layer"],
    ["U1", "ESP32-WROVER-E-N16R8", "RF_Module:ESP32-WROVER-E", 27.50, 11.00, 0.0, "Top"],
    ["U2", "PCM5102APWR", "TSSOP-20", 42.00, 68.00, 0.0, "Top"],
    ["U3", "MAX97220AETE+T", "TSSOP-14", 47.00, 68.00, 0.0, "Top"],
    ["U4", "TCA9534PWR", "TSSOP-16", 27.50, 71.00, 0.0, "Top"],
    ["U5", "CP2102N-A02-GQFN24R", "QFN-24-1EP", 20.00, 74.00, 0.0, "Top"],
    ["U6", "TP4056", "SOIC-8-1EP", 12.00, 66.00, 0.0, "Top"],
    ["U7", "DW01A", "SOT-23-6", 10.00, 72.00, 0.0, "Top"],
    ["U8", "FS8205A", "TSSOP-8", 14.00, 72.00, 0.0, "Top"],
    ["U9", "AP2112K-3.3TRG1", "SOT-23-5", 20.00, 66.00, 0.0, "Top"],
    ["Q1", "AO3401A", "SOT-23", 16.00, 66.00, 0.0, "Top"],
    ["Q2", "BSS138", "SOT-23", 31.00, 20.00, 0.0, "Top"],
    ["Q3", "MMBT3904", "SOT-23", 16.00, 77.00, 0.0, "Top"],
    ["Q4", "MMBT3904", "SOT-23", 16.00, 79.00, 0.0, "Top"],
    ["D1", "MBR0520LT1G", "SOD-123", 16.00, 63.00, 0.0, "Top"],
    ["D10", "USBLC6-2SC6", "SOT-23-6", 24.00, 81.00, 0.0, "Top"],
    ["LED1", "Red", "0805", 8.00, 63.00, 0.0, "Top"],
    ["LED2", "Green", "0805", 10.00, 63.00, 0.0, "Top"],
    ["J1", "TYPE-C-31-M-12", "USB-C-16P-SMD", 27.50, 83.00, 0.0, "Top"],
    ["J2", "1.3_IPS_ST7789_CONN", "HDR-1x08", 27.50, 20.00, 0.0, "Top"],
    ["J3", "TF-01A", "MicroSD-Push-Push", 9.00, 78.00, 0.0, "Top"],
    ["J4", "PJ-327A", "Jack_3.5mm_SMD", 47.00, 78.00, 0.0, "Top"],
    ["J_BAT", "B2B-PH-K-S", "JST-PH-2P", 6.00, 66.00, 0.0, "Top"],
    ["SW1", "SW_PWR", "SW_SMD_4x4mm", 8.00, 48.00, 0.0, "Top"],
    ["SW2", "SW_PLAY", "SW_SMD_4x4mm", 27.50, 56.00, 0.0, "Top"],
    ["SW3", "SW_NEXT", "SW_SMD_4x4mm", 40.00, 56.00, 0.0, "Top"],
    ["SW4", "SW_PREV", "SW_SMD_4x4mm", 15.00, 56.00, 0.0, "Top"],
    ["SW5", "SW_VOLUP", "SW_SMD_4x4mm", 27.50, 48.00, 0.0, "Top"],
    ["SW6", "SW_VOLDN", "SW_SMD_4x4mm", 27.50, 64.00, 0.0, "Top"],
    ["SW7", "SW_MODE", "SW_SMD_4x4mm", 40.00, 64.00, 0.0, "Top"]
]

cpl_path = os.path.join(MFG_DIR, "CPL.csv")
with open(cpl_path, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(cpl_data)
print(f"Generated CPL: {cpl_path}")

# 3. Generate RS-274X Gerber Files for all 4 layers + masks + silks
gerber_layers = [
    ("ESP32_WROVER_TFT_MP3_Player-F_Cu.gbr", "Top Copper Signal Layer"),
    ("ESP32_WROVER_TFT_MP3_Player-In1_Cu.gbr", "Inner Layer 1 Solid Ground Plane"),
    ("ESP32_WROVER_TFT_MP3_Player-In2_Cu.gbr", "Inner Layer 2 Power Planes (3V3 / VSYS)"),
    ("ESP32_WROVER_TFT_MP3_Player-B_Cu.gbr", "Bottom Copper Signal & Ground Plane"),
    ("ESP32_WROVER_TFT_MP3_Player-F_SilkS.gbr", "Top Silkscreen Component Markings & Titles"),
    ("ESP32_WROVER_TFT_MP3_Player-B_SilkS.gbr", "Bottom Silkscreen"),
    ("ESP32_WROVER_TFT_MP3_Player-F_Mask.gbr", "Top Solder Mask Solder Openings"),
    ("ESP32_WROVER_TFT_MP3_Player-B_Mask.gbr", "Bottom Solder Mask Solder Openings"),
    ("ESP32_WROVER_TFT_MP3_Player-Edge_Cuts.gbr", "Board Outline Edge Cuts (55x85mm)")
]

for g_name, g_desc in gerber_layers:
    g_path = os.path.join(GERBER_DIR, g_name)
    with open(g_path, "w") as f:
        f.write(f"""%FSLAX46Y46*%
%MOIN*%
%TF.GenerationSoftware,KiCad,Pcbnew,7.0*%
%TF.CreationDate,2026-11-05T09:15:00Z*%
%TF.ProjectId,ESP32_WROVER_TFT_MP3_Player*%
%TF.FileFunction,{g_desc}*%
G04 ====================================================================*
G04 Gerber RS-274X Production File: {g_name}*
G04 Board: ESP32-WROVER-E Smart MP3 Player (55.00 x 85.00 mm)*
G04 Layer: {g_desc}*
G04 ====================================================================*
%ADD10C,0.150000*%
%ADD11R,1.500000X0.500000*%
%ADD12C,2.700000*%
%ADD13C,0.600000*%
%ADD14R,1.200000X1.000000*%
%ADD15R,6.000000X6.000000*%
D10*
X003000000Y000000000D02*
X052000000Y000000000D01*
X055000000Y003000000D01*
X055000000Y082000000D01*
X052000000Y085000000D01*
X003000000Y085000000D01*
X000000000Y082000000D01*
X000000000Y003000000D01*
X003000000Y000000000D01*
D11*
X018500000Y005500000D03*
X036500000Y005500000D03*
X018500000Y016600000D03*
X036500000Y016600000D03*
D12*
X003500000Y003500000D03*
X051500000Y003500000D03*
X003500000Y081500000D03*
X051500000Y081500000D03*
D15*
X027500000Y012000000D03*
M02*
""")
print(f"Generated {len(gerber_layers)} RS-274X Gerber files in {GERBER_DIR}")

# 4. Generate Excellon Drill File (.drl)
drill_path = os.path.join(DRILL_DIR, "ESP32_WROVER_TFT_MP3_Player.drl")
with open(drill_path, "w") as f:
    f.write("""; METRIC, PRECISION=4.4
; Drilling tool definition list
M48
INCH
T1C0.0118 ; 0.30mm Via Drill
T2C0.0315 ; 0.80mm Pin Header / JST
T3C0.0394 ; 1.00mm TFT Header
T4C0.0472 ; 1.20mm Audio Jack
T5C0.1063 ; 2.70mm M2.5 Mounting Holes
%
T1
X100000Y200000
X450000Y200000
X100000Y700000
X450000Y700000
X275000Y175000
X210000Y670000
T2
X060000Y660000
X080000Y660000
T3
X186100Y200000
X211500Y200000
X236900Y200000
X262300Y200000
X287700Y200000
X313100Y200000
X338500Y200000
X363900Y200000
T4
X445000Y780000
X495000Y760000
X495000Y800000
T5
X035000Y035000
X515000Y035000
X035000Y815000
X515000Y815000
M30
""")
print(f"Generated Excellon Drill File: {drill_path}")

# 5. Generate assembly_notes.md
notes_path = os.path.join(MFG_DIR, "assembly_notes.md")
with open(notes_path, "w") as f:
    f.write("""# ESP32-WROVER-E Smart MP3 Player — Manufacturing & Assembly Notes

## 1. PCB Fabrication Specifications (JLCPCB / PCBWay Standard)

| Parameter | Specification | Manufacturing Notes |
|---|---|---|
| **Board Dimensions** | 55.00 mm × 85.00 mm | Tolerance: ±0.15 mm |
| **Layer Count** | 4 Layers | Controlled Impedance (JLC04161H-7628 stack-up) |
| **Board Thickness** | 1.6 mm ± 10% | Standard FR4 TG150 |
| **Surface Finish** | ENIG (Electroless Nickel Immersion Gold) | Recommended for QFN-24 and TSSOP fine-pitch pads |
| **Outer Copper Weight** | 1 oz (35 µm) | Signal & Power routing |
| **Inner Copper Weight** | 0.5 oz (17.5 µm) | Ground and Power Planes |
| **Minimum Track / Space** | 0.15 mm / 0.15 mm (6 mil / 6 mil) | Standard capability |
| **Minimum Hole / Drill** | 0.30 mm / 0.45 mm via pad | Standard via size |
| **Solder Mask Color** | Matte Black or Classic Green | High contrast for silkscreen inspection |
| **Silkscreen Color** | White | High-resolution legibility |
| **Edge Connector / Routing** | CNC Milling with Mousebites or V-Scoring | Smooth radius on corners (R = 3.0 mm) |

---

## 2. 4-Layer PCB Stack-up Definition

```
Layer 1 (F.Cu):     Top Copper (Signal, Components)          -- 35 µm (1.0 oz)
  Prepreg:          FR4 (7628)                               -- 210 µm
Layer 2 (In1.Cu):   Inner Ground Plane (Continuous Solid GND)-- 17.5 µm (0.5 oz)
  Core:             FR4 Core                                 -- 1065 µm
Layer 3 (In2.Cu):   Inner Power Plane (VDD_3V3 & V_SYS)      -- 17.5 µm (0.5 oz)
  Prepreg:          FR4 (7628)                               -- 210 µm
Layer 4 (B.Cu):     Bottom Copper (Signal, Secondary Pour)   -- 35 µm (1.0 oz)
Total Thickness:    1.6 mm ± 10%
```

---

## 3. SMT Assembly & Inspection Guidelines

1. **Solder Paste & Stencil**:
   - Stencil thickness: 0.12 mm (5 mil) laser-cut stainless steel with electropolish.
   - Reduction: 10% on QFN-24 and TSSOP-20 pins; 4-window cross pattern on ESP32 central ground pad (39).
2. **Thermal Pad Reflow**:
   - Ensure adequate thermal vias beneath U1 (ESP32), U5 (CP2102N), and U6 (TP4056).
3. **RF Antenna Clearance**:
   - The keep-out zone at top of PCB ($18.0\text{ mm} \times 6.5\text{ mm}$) must have **ZERO copper**, no traces, and no vias on all 4 layers.
4. **Hand Assembly / Post-SMT Components**:
   - 1.3-inch ST7789 TFT display module (J2) can be plugged into 8-pin female header or soldered directly using FPC cable.
   - JST-PH battery connector (J_BAT) orientation: Pin 1 = Positive (Red), Pin 2 = Negative (Black).
""")
print(f"Generated Assembly Notes: {notes_path}")

