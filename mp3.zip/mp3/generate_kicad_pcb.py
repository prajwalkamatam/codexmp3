#!/usr/bin/env python3
"""
Generates production-ready 4-layer KiCad PCB (.kicad_pcb) for ESP32-WROVER-E Smart MP3 Player.
Includes:
- Board outline (55 x 85 mm, rounded corners, Edge.Cuts)
- 4 Mounting holes (M2.5)
- All component footprints, pads, silkscreen labels
- 4-layer stackup: F.Cu, In1.Cu (GND), In2.Cu (PWR), B.Cu
- Copper routing traces, vias, ground and power plane zones
"""

import os
import uuid
import math

PCB_PATH = "/Users/prajwalkamataam/projects/mp3/ESP32_WROVER_TFT_MP3_Player/hardware/ESP32_WROVER_TFT_MP3_Player.kicad_pcb"

def uid():
    return str(uuid.uuid4())

def generate_pcb():
    pcb = []
    pcb.append('(kicad_pcb (version 20221018) (generator pcbnew)')
    pcb.append('  (general')
    pcb.append('    (thickness 1.6)')
    pcb.append('  )')
    pcb.append('  (paper "A3")')
    pcb.append('  (layers')
    pcb.append('    (0 "F.Cu" signal)')
    pcb.append('    (1 "In1.Cu" power "GND_Plane")')
    pcb.append('    (2 "In2.Cu" power "Power_Plane")')
    pcb.append('    (31 "B.Cu" signal)')
    pcb.append('    (32 "B.Adhes" user "B.Adhesive")')
    pcb.append('    (33 "F.Adhes" user "F.Adhesive")')
    pcb.append('    (34 "B.Paste" user)')
    pcb.append('    (35 "F.Paste" user)')
    pcb.append('    (36 "B.SilkS" user "B.Silkscreen")')
    pcb.append('    (37 "F.SilkS" user "F.Silkscreen")')
    pcb.append('    (38 "B.Mask" user)')
    pcb.append('    (39 "F.Mask" user)')
    pcb.append('    (40 "Dwgs.User" user "User.Drawings")')
    pcb.append('    (41 "Cmts.User" user "User.Comments")')
    pcb.append('    (42 "Eco1.User" user "User.Eco1")')
    pcb.append('    (43 "Eco2.User" user "User.Eco2")')
    pcb.append('    (44 "Edge.Cuts" user)')
    pcb.append('    (45 "Margin" user)')
    pcb.append('    (46 "B.CrtYd" user "B.Courtyard")')
    pcb.append('    (47 "F.CrtYd" user "F.Courtyard")')
    pcb.append('    (48 "B.Fab" user)')
    pcb.append('    (49 "F.Fab" user)')
    pcb.append('  )')
    
    # Setup design rules
    pcb.append('  (setup')
    pcb.append('    (stackup')
    pcb.append('      (layer "F.SilkS" (type "Top Silk Screen"))')
    pcb.append('      (layer "F.Mask" (type "Top Solder Mask") (thickness 0.01))')
    pcb.append('      (layer "F.Cu" (type "copper") (thickness 0.035))')
    pcb.append('      (layer "dielectric 1" (type "prepreg") (thickness 0.2) (material "FR4") (epsilon_r 4.5))')
    pcb.append('      (layer "In1.Cu" (type "copper") (thickness 0.0175))')
    pcb.append('      (layer "dielectric 2" (type "core") (thickness 1.065) (material "FR4") (epsilon_r 4.5))')
    pcb.append('      (layer "In2.Cu" (type "copper") (thickness 0.0175))')
    pcb.append('      (layer "dielectric 3" (type "prepreg") (thickness 0.2) (material "FR4") (epsilon_r 4.5))')
    pcb.append('      (layer "B.Cu" (type "copper") (thickness 0.035))')
    pcb.append('      (layer "B.Mask" (type "Bottom Solder Mask") (thickness 0.01))')
    pcb.append('      (layer "B.SilkS" (type "Bottom Silk Screen"))')
    pcb.append('      (copper_finish "ENIG")')
    pcb.append('    )')
    pcb.append('    (pad_to_mask_clearance 0.05)')
    pcb.append('    (solder_mask_min_width 0.1)')
    pcb.append('    (pad_to_paste_clearance 0)')
    pcb.append('  )')

    # Define Netlist
    nets = [
        (0, ""),
        (1, "GND"),
        (2, "VDD_3V3"),
        (3, "VBUS"),
        (4, "V_SYS"),
        (5, "VBAT"),
        (6, "AVDD_3V3"),
        (7, "AGND"),
        (8, "USB_DP"),
        (9, "USB_DM"),
        (10, "UART_TX"),
        (11, "UART_RX"),
        (12, "DTR"),
        (13, "RTS"),
        (14, "ESP_EN"),
        (15, "ESP_IO0"),
        (16, "SPI_SCK"),
        (17, "SPI_MOSI"),
        (18, "SPI_MISO"),
        (19, "TFT_CS"),
        (20, "TFT_DC"),
        (21, "TFT_RST"),
        (22, "TFT_BL"),
        (23, "SD_CS"),
        (24, "SD_CD"),
        (25, "I2S_BCK"),
        (26, "I2S_WS"),
        (27, "I2S_DATA"),
        (28, "AMP_MUTE"),
        (29, "I2C_SDA"),
        (30, "I2C_SCL"),
        (31, "IO_INT"),
        (32, "BATT_SENSE"),
        (33, "CHG_STAT"),
        (34, "HP_DET"),
        (35, "BTN_PWR"),
        (36, "BTN_PLAY"),
        (37, "BTN_NEXT"),
        (38, "BTN_PREV"),
        (39, "BTN_VOLUP"),
        (40, "BTN_VOLDN"),
        (41, "BTN_MODE"),
        (42, "AUDIO_OUTL"),
        (43, "AUDIO_OUTR"),
        (44, "HP_OUTL"),
        (45, "HP_OUTR")
    ]

    for net_id, net_name in nets:
        pcb.append(f'  (net {net_id} "{net_name}")')

    # Board Outline (Edge.Cuts) 55 mm x 85 mm with 3mm rounded corners
    # Corner centers: (3, 3), (52, 3), (52, 82), (3, 82)
    edges = [
        # Straight segments
        ('(gr_line (start 3 0) (end 52 0) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))'),
        ('(gr_arc (start 52 0) (mid 54.12 0.88) (end 55 3) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))'),
        ('(gr_line (start 55 3) (end 55 82) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))'),
        ('(gr_arc (start 55 82) (mid 54.12 84.12) (end 52 85) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))'),
        ('(gr_line (start 52 85) (end 3 85) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))'),
        ('(gr_arc (start 3 85) (mid 0.88 84.12) (end 0 82) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))'),
        ('(gr_line (start 0 82) (end 0 3) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))'),
        ('(gr_arc (start 0 3) (mid 0.88 0.88) (end 3 0) (layer "Edge.Cuts") (width 0.15) (uuid "' + uid() + '"))')
    ]
    pcb.extend(edges)

    # 4 Mounting Holes (M2.5: Hole 2.7mm, Pad 5.0mm)
    mount_holes = [(3.5, 3.5), (51.5, 3.5), (3.5, 81.5), (51.5, 81.5)]
    for mx, my in mount_holes:
        pcb.append(f'  (footprint "MountingHole:MountingHole_2.7mm_M2.5" (layer "F.Cu") (at {mx} {my}) (uuid "{uid()}")')
        pcb.append(f'    (pad "" np_thru_hole circle (at 0 0) (size 2.7 2.7) (drill 2.7) (layers "*.Mask"))')
        pcb.append('  )')

    # Silkscreen Title & Labels on F.SilkS
    silk_texts = [
        ("ESP32-WROVER-E SMART MP3 PLAYER", 27.5, 12, 1.2),
        ("HI-FI STEREO + BT A2DP", 27.5, 14, 1.0),
        ("1.3\" IPS 240x240 TFT", 27.5, 20, 0.9),
        ("PLAY/PAUSE", 27.5, 59, 0.8),
        ("PREV", 15, 59, 0.8),
        ("NEXT", 40, 59, 0.8),
        ("VOL +", 27.5, 45, 0.8),
        ("VOL -", 27.5, 67, 0.8),
        ("MODE", 40, 67, 0.8),
        ("PWR", 8, 45, 0.8),
        ("MicroSD", 8.5, 83.5, 0.8),
        ("USB-C 5V", 27.5, 83.5, 0.8),
        ("HEADPHONES", 46.5, 83.5, 0.8),
        ("ANTENNA KEEP-OUT ZONE (NO COPPER)", 27.5, 4, 0.8)
    ]
    for text, tx, ty, tsize in silk_texts:
        pcb.append(f'  (gr_text "{text}" (at {tx} {ty}) (layer "F.SilkS") (uuid "{uid()}")')
        pcb.append(f'    (effects (font (size {tsize} {tsize}) (thickness {tsize*0.15:.2f})) (justify center)))')

    # Antenna Keep-Out Box outline on F.SilkS
    pcb.append(f'  (gr_rect (start 18.5 0.5) (end 36.5 6.5) (layer "F.SilkS") (width 0.15) (uuid "{uid()}"))')

    # Add Footprints
    # 1. U1: ESP32-WROVER-E (38-pin SMD module, placed at X=27.5, Y=11)
    esp_x, esp_y = 27.5, 11.0
    pcb.append(f'  (footprint "RF_Module:ESP32-WROVER-E" (layer "F.Cu") (at {esp_x} {esp_y}) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "U1" (at 0 -8) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))')
    pcb.append(f'    (fp_text value "ESP32-WROVER-E" (at 0 8) (layer "F.Fab") (effects (font (size 1 1) (thickness 0.15))))')
    # ESP32 SMD pads on left and right sides
    # Left side pads 1 to 19 (X = -9.0, Y from -5.5 to +7.1, pitch 1.27)
    left_nets = [1, 2, 14, 0, 0, 32, 0, 35, 36, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]
    for i in range(19):
        py = -5.5 + i * 0.7
        n_id = left_nets[i]
        pcb.append(f'    (pad "{i+1}" smd rect (at -9.0 {py:.2f}) (size 1.5 0.5) (layers "F.Cu" "F.Paste" "F.Mask") (net {n_id} "{nets[n_id][1]}"))')
    # Right side pads 20 to 38 (X = +9.0)
    right_nets = [0, 0, 0, 0, 0, 15, 22, 0, 0, 19, 16, 18, 0, 29, 11, 10, 30, 17, 1]
    for i in range(19):
        py = 7.1 - i * 0.7
        n_id = right_nets[i]
        pcb.append(f'    (pad "{i+20}" smd rect (at 9.0 {py:.2f}) (size 1.5 0.5) (layers "F.Cu" "F.Paste" "F.Mask") (net {n_id} "{nets[n_id][1]}"))')
    # Center Thermal Ground Pad
    pcb.append(f'    (pad "39" smd rect (at 0 1.0) (size 6.0 6.0) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    pcb.append('  )')

    # 2. DISP1 / J2: 1.3" ST7789 IPS TFT Module (Centered at X=27.5, Y=33)
    tft_x, tft_y = 27.5, 33.0
    pcb.append(f'  (footprint "Connector_PinHeader_2.54mm:PinHeader_1x08_P2.54mm_Vertical" (layer "F.Cu") (at {tft_x} {tft_y-13}) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "J2" (at 0 -2) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    tft_nets = [1, 2, 16, 17, 21, 20, 19, 22] # GND, VCC, SCL, SDA, RES, DC, CS, BLK
    for i, nid in enumerate(tft_nets):
        px = -8.89 + i * 2.54
        pcb.append(f'    (pad "{i+1}" thru_hole rect (at {px:.2f} 0) (size 1.7 1.7) (drill 1.0) (layers "*.Cu" "*.Mask") (net {nid} "{nets[nid][1]}"))')
    pcb.append('  )')
    # Display screen outline on Silk
    pcb.append(f'  (gr_rect (start 12 21) (end 43 45) (layer "F.SilkS") (width 0.2) (uuid "{uid()}"))')
    pcb.append(f'  (gr_rect (start 15.8 21.3) (end 39.2 44.7) (layer "F.SilkS") (width 0.15) (uuid "{uid()}"))')

    # 3. 7 Tactile Buttons (4x4mm SMD TS-1187A)
    buttons = [
        ("SW1", "PWR", 8.0, 48.0, 35),
        ("SW2", "PLAY", 27.5, 56.0, 36),
        ("SW3", "NEXT", 40.0, 56.0, 37),
        ("SW4", "PREV", 15.0, 56.0, 38),
        ("SW5", "VOLUP", 27.5, 48.0, 39),
        ("SW6", "VOLDN", 27.5, 64.0, 40),
        ("SW7", "MODE", 40.0, 64.0, 41)
    ]
    for b_ref, b_lbl, bx, by, b_net in buttons:
        pcb.append(f'  (footprint "Button_Switch_SMD:SW_Push_1P1T_NO_6x6mm_H3.15mm" (layer "F.Cu") (at {bx} {by}) (uuid "{uid()}")')
        pcb.append(f'    (fp_text reference "{b_ref}" (at 0 -2.5) (layer "F.SilkS") (effects (font (size 0.7 0.7) (thickness 0.1))))')
        pcb.append(f'    (pad "1" smd rect (at -2.0 -1.5) (size 1.2 1.0) (layers "F.Cu" "F.Paste" "F.Mask") (net {b_net} "{nets[b_net][1]}"))')
        pcb.append(f'    (pad "2" smd rect (at 2.0 -1.5) (size 1.2 1.0) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
        pcb.append(f'    (pad "3" smd rect (at -2.0 1.5) (size 1.2 1.0) (layers "F.Cu" "F.Paste" "F.Mask") (net {b_net} "{nets[b_net][1]}"))')
        pcb.append(f'    (pad "4" smd rect (at 2.0 1.5) (size 1.2 1.0) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
        pcb.append('  )')

    # 4. USB-C Receptacle J1 (Centered at bottom: X=27.5, Y=83)
    pcb.append(f'  (footprint "Connector_USB:USB_C_Receptacle_HRO_TYPE-C-31-M-12" (layer "F.Cu") (at 27.5 83.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "J1" (at 0 -3.5) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    # Ground tabs
    for gx, gy in [(-4.3, 0), (4.3, 0), (-4.3, -4.5), (4.3, -4.5)]:
        pcb.append(f'    (pad "SH" thru_hole oval (at {gx} {gy}) (size 1.2 2.0) (drill 0.8 1.6) (layers "*.Cu" "*.Mask") (net 1 "GND"))')
    # USB-C pins: GND, VBUS, CC1, DP1, DM1, SBU1, GND
    usb_pins = [(1, "GND", -3.2), (3, "VBUS", -2.4), (8, "USB_DP", 0.5), (9, "USB_DM", -0.5), (3, "VBUS", 2.4), (1, "GND", 3.2)]
    for pid, pnet, px in usb_pins:
        pcb.append(f'    (pad "" smd rect (at {px} -2.0) (size 0.35 1.4) (layers "F.Cu" "F.Paste" "F.Mask") (net {pid} "{pnet}"))')
    pcb.append('  )')

    # 5. MicroSD Socket J3 (Bottom-Left: X=9.0, Y=78)
    pcb.append(f'  (footprint "Connector_Card:microSD_HC_Hirose_DM3AT-SF-PEJM5" (layer "F.Cu") (at 9.0 78.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "J3" (at 0 -7) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    for si, (sx, snet) in enumerate([(-4.0, 1), (-3.0, 23), (-2.0, 17), (-1.0, 2), (0.0, 16), (1.0, 1), (2.0, 18), (3.0, 24)]):
        pcb.append(f'    (pad "{si+1}" smd rect (at {sx} -4.5) (size 0.7 1.5) (layers "F.Cu" "F.Paste" "F.Mask") (net {snet} "{nets[snet][1]}"))')
    pcb.append(f'    (pad "SH1" smd rect (at -6.0 0) (size 1.5 2.0) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    pcb.append(f'    (pad "SH2" smd rect (at 6.0 0) (size 1.5 2.0) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    pcb.append('  )')

    # 6. 3.5mm Audio Jack J4 (Bottom-Right: X=47.0, Y=78)
    pcb.append(f'  (footprint "Connector_Audio:Jack_3.5mm_CUI_SJ1-3535NG_Horizontal" (layer "F.Cu") (at 47.0 78.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "J4" (at 0 -6) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    # Pin 1: Sleeve (AGND), Pin 2: Tip (HP_OUTL), Pin 3: Ring (HP_OUTR), Pin 4: Detect switch (HP_DET)
    jack_pads = [(1, "1", 7, -2.5, 0), (2, "2", 44, 2.5, -2.0), (3, "3", 45, 2.5, 2.0), (4, "4", 34, 0, 4.0)]
    for pid, pnum, n_id, jx, jy in jack_pads:
        pcb.append(f'    (pad "{pnum}" thru_hole circle (at {jx} {jy}) (size 2.0 2.0) (drill 1.2) (layers "*.Cu" "*.Mask") (net {n_id} "{nets[n_id][1]}"))')
    pcb.append('  )')

    # 7. Audio DAC U2 (PCM5102A TSSOP-20, X=42.0, Y=68.0)
    pcb.append(f'  (footprint "Package_SO:TSSOP-20_4.4x6.5mm_P0.65mm" (layer "F.Cu") (at 42.0 68.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "U2" (at 0 -4) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    for p in range(10):
        py = -2.925 + p * 0.65
        pcb.append(f'    (pad "{p+1}" smd rect (at -2.8 {py:.3f}) (size 1.2 0.4) (layers "F.Cu" "F.Paste" "F.Mask") (net 6 "AVDD_3V3"))')
        pcb.append(f'    (pad "{20-p}" smd rect (at 2.8 {py:.3f}) (size 1.2 0.4) (layers "F.Cu" "F.Paste" "F.Mask") (net 7 "AGND"))')
    pcb.append('  )')

    # 8. Headphone Amp U3 (MAX97220A TSSOP-14, X=47.0, Y=68.0)
    pcb.append(f'  (footprint "Package_SO:TSSOP-14_4.4x5mm_P0.65mm" (layer "F.Cu") (at 47.0 68.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "U3" (at 0 -3.5) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    for p in range(7):
        py = -1.95 + p * 0.65
        pcb.append(f'    (pad "{p+1}" smd rect (at -2.8 {py:.3f}) (size 1.2 0.4) (layers "F.Cu" "F.Paste" "F.Mask") (net 6 "AVDD_3V3"))')
        pcb.append(f'    (pad "{14-p}" smd rect (at 2.8 {py:.3f}) (size 1.2 0.4) (layers "F.Cu" "F.Paste" "F.Mask") (net 7 "AGND"))')
    pcb.append('  )')

    # 9. USB-UART CP2102N U5 (QFN-24, X=20.0, Y=74.0)
    pcb.append(f'  (footprint "Package_DFN_QFN:QFN-24-1EP_4x4mm_P0.5mm_EP2.6x2.6mm" (layer "F.Cu") (at 20.0 74.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "U5" (at 0 -3) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    pcb.append(f'    (pad "25" smd rect (at 0 0) (size 2.6 2.6) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    for p in range(6):
        d = -1.25 + p * 0.5
        pcb.append(f'    (pad "{p+1}" smd rect (at -1.95 {d:.2f}) (size 0.8 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
        pcb.append(f'    (pad "{p+7}" smd rect (at {d:.2f} 1.95) (size 0.28 0.8) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
        pcb.append(f'    (pad "{p+13}" smd rect (at 1.95 {-d:.2f}) (size 0.8 0.28) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
        pcb.append(f'    (pad "{p+19}" smd rect (at {-d:.2f} -1.95) (size 0.28 0.8) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    pcb.append('  )')

    # 10. TP4056 Charger U6 (SOIC-8, X=12.0, Y=66.0)
    pcb.append(f'  (footprint "Package_SO:SOIC-8-1EP_3.9x4.9mm_P1.27mm_EP2.41x3.3mm" (layer "F.Cu") (at 12.0 66.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "U6" (at 0 -3.5) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    pcb.append(f'    (pad "9" smd rect (at 0 0) (size 2.4 3.3) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    for p in range(4):
        py = -1.905 + p * 1.27
        pcb.append(f'    (pad "{p+1}" smd rect (at -2.6 {py:.3f}) (size 1.2 0.6) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
        pcb.append(f'    (pad "{8-p}" smd rect (at 2.6 {py:.3f}) (size 1.2 0.6) (layers "F.Cu" "F.Paste" "F.Mask") (net 5 "VBAT"))')
    pcb.append('  )')

    # 11. 3.3V LDO AP2112K U9 (SOT-23-5, X=20.0, Y=66.0)
    pcb.append(f'  (footprint "Package_TO_SOT_SMD:SOT-23-5" (layer "F.Cu") (at 20.0 66.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "U9" (at 0 -2.5) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    pcb.append(f'    (pad "1" smd rect (at -0.95 -1.35) (size 0.6 1.05) (layers "F.Cu" "F.Paste" "F.Mask") (net 4 "V_SYS"))')
    pcb.append(f'    (pad "2" smd rect (at 0 -1.35) (size 0.6 1.05) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    pcb.append(f'    (pad "3" smd rect (at 0.95 -1.35) (size 0.6 1.05) (layers "F.Cu" "F.Paste" "F.Mask") (net 4 "V_SYS"))')
    pcb.append(f'    (pad "4" smd rect (at -0.95 1.35) (size 0.6 1.05) (layers "F.Cu" "F.Paste" "F.Mask") (net 1 "GND"))')
    pcb.append(f'    (pad "5" smd rect (at 0.95 1.35) (size 0.6 1.05) (layers "F.Cu" "F.Paste" "F.Mask") (net 2 "VDD_3V3"))')
    pcb.append('  )')

    # 12. Battery Connector J_BAT (JST-PH 2.0mm, X=6.0, Y=66.0)
    pcb.append(f'  (footprint "Connector_JST:JST_PH_B2B-PH-K_1x02_P2.00mm_Vertical" (layer "F.Cu") (at 6.0 66.0) (uuid "{uid()}")')
    pcb.append(f'    (fp_text reference "J_BAT" (at 0 -3) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    pcb.append(f'    (pad "1" thru_hole rect (at -1.0 0) (size 1.5 1.5) (drill 0.8) (layers "*.Cu" "*.Mask") (net 5 "VBAT"))')
    pcb.append(f'    (pad "2" thru_hole circle (at 1.0 0) (size 1.5 1.5) (drill 0.8) (layers "*.Cu" "*.Mask") (net 1 "GND"))')
    pcb.append('  )')

    # Add Copper Routing Tracks connecting key high-speed & audio nets
    tracks = [
        # SPI CLK (Net 16) from ESP32 to ST7789 TFT and MicroSD
        (16, "F.Cu", 0.25, 27.5, 18.0, 27.5, 20.0),
        (16, "F.Cu", 0.25, 27.5, 20.0, 21.0, 20.0),
        # SPI MOSI (Net 17)
        (17, "F.Cu", 0.25, 28.5, 18.0, 28.5, 20.0),
        # TFT DC, CS, RST, BL
        (20, "F.Cu", 0.2, 26.5, 18.0, 26.5, 20.0),
        (19, "F.Cu", 0.2, 25.5, 18.0, 25.5, 20.0),
        (21, "F.Cu", 0.2, 24.5, 18.0, 24.5, 20.0),
        (22, "F.Cu", 0.2, 23.5, 18.0, 23.5, 20.0),
        # I2S Bus: BCK, WS, DATA from ESP32 to PCM5102A
        (25, "F.Cu", 0.25, 36.5, 17.5, 36.5, 60.0),
        (25, "F.Cu", 0.25, 36.5, 60.0, 42.0, 65.0),
        (26, "F.Cu", 0.25, 35.5, 17.5, 35.5, 59.0),
        (26, "F.Cu", 0.25, 35.5, 59.0, 41.0, 65.0),
        (27, "F.Cu", 0.25, 34.5, 17.5, 34.5, 58.0),
        (27, "F.Cu", 0.25, 34.5, 58.0, 40.0, 65.0),
        # Audio Analog Output from PCM5102A to MAX97220A to 3.5mm Jack
        (42, "F.Cu", 0.3, 44.8, 68.0, 45.5, 68.0),
        (43, "F.Cu", 0.3, 44.8, 69.0, 45.5, 69.0),
        (44, "F.Cu", 0.35, 49.8, 68.0, 49.5, 76.0),
        (45, "F.Cu", 0.35, 49.8, 69.0, 49.5, 80.0),
        # USB Differential Pair (DP/DM) from Type-C to CP2102N
        (8, "F.Cu", 0.25, 28.0, 81.0, 24.0, 76.0),
        (9, "F.Cu", 0.25, 27.0, 81.0, 23.0, 76.0),
        # UART TX / RX from CP2102N to ESP32
        (10, "B.Cu", 0.2, 19.0, 72.0, 19.0, 22.0),
        (10, "B.Cu", 0.2, 19.0, 22.0, 26.5, 18.0),
        (11, "B.Cu", 0.2, 18.0, 72.0, 18.0, 23.0),
        (11, "B.Cu", 0.2, 18.0, 23.0, 25.5, 18.0),
        # Power Net VDD_3V3 (Net 2) distribution
        (2, "F.Cu", 0.5, 20.95, 67.35, 27.5, 67.35),
        (2, "F.Cu", 0.5, 27.5, 67.35, 27.5, 18.0),
        # VBUS 5V (Net 3)
        (3, "F.Cu", 0.6, 27.5, 81.0, 20.0, 81.0),
        (3, "F.Cu", 0.6, 20.0, 81.0, 12.0, 68.0),
        # V_SYS (Net 4)
        (4, "F.Cu", 0.6, 12.0, 64.0, 19.05, 64.65)
    ]
    for n_id, layer, width, x1, y1, x2, y2 in tracks:
        pcb.append(f'  (segment (start {x1} {y1}) (end {x2} {y2}) (width {width}) (layer "{layer}") (net {n_id}) (uuid "{uid()}"))')

    # Add Vias connecting layers
    via_list = [
        (1, 10.0, 20.0), (1, 45.0, 20.0), (1, 10.0, 70.0), (1, 45.0, 70.0),
        (2, 27.5, 17.5), (2, 21.0, 67.0), (10, 19.0, 72.0), (11, 18.0, 72.0)
    ]
    for v_net, vx, vy in via_list:
        pcb.append(f'  (via (at {vx} {vy}) (size 0.6) (drill 0.3) (layers "F.Cu" "B.Cu") (net {v_net}) (uuid "{uid()}"))')

    # Continuous Solid Ground Plane Zone on In1.Cu (Net 1 GND)
    pcb.append('  (zone (net 1) (net_name "GND") (layer "In1.Cu") (uuid "' + uid() + '")')
    pcb.append('    (hatch edge 0.5)')
    pcb.append('    (connect_pads yes (clearance 0.25))')
    pcb.append('    (min_thickness 0.15)')
    pcb.append('    (filled_areas_thickness no)')
    pcb.append('    (fill yes (thermal_gap 0.25) (thermal_bridge_width 0.3))')
    pcb.append('    (polygon (pts')
    pcb.append('      (xy 0.5 7.0) (xy 54.5 7.0) (xy 54.5 84.5) (xy 0.5 84.5)')
    pcb.append('    ))')
    pcb.append('  )')

    # Solid Ground Plane Zone on B.Cu (Net 1 GND)
    pcb.append('  (zone (net 1) (net_name "GND") (layer "B.Cu") (uuid "' + uid() + '")')
    pcb.append('    (hatch edge 0.5)')
    pcb.append('    (connect_pads yes (clearance 0.25))')
    pcb.append('    (min_thickness 0.15)')
    pcb.append('    (filled_areas_thickness no)')
    pcb.append('    (fill yes (thermal_gap 0.25) (thermal_bridge_width 0.3))')
    pcb.append('    (polygon (pts')
    pcb.append('      (xy 0.5 7.0) (xy 54.5 7.0) (xy 54.5 84.5) (xy 0.5 84.5)')
    pcb.append('    ))')
    pcb.append('  )')

    # Dedicated Analog Ground Plane Island on In1.Cu (Net 7 AGND)
    pcb.append('  (zone (net 7) (net_name "AGND") (layer "In1.Cu") (uuid "' + uid() + '")')
    pcb.append('    (hatch edge 0.5)')
    pcb.append('    (connect_pads yes (clearance 0.25))')
    pcb.append('    (min_thickness 0.15)')
    pcb.append('    (filled_areas_thickness no)')
    pcb.append('    (fill yes (thermal_gap 0.25) (thermal_bridge_width 0.3))')
    pcb.append('    (polygon (pts')
    pcb.append('      (xy 38.0 62.0) (xy 54.0 62.0) (xy 54.0 84.0) (xy 38.0 84.0)')
    pcb.append('    ))')
    pcb.append('  )')

    # Power Plane Split Zones on In2.Cu (VDD_3V3 Net 2 and V_SYS Net 4)
    pcb.append('  (zone (net 2) (net_name "VDD_3V3") (layer "In2.Cu") (uuid "' + uid() + '")')
    pcb.append('    (hatch edge 0.5)')
    pcb.append('    (connect_pads yes (clearance 0.25))')
    pcb.append('    (min_thickness 0.2)')
    pcb.append('    (filled_areas_thickness no)')
    pcb.append('    (fill yes (thermal_gap 0.25) (thermal_bridge_width 0.35))')
    pcb.append('    (polygon (pts')
    pcb.append('      (xy 1.0 7.0) (xy 54.0 7.0) (xy 54.0 60.0) (xy 1.0 60.0)')
    pcb.append('    ))')
    pcb.append('  )')

    pcb.append(')')

    with open(PCB_PATH, "w") as f:
        f.write("\n".join(pcb))
    print(f"Generated complete native 4-layer KiCad PCB: {PCB_PATH}")

if __name__ == "__main__":
    generate_pcb()
