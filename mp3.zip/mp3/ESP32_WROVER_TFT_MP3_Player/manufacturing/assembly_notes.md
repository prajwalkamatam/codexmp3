# ESP32-WROVER-E Smart MP3 Player — Manufacturing & Assembly Notes

## 1. PCB Fabrication Specifications (JLCPCB / PCBWay Standard)

| Parameter | Specification | Manufacturing Notes |
|---|---|---|
| **Board Dimensions** | 55.00 mm × 85.00 mm | Tolerance: ±0.15 mm |
| **Layer Count** | 4 Layers | Controlled Impedance (JLC04161H-7628 stack-up) |
| **Board Thickness** | 1.6 mm ± 10% | Standard FR4 TG150 |
| **Surface Finish** | ENIG (Electroless Nickel Immersion Gold) | Recommended for QFN-24 and TSSOP fine-pitch pads |
| **Outer Copper Weight** | 1 oz (35 µm) | Signal & Power routing |
| **Inner Copper Weight** | 0.5 oz (17.5 µm) | Ground and Power Planes |
| **Minimum Track / Space** | 0.15 mm / 0.15 mm (6 mil / 6 mil) | Standard capability |
| **Minimum Hole / Drill** | 0.30 mm / 0.45 mm via pad | Standard via size |
| **Solder Mask Color** | Matte Black or Classic Green | High contrast for silkscreen inspection |
| **Silkscreen Color** | White | High-resolution legibility |
| **Edge Connector / Routing** | CNC Milling with Mousebites or V-Scoring | Smooth radius on corners (R = 3.0 mm) |

---

## 2. 4-Layer PCB Stack-up Definition

```
Layer 1 (F.Cu):     Top Copper (Signal, Components)          -- 35 µm (1.0 oz)
  Prepreg:          FR4 (7628)                               -- 210 µm
Layer 2 (In1.Cu):   Inner Ground Plane (Continuous Solid GND)-- 17.5 µm (0.5 oz)
  Core:             FR4 Core                                 -- 1065 µm
Layer 3 (In2.Cu):   Inner Power Plane (VDD_3V3 & V_SYS)      -- 17.5 µm (0.5 oz)
  Prepreg:          FR4 (7628)                               -- 210 µm
Layer 4 (B.Cu):     Bottom Copper (Signal, Secondary Pour)   -- 35 µm (1.0 oz)
Total Thickness:    1.6 mm ± 10%
```

---

## 3. SMT Assembly & Inspection Guidelines

1. **Solder Paste & Stencil**:
   - Stencil thickness: 0.12 mm (5 mil) laser-cut stainless steel with electropolish.
   - Reduction: 10% on QFN-24 and TSSOP-20 pins; 4-window cross pattern on ESP32 central ground pad (39).
2. **Thermal Pad Reflow**:
   - Ensure adequate thermal vias beneath U1 (ESP32), U5 (CP2102N), and U6 (TP4056).
3. **RF Antenna Clearance**:
   - The keep-out zone at top of PCB ($18.0	ext{ mm} 	imes 6.5	ext{ mm}$) must have **ZERO copper**, no traces, and no vias on all 4 layers.
4. **Hand Assembly / Post-SMT Components**:
   - 1.3-inch ST7789 TFT display module (J2) can be plugged into 8-pin female header or soldered directly using FPC cable.
   - JST-PH battery connector (J_BAT) orientation: Pin 1 = Positive (Red), Pin 2 = Negative (Black).
