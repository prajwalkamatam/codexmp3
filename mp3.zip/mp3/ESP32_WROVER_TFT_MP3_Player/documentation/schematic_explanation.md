# ESP32-WROVER-E Smart MP3 Player — Schematic Circuit Walkthrough

## 1. USB Type-C Receptacle & Input ESD Protection (Sheet 1)

### Circuit Elements: `J1`, `R_CC1`, `R_CC2`, `D10`, `C_VBUS1`
- **Receptacle**: Standard 16-pin / 12-pin USB 2.0 Type-C connector (`J1`).
- **Configuration Channel Pins (`CC1`, `CC2`)**:
  - `CC1` connected to GND through $5.1\text{ k}\Omega\ (\pm 1\%)$ resistor `R_CC1`.
  - `CC2` connected to GND through $5.1\text{ k}\Omega\ (\pm 1\%)$ resistor `R_CC2`.
  - *Engineering Note*: These two resistors must remain strictly separate. Shorting them together prevents detection by USB-C E-marked cables and Power Delivery (PD) chargers. Separate pull-downs advertise the player as a standard $5.0\text{ V}$ Upstream Facing Port (UFP / Sink), drawing up to $3.0\text{ A}$ from compliant hosts.
- **TVS ESD Protection Array (`D10`)**:
  - High-speed low-capacitance TVS diode array (USBLC6-2SC6, SOT-23-6).
  - Channels clamp $D+$ and $D-$ lines to protect against $\pm 15\text{ kV}$ air discharge / $\pm 8\text{ kV}$ contact discharge without degrading high-speed signal integrity.
- **VBUS Decoupling**: $10\ \mu\text{F}$ ceramic capacitor rated at $25\text{ V}$ (`C_VBUS1`) absorbs input voltage overshoot caused by cable inductance.

---

## 2. USB-to-UART Bridge & Auto-Programming Circuit (Sheet 2)

### Circuit Elements: `U5` (CP2102N), `Q3`, `Q4` (Dual NPN), `SW_RST`, `SW_BOOT`
- **Bridge IC**: Silicon Labs CP2102N-A02-GQFN24.
  - Powered from USB VBUS ($5\text{ V}$) into pin `REGIN`.
  - Integrated 3.3 V regulator outputs 3.3 V on `VDD` (pin 6) and powers `VIO` (pin 5) to match the ESP32 3.3 V logic level.
  - USB D+ and D- connect directly to pins 4 and 3.
  - TXD output connects to ESP32 RXD0 (`GPIO3`), and RXD input connects to ESP32 TXD0 (`GPIO1`).
- **ESP32 Auto-Download Reset Circuit**:
  - Consists of two NPN bipolar junction transistors (`Q3`, `Q4`, e.g., UMH3N or dual MMBT3904).
  - Base of Q3 driven by RTS through $10\text{ k}\Omega$ resistor `R_RTS`.
  - Base of Q4 driven by DTR through $10\text{ k}\Omega$ resistor `R_DTR`.
  - Emitter of Q3 tied to DTR; Collector connected to ESP32 `EN`.
  - Emitter of Q4 tied to RTS; Collector connected to ESP32 `GPIO0`.
  - When esptool / idf.py commands a download:
    - RTS is driven HIGH and DTR is driven LOW $\rightarrow$ `EN` is driven LOW (reset asserted).
    - DTR is driven HIGH and RTS is driven LOW $\rightarrow$ `GPIO0` is pulled LOW while `EN` transitions HIGH, successfully latching the ESP32 into ROM download boot mode.
- **RC Delay on EN**: A $1.0\ \mu\text{F}$ capacitor (`C_EN`) and $10\text{ k}\Omega$ pull-up (`R_EN`) ensure that when `EN` is released, the rise time is slower than `GPIO0`, guaranteeing reliable boot strapping.
- **Manual Buttons**:
  - `SW_RST`: Tactile button pulling `EN` to GND.
  - `SW_BOOT`: Tactile button pulling `GPIO0` to GND.

---

## 3. Battery Charger, Load Sharing & Protection (Sheet 3)

### Circuit Elements: `U6` (TP4056), `Q1` (AO3401A), `D1` (MBR0520), `U7` (DW01A), `U8` (FS8205A)
- **Charger IC (`U6`)**:
  - TP4056 linear Li-ion charger in ESOP-8 package with exposed thermal pad soldered to GND plane.
  - `PROG` pin programmed with $R_{\text{PROG}} = 2.4\text{ k}\Omega$ to establish a constant charging current of $I_{\text{CHG}} = 1200 / 2400 = 500\text{ mA}$.
  - `~CHRG` pin (Pin 7) pulls LOW when charging, driving a red indicator LED (`LED_CHG`) and providing a logic state to TCA9534 expander input P5.
  - `~STDBY` pin (Pin 6) pulls LOW when charging is complete, driving a green indicator LED (`LED_FULL`).
- **Load Sharing (Power-Path)**:
  - Consists of P-channel MOSFET `Q1` (AO3401A) and Schottky diode `D1` (MBR0520).
  - Gate of Q1 connected to VBUS with $100\text{ k}\Omega$ pull-down `R_GATE`.
  - When VBUS is present ($5\text{ V}$), Q1 turns OFF. System rail `V_SYS` is supplied from VBUS through diode D1 ($\sim 4.65\text{ V}$). Battery charges without seeing system current.
  - When VBUS is absent ($0\text{ V}$), Gate is pulled to 0 V by `R_GATE`. Q1 turns hard ON ($V_{\text{gs}} = -3.7\text{ V}$), connecting VBAT directly to `V_SYS` with $<10\text{ mV}$ drop.
- **Protection Circuitry**:
  - `U7` (DW01A) continuously monitors cell voltage across pins `VDD` and `VSS`.
  - Pin `OD` controls over-discharge FET inside `U8` (FS8205A), cutting off battery discharge when voltage falls below $2.4\text{ V}$.
  - Pin `OC` controls over-charge FET inside `U8`, cutting off charging when voltage exceeds $4.3\text{ V}$.
  - Pin `CS` detects current sense resistor voltage across FET $R_{\text{ds(on)}}$, isolating the pack within $10\ \mu\text{s}$ during an external short circuit ($>3.0\text{ A}$).

---

## 4. System Power Regulation & Audio Filter (Sheet 4)

### Circuit Elements: `U9` (AP2112K-3.3), `FB1`, `C_IN`, `C_OUT`, `C_AUDIO`
- **Main LDO Regulator (`U9`)**:
  - Diodes Inc AP2112K-3.3 in SOT-23-5 package.
  - Input: `V_SYS` ($3.3\text{ V} - 4.65\text{ V}$), decoupled with $10\ \mu\text{F} + 0.1\ \mu\text{F}$ low-ESR ceramic capacitors.
  - Output: `VDD_3V3` ($3.30\text{ V} \pm 1.5\%$, up to $1.0\text{ A}$ peak), decoupled with $22\ \mu\text{F} + 0.1\ \mu\text{F}$ capacitors.
  - Powers ESP32, TFT logic, MicroSD, CP2102N, and TCA9534.
- **Analog Audio Power Filtering**:
  - To prevent digital Wi-Fi RF switching pulses from entering the audio DAC, `VDD_3V3` feeds the analog audio rail `AVDD_3V3` through a $\pi$-filter:
  - Ferrite Bead `FB1`: Murata BLM21PG601SN1D ($600\ \Omega\ @\ 100\text{ MHz}$, $1.5\text{ A}$ DC rating, $0.1\ \Omega$ DCR).
  - Capacitors: $10\ \mu\text{F}$ ceramic $+ 0.1\ \mu\text{F}$ high-frequency ceramic in parallel with $100\ \text{pF}$ RF bypass capacitor.

---

## 5. ESP32-WROVER-E Core Subsystem (Sheet 5)

### Circuit Elements: `U1`, Strapping Biasing, Decoupling
- **Decoupling Network**:
  - Main 3.3 V pins (Pins 2 and 3) decoupled with $10\ \mu\text{F}$ bulk ceramic cap and three $0.1\ \mu\text{F}$ high-frequency caps placed directly adjacent to VDD pads.
- **Memory Pin Isolation**:
  - Pin 27 (`GPIO16`) and Pin 28 (`GPIO17`) are completely unconnected on the PCB to protect the internal 8 MB PSRAM bus.
  - Pins 17–22 (`GPIO6–11`) are completely unconnected on the PCB to protect the internal 16 MB SPI Flash bus.
- **Strapping Pin Configuration**:
  - `GPIO0`: $10\text{ k}\Omega$ pull-up to 3.3 V.
  - `GPIO12`: Pulled LOW via $10\text{ k}\Omega$ resistor to prevent setting flash to 1.8 V.
  - `GPIO15`: Pulled HIGH via $10\text{ k}\Omega$ resistor.
  - `GPIO2`: Pulled LOW via $10\text{ k}\Omega$ resistor.
- **Antenna Region**:
  - Positioned at the top edge of the PCB. All copper (signal, power, and ground) on all four layers is cleared for $18.0\text{ mm} \times 6.5\text{ mm}$ beneath and around the PCB meander antenna to maintain $50\ \Omega$ radiation impedance.

---

## 6. ST7789 TFT Display & Backlight Driver (Sheet 6)

### Circuit Elements: `J2` (Display Interface), `Q2` (BSS138), `R_BL`, `C_DISP`
- **Display Connection**:
  - 8-pin interface: `GND`, `VCC` (3.3 V), `SCL` (GPIO18), `SDA` (GPIO23), `RES` (GPIO22), `DC` (GPIO21), `CS` (GPIO5), `BLK` (Backlight Cathode).
- **Backlight Switching**:
  - N-channel MOSFET `Q2` (BSS138, SOT-23).
  - Gate connected to `GPIO4` with $100\ \Omega$ series damping resistor and $10\text{ k}\Omega$ pull-down resistor.
  - Drain connected to `BLK` through $15\ \Omega$ ($0.25\text{ W}$) current-limiting resistor `R_BL`.
  - Source connected to `GND`.
  - LEDC PWM on GPIO4 provides smooth $0\% - 100\%$ dimming without flicker.

---

## 7. MicroSD Card Interface (Sheet 7)

### Circuit Elements: `J3` (MicroSD Push-Push Socket), Pull-up Resistors
- **SPI Mode Wiring**:
  - `CLK` $\rightarrow$ `GPIO18` (Shared VSPI Clock)
  - `MOSI / CMD` $\rightarrow$ `GPIO23` (Shared VSPI MOSI)
  - `MISO / DAT0` $\rightarrow$ `GPIO19` (Dedicated SPI MISO)
  - `CS / DAT3` $\rightarrow$ `GPIO13` (Dedicated MicroSD Chip Select)
- **Bus Biasing**:
  - All SPI lines (`CLK`, `MOSI`, `MISO`, `CS`, `DAT1`, `DAT2`) feature $10\text{ k}\Omega$ pull-up resistors to `VDD_3V3` to prevent floating inputs when the card is removed or uninitialized.
- **Card Detect Switch (`CD`)**:
  - Mechanical push-push switch inside socket connects to TCA9534 expander pin `P6` with $10\text{ k}\Omega$ pull-up. Pulls to GND when card is inserted.

---

## 8. High-Fidelity Audio DAC & Headphone Output (Sheet 8)

### Circuit Elements: `U2` (PCM5102A), `U3` (MAX97220A), `J4` (3.5 mm Jack), Reconstruction Filter
- **DAC Stage (`U2`)**:
  - `I2S_BCK` (`GPIO26`) $\rightarrow$ Pin 11 (`BCK`)
  - `I2S_WS` (`GPIO25`) $\rightarrow$ Pin 13 (`LRCK`)
  - `I2S_DATA` (`GPIO27`) $\rightarrow$ Pin 12 (`DIN`)
  - Flying charge pump capacitor `C_FLY` ($2.2\ \mu\text{F}$) between pins 2 and 4.
  - Negative rail output `VNEG` (Pin 5) decoupled with $2.2\ \mu\text{F}$ capacitor to `AGND`.
  - Configuration pins (`DEMP`, `FLT`, `SCK`, `FMT`) hardwired to `AGND`.
- **Reconstruction Filter**:
  - `OUTL` $\rightarrow 470\ \Omega$ series resistor $\rightarrow 2.2\text{ nF}$ C0G cap to AGND $\rightarrow 1.0\ \mu\text{F}$ AC-coupling cap $\rightarrow$ Amp `INL`.
  - `OUTR` $\rightarrow 470\ \Omega$ series resistor $\rightarrow 2.2\text{ nF}$ C0G cap to AGND $\rightarrow 1.0\ \mu\text{F}$ AC-coupling cap $\rightarrow$ Amp `INR`.
- **Amplifier Stage (`U3`)**:
  - Maxim MAX97220A DirectDrive amplifier powered from `AVDD_3V3`.
  - Input feedback network sets gain to $0\text{ dB}$ ($1.0\text{ V/V}$) with $10\text{ k}\Omega$ input and feedback resistors.
  - `~SHDN` controlled by `GPIO14` (`AMP_MUTE`) with $100\text{ k}\Omega$ pull-down resistor.
- **Headphone Output (`J4`)**:
  - Outputs connect to Tip and Ring of standard 3.5 mm stereo jack `J4` through $33\ \Omega$ ferrite damping beads (`FB_L`, `FB_R`) to suppress RF ingress.
  - Sleeve connected to `AGND`.
  - Isolated switch pin on jack connects to TCA9534 expander input `P7` (`HP_DET`) with $10\text{ k}\Omega$ pull-up. When plug is inserted, switch opens, pulling line LOW.

---

## 9. I2C I/O Expander & Tactile Buttons (Sheet 9)

### Circuit Elements: `U4` (TCA9534), `SW1 – SW7`
- **Expander (`U4`)**:
  - Address pins `A0`, `A1`, `A2` tied to GND $\rightarrow$ 7-bit I2C address `0x20`.
  - `SDA` to `GPIO32`, `SCL` to `GPIO33`, both pulled to 3.3 V with $4.7\text{ k}\Omega$ resistors.
  - `~INT` to `GPIO35` with $10\text{ k}\Omega$ pull-up.
- **Button Connections**:
  - `SW1` (Power): Connected directly to `GPIO36` (RTC Wakeup / VP) with $10\text{ k}\Omega$ pull-up and $100\text{ nF}$ debounce cap.
  - `SW2` (Play/Pause): Connected directly to `GPIO39` (VN) with $10\text{ k}\Omega$ pull-up and $100\text{ nF}$ debounce cap.
  - `SW3` (Next Track): Connected to TCA9534 `P0` with $100\text{ nF}$ cap.
  - `SW4` (Prev Track): Connected to TCA9534 `P1` with $100\text{ nF}$ cap.
  - `SW5` (Vol+): Connected to TCA9534 `P2` with $100\text{ nF}$ cap.
  - `SW6` (Vol-): Connected to TCA9534 `P3` with $100\text{ nF}$ cap.
  - `SW7` (Mode / BT): Connected to TCA9534 `P4` with $100\text{ nF}$ cap.
