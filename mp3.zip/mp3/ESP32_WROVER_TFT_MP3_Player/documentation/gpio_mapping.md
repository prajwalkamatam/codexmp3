# ESP32-WROVER-E Smart MP3 Player — GPIO Mapping & Pin Allocation

## 1. Master GPIO Mapping Table

| GPIO Pin | Pad Name | Function | Direction | Default State | Electrical Configuration & Hardware Details |
|---|---|---|---|---|---|
| **GPIO0** | GPIO0 | `BOOT_SW` / Mode Strap | In/Out | Pull-up (10 kΩ) | Connected to manual BOOT button and auto-programming dual NPN transistor circuit. Must be HIGH for SPI flash boot, LOW for UART download. |
| **GPIO1** | U0TXD | `UART0_TXD` | Output | High | ESP32 serial debug console and programming UART TX. Connected to CP2102N RXD. |
| **GPIO2** | GPIO2 | Strapping / Debug | In/Out | Pull-down (10 kΩ) | Strapping pin: Must be LOW or floating during UART download. Reserved or optional debug LED. |
| **GPIO3** | U0RXD | `UART0_RXD` | Input | High | ESP32 serial programming UART RX. Connected to CP2102N TXD. |
| **GPIO4** | GPIO4 | `TFT_BL` | Output | Low | Backlight PWM control via LEDC timer. Connects to Gate of N-MOSFET (BSS138) with 10 kΩ pull-down to ensure backlight is OFF during boot. |
| **GPIO5** | GPIO5 | `TFT_CS` | Output | Pull-up (10 kΩ) | ST7789 TFT SPI Chip Select (Active Low). Pulled HIGH to ensure display SPI bus is deselected at reset. |
| **GPIO6–11** | SD_CLK, SD_DATA0–3, SD_CMD | `SPI_FLASH` | Internal | Internal | **DEDICATED**: Interfaced internally to high-speed SPI Flash inside WROVER-E module. **DO NOT CONNECT EXTERNALLY**. |
| **GPIO12** | MTDI | Strapping / NC | Input | Pull-down (10 kΩ) | **CRITICAL STRAPPING PIN**: Selects VDD_SDIO flash supply voltage. If HIGH at boot, flash voltage sets to 1.8 V, causing module brownout/crash. Kept pulled down. |
| **GPIO13** | MTCK | `SD_CS` | Output | Pull-up (10 kΩ) | MicroSD Card SPI Chip Select (Active Low). Pulled HIGH to keep card deselected during power-up. |
| **GPIO14** | MTMS | `AMP_MUTE` | Output | Pull-down (100 kΩ) | MAX97220A Headphone Amplifier Shutdown/Mute control. Pulled LOW to ensure total silence (mute) during boot, preventing pops and clicks. |
| **GPIO15** | MTDO | `BOOT_LOG` | Output | Pull-up (10 kΩ) | Strapping pin: Controls UART boot logging. Normal boot output is enabled when HIGH. |
| **GPIO16** | GPIO16 | `PSRAM_CS` | Internal | Internal | **DEDICATED**: Connected internally to PSRAM Chip Select in ESP32-WROVER-E. **NEVER CONNECT EXTERNALLY**. |
| **GPIO17** | GPIO17 | `PSRAM_CLK` | Internal | Internal | **DEDICATED**: Connected internally to PSRAM Clock in ESP32-WROVER-E. **NEVER CONNECT EXTERNALLY**. |
| **GPIO18** | VSPICLK | `SPI_SCK` | Output | Low | High-Speed Master SPI Clock (VSPI). Shared between ST7789 TFT (up to 40 MHz) and MicroSD (up to 20 MHz). |
| **GPIO19** | VSPIMISO | `SPI_MISO` | Input | Pull-up (10 kΩ) | Master In / Slave Out for MicroSD Card. TFT does not drive MISO (3-wire/4-wire unidirectional write). |
| **GPIO21** | VSPIHD | `TFT_DC` | Output | Low | ST7789 Data / Command select line (Low = Command, High = Parameter/Data). |
| **GPIO22** | VSPIWP | `TFT_RST` | Output | Pull-up (10 kΩ) | ST7789 Hardware Reset (Active Low). Hardware RC delay and software controllable. |
| **GPIO23** | VSPID | `SPI_MOSI` | Output | Low | High-Speed Master SPI Data Out (VSPI). Shared between ST7789 TFT and MicroSD. |
| **GPIO25** | DAC1 | `I2S_WS` | Output | Low | I2S Word Select / Left-Right Clock (LRCLK). Connected to PCM5102A LRCK. |
| **GPIO26** | DAC2 | `I2S_BCK` | Output | Low | I2S Bit Clock (BCK). Connected to PCM5102A BCK. Continuous clocking for internal PLL. |
| **GPIO27** | GPIO27 | `I2S_DATA` | Output | Low | I2S Serial Data Out. Connected to PCM5102A DIN. |
| **GPIO32** | 32K_XP | `I2C_SDA` | In/Out (OD) | Pull-up (4.7 kΩ) | I2C Data bus for TCA9534 I/O Expander. Standard 400 kHz fast mode. |
| **GPIO33** | 32K_XN | `I2C_SCL` | Output (OD) | Pull-up (4.7 kΩ) | I2C Clock bus for TCA9534 I/O Expander. Standard 400 kHz fast mode. |
| **GPIO34** | VDET_1 | `BATT_SENSE` | Input Only | Analog | ADC1 Channel 6. Connected to 100 kΩ / 100 kΩ precision resistor divider with 100 nF filter cap on battery rail. Fully functional while Wi-Fi/BT active. |
| **GPIO35** | VDET_2 | `IO_INT` | Input Only | Pull-up (10 kΩ) | Interrupt signal from TCA9534 I/O Expander (Active Low). Alerts MCU to button presses, headphone insertion, or card detection. |
| **GPIO36** | SENSOR_VP | `BTN_PWR` | Input Only | Pull-up (10 kΩ) | Power Button / RTC Wakeup (ext0). Active Low, debounced with 100 nF capacitor. Can wake the ESP32 from deep sleep mode. |
| **GPIO39** | SENSOR_VN | `BTN_PLAY` | Input Only | Pull-up (10 kΩ) | Play / Pause Button. Active Low, debounced with 100 nF capacitor. Directly routed for instant response during playback. |

---

## 2. TCA9534 I2C I/O Expander Allocation Table

Address: `0x20` (A0=GND, A1=GND, A2=GND)

| Port Pin | Signal Name | Direction | Default State | Connected Device & Description |
|---|---|---|---|---|
| **P0** | `SW_NEXT` | Input | Pull-up (100 kΩ int + ext) | Next Track / Fast-Forward button. Active Low. |
| **P1** | `SW_PREV` | Input | Pull-up (100 kΩ int + ext) | Previous Track / Rewind button. Active Low. |
| **P2** | `SW_VOLUP` | Input | Pull-up (100 kΩ int + ext) | Volume Increment button (+). Active Low. |
| **P3** | `SW_VOLDN` | Input | Pull-up (100 kΩ int + ext) | Volume Decrement button (-). Active Low. |
| **P4** | `SW_MODE` | Input | Pull-up (100 kΩ int + ext) | Bluetooth / Output Mode button. Active Low. |
| **P5** | `CHG_STAT` | Input | Pull-up (10 kΩ) | Battery Charger State from TP4056 `~CHRG` pin. Low = Charging, High = Complete / Disconnected. |
| **P6** | `SD_CD` | Input | Pull-up (10 kΩ) | MicroSD Card Detect switch. Low = Card Inserted, High = Card Ejected. |
| **P7** | `HP_DET` | Input | Pull-up (10 kΩ) | 3.5 mm Headphone Jack isolated switch. Low = Headphone Plugged, High = Unplugged. |

---

## 3. Critical Electrical Constraints & Verification Rules

1. **PSRAM Pin Reservation**:
   - The ESP32-WROVER-E integrates an 8 MB PSRAM chip connected internally to GPIO16 (CS) and GPIO17 (CLK).
   - These pins are completely isolated on the PCB. No copper traces, vias, or test pads are attached to GPIO16 or GPIO17.

2. **SPI Flash Reservation**:
   - Pins GPIO6, GPIO7, GPIO8, GPIO9, GPIO10, and GPIO11 interface to the internal 16 MB SPI Flash.
   - These pins are omitted from external routing entirely.

3. **Strapping Pin Integrity**:
   - **GPIO0**: Must be pulled HIGH (10 kΩ) during power-up for normal execution from SPI flash. Auto-reset circuit temporarily pulls it LOW during UART flash download.
   - **GPIO12 (MTDI)**: Must remain LOW at boot. If pulled HIGH, the internal LDO switches flash voltage to 1.8 V, causing immediate boot failure for the 3.3 V flash chip.
   - **GPIO15 (MTDO)**: Kept pulled HIGH (10 kΩ) to enable ROM serial boot messages on UART0.
   - **GPIO2**: Strapping pin tied LOW via 10 kΩ to ensure successful download mode entry without floating glitches.

4. **Input-Only Pins (GPI 34–39)**:
   - GPIO34, 35, 36, and 39 lack internal pull-up and pull-down resistors in silicon.
   - All external connections to these pins feature dedicated external pull-up resistors (10 kΩ) or precision dividers.

5. **ADC Compatibility During Wireless Transmission**:
   - ADC2 channels are multiplexed with internal Wi-Fi/Bluetooth hardware and cannot be used reliably when RF transmissions occur.
   - Battery voltage monitoring is intentionally mapped to **ADC1 Channel 6 (GPIO34)**, guaranteeing 100% uninterrupted, accurate battery measurement while streaming music over Wi-Fi or Bluetooth.
