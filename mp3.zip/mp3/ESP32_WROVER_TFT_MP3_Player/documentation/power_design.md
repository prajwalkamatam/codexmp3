# ESP32-WROVER-E Smart MP3 Player — Power Architecture & Budget

## 1. System Power Budget Calculations

| Subsystem / Component | State / Operating Mode | Typ Current (3.3 V) | Peak Current (3.3 V) | Notes & Mitigation |
|---|---|---|---|---|
| **ESP32-WROVER-E CPU** | Dual-core @ 240 MHz (decoding MP3) | 65 mA | 90 mA | PSRAM active, clock frequency dynamic |
| **ESP32 Wi-Fi TX** | 802.11b, +19.5 dBm output | 180 mA | 380 mA | Burst mode during web streaming buffer fills |
| **ESP32 Bluetooth TX** | A2DP Classic Source (SBC codec) | 45 mA | 130 mA | Periodic 2.4 GHz RF bursts |
| **ST7789 TFT Logic** | 240 × 240 refresh @ 30 FPS | 8 mA | 12 mA | SPI clock active at 40 MHz |
| **TFT Backlight** | 100% Brightness (White display) | 22 mA | 25 mA | Current limited by R_BL (15 Ω) |
| **PCM5102A Audio DAC** | Active 44.1 kHz 24-bit playback | 24 mA | 30 mA | Internal charge pump running |
| **MAX97220A Headphone Amp** | Driving 32 Ω headphones at 85 dBA | 35 mA | 75 mA | Max output 125 mW per channel |
| **MicroSD Card** | Read bursts (FAT32 sector stream) | 18 mA | 85 mA | Decoupled with 10 µF + 0.1 µF local caps |
| **TCA9534, CP2102N, Passives** | Active standby | 12 mA | 20 mA | CP2102N suspended when USB unplugged |
| **TOTAL (Wired Headphone Playback)**| **Screen ON, 32 Ω Load, MicroSD** | **~184 mA** | **~337 mA** | **Continuous average: ~165 mA** |
| **TOTAL (Bluetooth Earbuds Playback)**| **Screen ON, BT A2DP, MicroSD** | **~172 mA** | **~362 mA** | **Continuous average: ~155 mA** |
| **TOTAL (Wi-Fi Music Stream + Wired)**| **Screen ON, Wi-Fi Active, Headphone**| **~324 mA** | **~672 mA** | **Peak LDO current requirement** |
| **Deep Sleep Mode** | **ESP32 RTC timer / button wake, screen OFF**| **~120 µA** | **~180 µA** | **Quiescent draw: Battery lasts >6 months** |

---

## 2. Battery Runtime Estimation

Assuming a standard single-cell rechargeable Li-ion/LiPo pouch battery (3.7 V nominal, 4.2 V full):

### Scenario A: 1200 mAh LiPo Cell (Typical 603450 Form Factor)
- **Continuous Local MP3 Playback (3.5 mm Headphones, Screen auto-dimmed to 30%)**:
  - Average current: 140 mA @ 3.3 V
  - Power consumption: 462 mW
  - Usable battery energy ($1200\text{ mAh} \times 3.7\text{ V} \times 90\% \text{ LDO efficiency} \approx 4.0\text{ Wh}$):
  - **Estimated Runtime: ~8.5 hours continuous playback**.

- **Continuous Bluetooth A2DP Streaming (TWS Earbuds, Screen auto-dimmed)**:
  - Average current: 130 mA @ 3.3 V
  - Power consumption: 429 mW
  - **Estimated Runtime: ~9.3 hours continuous playback**.

- **Display Auto-Off / Background Audio Playback**:
  - Average current: 110 mA @ 3.3 V
  - **Estimated Runtime: ~11.0 hours continuous playback**.

---

## 3. Power-Path (Load-Sharing) Architecture & Theory of Operation

When operating an MP3 player that charges via USB while simultaneously playing music, connecting the battery directly to both the charger output and the system load causes a fatal flaw: the system current prevents the charger IC from detecting when the battery charge current has dropped below the termination threshold ($C/10$), leading to battery over-charging, thermal degradation, and reduced safety.

To solve this, our design implements a dynamic hardware power-path circuit using a P-channel MOSFET (AO3401A) and a low-forward-drop Schottky barrier diode (MBR0520).

```
                      +-------------------+
                      |   USB VBUS 5.0 V  |
                      +---------+---------+
                                |
             +------------------+------------------+
             |                                     |
             | Gate                                | Anode
             v                                     v
       +-----------+                         +-----------+
       |  AO3401A  |                         |  MBR0520  |
       |  P-MOSFET |                         |  SCHOTTKY |
       +-----+-----+                         +-----+-----+
   Source    | Drain                               | Cathode
     ^       |                                     |
     |       +------------------+------------------+
     |                          |
+----+----+                     v
| BATTERY |               +-----------+
| (3.7 V) |               |   V_SYS   | (4.65 V on USB, or 3.7 V on Batt)
+---------+               +-----+-----+
                                |
                                v
                          +-----------+
                          | AP2112K   |
                          | 3.3 V LDO |
                          +-----+-----+
                                |
                                v
                          +-----------+
                          |  VDD_3V3  |
                          +-----------+
```

### 3.1 Operating State 1: USB Disconnected (Battery Operation)
- Gate of AO3401A is pulled to GND (0 V) through $R_{\text{gate}} = 100\text{ k}\Omega$.
- Source is connected to VBAT ($3.0\text{ V} - 4.2\text{ V}$).
- Gate-to-Source voltage: $V_{\text{gs}} = 0\text{ V} - 3.7\text{ V} = -3.7\text{ V}$.
- The AO3401A is driven fully into saturation ($R_{\text{ds(on)}} < 35\text{ m}\Omega$).
- The voltage drop across the MOSFET at 200 mA load is only:
  $$\Delta V = 0.200\text{ A} \times 0.035\ \Omega = 7\text{ mV}$$
- Schottky diode D1 is reverse-biased since USB VBUS is floating.
- Battery supplies V_SYS with negligible power loss ($>99.8\%$ efficiency).

### 3.2 Operating State 2: USB Connected (Charging + Playback)
- USB VBUS (5.0 V) supplies 5.0 V to the Gate of AO3401A.
- Gate-to-Source voltage: $V_{\text{gs}} = 5.0\text{ V} - 3.7\text{ V} = +1.3\text{ V} > 0\text{ V}$.
- The P-channel MOSFET turns completely OFF, isolating the battery from the load.
- Schottky diode D1 conducts from VBUS (5.0 V) to V_SYS:
  $$V_{\text{sys}} = 5.0\text{ V} - V_f \approx 5.0\text{ V} - 0.35\text{ V} = 4.65\text{ V}$$
- The TP4056 charges the battery in pure CC/CV isolation without seeing system load fluctuations. Charge termination at $C/10$ (50 mA) triggers correctly every time.

---

## 4. Voltage Regulator (AP2112K-3.3) Thermal & Dropout Analysis

### 4.1 Dropout Verification
- Minimum battery discharge cutoff: 3.30 V.
- Nominal battery voltage under load: 3.60 V.
- AP2112K-3.3 dropout voltage:
  - At 200 mA: $\sim 80\text{ mV} \rightarrow V_{\text{out}} = 3.30\text{ V}$ maintained down to $V_{\text{in}} = 3.38\text{ V}$.
  - At 600 mA peak: $\sim 250\text{ mV} \rightarrow V_{\text{out}} = 3.30\text{ V}$ maintained down to $V_{\text{in}} = 3.55\text{ V}$.
- When battery reaches 3.30 V, the ESP32 brownout detector triggers safe shutdown before unpredictable flash corruption occurs.

### 4.2 Thermal Dissipation
Worst-case power dissipation occurs when running from USB (V_SYS = 4.65 V) with Wi-Fi / BT active (300 mA):
$$P_{\text{diss}} = (V_{\text{in}} - V_{\text{out}}) \times I_{\text{load}} = (4.65\text{ V} - 3.30\text{ V}) \times 0.300\text{ A} = 0.405\text{ W}$$
For SOT-23-5 with thermal resistance $\theta_{\text{JA}} \approx 180\ ^\circ\text{C/W}$ on a 4-layer PCB with dedicated copper pours:
$$\Delta T = 0.405\text{ W} \times 120\ ^\circ\text{C/W} = 48.6\ ^\circ\text{C}$$
At an ambient temperature of $25\ ^\circ\text{C}$, the junction temperature reaches $\sim 73.6\ ^\circ\text{C}$, comfortably below the maximum rated junction temperature of $125\ ^\circ\text{C}$.

---

## 5. Battery Monitoring (ADC1 Channel 6)

- Resistor divider: $R_{\text{top}} = 100\text{ k}\Omega\ (\pm 1\%)$, $R_{\text{bot}} = 100\text{ k}\Omega\ (\pm 1\%)$.
- Attenuation ratio: $\alpha = 0.500$.
- Filter capacitor: $C = 100\text{ nF}$ (cutoff frequency $f_c \approx 31.8\text{ Hz}$ to filter out RF burst noise).
- Quiescent current draw:
  $$I_{\text{sense}} = \frac{4.2\text{ V}}{200\text{ k}\Omega} = 21\ \mu\text{A}$$
- ADC input voltage range:
  - Battery 4.20 V (100% full): $V_{\text{ADC}} = 2.10\text{ V}$
  - Battery 3.70 V (50% nominal): $V_{\text{ADC}} = 1.85\text{ V}$
  - Battery 3.30 V (0% empty): $V_{\text{ADC}} = 1.65\text{ V}$
- The ESP32 ADC1 is configured with 11 dB attenuation ($0\text{ V} - 3.1\text{ V}$ full-scale), placing the full battery range in the most linear region of the ADC converter.
