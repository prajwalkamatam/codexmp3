# ESP32-WROVER-E Smart MP3 Player — Component Selection & Bill of Materials

## 1. Primary Active Components

### 1.1 Microcontroller Unit
- **Designator**: U1
- **Component**: ESP32-WROVER-E-N16R8 (or ESP32-WROVER-E with 8 MB PSRAM, 16 MB SPI Flash)
- **Manufacturer**: Espressif Systems
- **Package**: SMD-38 (18.0 mm × 31.4 mm × 3.3 mm)
- **LCSC Part #**: C473049 / C701342
- **Key Specifications**:
  - Dual-Core Xtensa LX6 32-bit CPU up to 240 MHz
  - 520 KB internal SRAM
  - 8 MB PSRAM (Pseudo-Static RAM) on internal 80 MHz bus
  - 16 MB QSPI Flash memory
  - 802.11 b/g/n Wi-Fi (up to 150 Mbps)
  - Bluetooth v4.2 BR/EDR (Classic) and Bluetooth Low Energy (BLE)
  - Operating voltage: 3.0 V – 3.6 V (Nominal 3.3 V)
  - Integrated PCB antenna with RF matching network
- **Rationale**: The WROVER-E family provides verified onboard 8 MB PSRAM necessary for holding decoded audio ring buffers, large LVGL display framebuffers, album artwork textures, and network sockets without memory exhaustion.

### 1.2 Audio Digital-to-Analog Converter (DAC)
- **Designator**: U2
- **Component**: PCM5102APWR
- **Manufacturer**: Texas Instruments
- **Package**: TSSOP-20 (PW-20, 0.65 mm pitch)
- **LCSC Part #**: C524803
- **Key Specifications**:
  - Dynamic Range / SNR: 112 dB
  - THD+N @ -1 dBFS: -93 dB
  - Integrated High-Performance Charge Pump (true ground-centered 2.1 Vrms output, no DC bias)
  - Integrated PLL for SCK generation from standard BCK (removes requirement for MCLK wire)
  - Supports 16-bit, 24-bit, and 32-bit audio up to 384 kHz sample rate
  - Single 3.3 V supply operation
- **Rationale**: Integrated PLL simplifies ESP32 routing; high dynamic range and ground-centered output remove large, distorting DC-blocking capacitors.

### 1.3 Stereo Headphone Amplifier
- **Designator**: U3
- **Component**: MAX97220AETE+T
- **Manufacturer**: Analog Devices / Maxim Integrated
- **Package**: TQFN-16 (3 mm × 3 mm) or TSSOP-14 (MAX97220BETE+ / MAX97220AUE+)
- **LCSC Part #**: C128522
- **Key Specifications**:
  - DirectDrive Ground-Referenced Output Architecture
  - Output Power: 125 mW into 32 Ω from 3.3 V supply
  - THD+N: 0.003% into 32 Ω at 1 kHz
  - SNR: 112 dB
  - Active Click-and-Pop suppression on shutdown/enable
  - Short-circuit and thermal overload protection
- **Rationale**: DirectDrive provides true ground-referenced outputs directly matching the 3.5 mm jack sleeve connected to system ground, preventing headphone ground loop DC currents.

### 1.4 I2C 8-Bit I/O Expander
- **Designator**: U4
- **Component**: TCA9534PWR
- **Manufacturer**: Texas Instruments
- **Package**: TSSOP-16 (0.65 mm pitch)
- **LCSC Part #**: C132247
- **Key Specifications**:
  - 8 General Purpose I/O pins with individual direction and polarity inversion
  - Open-drain active-low interrupt output (`~INT`)
  - Low standby current: 1.0 µA
  - I2C Fast-Mode up to 400 kHz
  - Operating voltage: 1.65 V to 5.5 V
- **Rationale**: Offloads navigation buttons, headphone sense, card detect, and charger status from the ESP32, avoiding strapping pin conflicts and freeing precious native GPIOs.

### 1.5 USB-to-UART Bridge
- **Designator**: U5
- **Component**: CP2102N-A02-GQFN24R
- **Manufacturer**: Silicon Labs
- **Package**: QFN-24 (4 mm × 4 mm, 0.5 mm pitch)
- **LCSC Part #**: C151608
- **Key Specifications**:
  - USB 2.0 Full-Speed compliant (12 Mbps)
  - Integrated USB termination resistors and clock generator (crystal-less)
  - Integrated 5 V to 3.3 V LDO
  - Hardware modem handshake lines (DTR, RTS)
  - Baud rates up to 3 Mbps
- **Rationale**: Highly reliable, robust driver support across Windows, macOS, and Linux; official Espressif programming standard.

### 1.6 Battery Charger & Power-Path
- **Designator**: U6, Q1, D1
- **Components**:
  - Charger: TP4056 (ESOP-8, NanJing Top Power, LCSC C16581)
  - Power-Path P-MOSFET: AO3401A (SOT-23, Alpha & Omega Semiconductor, LCSC C15127, -30 V, -4.2 A, Rds(on) = 35 mΩ)
  - Power-Path Schottky Diode: MBR0520LT1G (SOD-123, ON Semi, LCSC C80687, 20 V, 0.5 A, Vf = 0.35 V)
- **Key Specifications**:
  - Constant-current / constant-voltage linear charging for single-cell Li-ion (4.20 V ±1%)
  - Configurable charge current via R_PROG (2.4 kΩ = 500 mA, standard USB limit)
  - Automatic load-sharing disconnects battery from load when 5 V VBUS is applied
- **Rationale**: Protects battery life by ensuring charge termination current is not masked by system operating current.

### 1.7 Battery Protection
- **Designator**: U7, U8
- **Components**:
  - Protection Controller: DW01A (SOT-23-6, Fortune Semiconductor, LCSC C37130)
  - Dual N-MOSFET Switch: FS8205A (TSSOP-8, Fortune Semiconductor, LCSC C32254, 20 V, 6 A, Rds(on) = 25 mΩ)
- **Key Specifications**:
  - Over-charge detection: 4.30 V ±0.05 V
  - Over-discharge detection: 2.40 V ±0.1 V
  - Over-current detection: 3.0 A cutoff
  - Standby current: <0.1 µA

### 1.8 3.3 V Voltage Regulator
- **Designator**: U9
- **Component**: AP2112K-3.3TRG1
- **Manufacturer**: Diodes Incorporated
- **Package**: SOT-23-5
- **LCSC Part #**: C440121
- **Key Specifications**:
  - Output Voltage: 3.3 V fixed ±1.5%
  - Output Current: 1.0 A Peak, 600 mA Continuous
  - Dropout Voltage: 250 mV at 600 mA
  - High PSRR: 65 dB at 1 kHz
  - Quiescent Current: 55 µA
  - Integrated thermal overload and short-circuit protection
- **Rationale**: Low dropout enables full battery discharge down to 3.55 V under load; low output ripple ensures clean digital audio and RF performance.

---

## 2. Electromechanical & Display Components

### 2.1 1.3-Inch IPS Color TFT Display
- **Designator**: DISP1 / J2
- **Resolution**: 240 × 240 pixels (RGB565, 65K colors)
- **Controller**: Sitronix ST7789V / ST7789H2
- **Active Area**: 23.4 mm × 23.4 mm (1.3-inch diagonal)
- **Viewing Angle**: Full IPS (80°/80°/80°/80°)
- **Interface**: 4-wire SPI (SCL, SDA/MOSI, DC, CS, RST, BLK)
- **Supply Voltage**: 3.3 V logic and analog

### 2.2 MicroSD Card Socket
- **Designator**: J3
- **Component**: Push-Push MicroSD Card Socket, Reverse Mount / Top Mount SMD
- **Manufacturer**: Korean HRO / Amphenol (TF-01A / 114-00841-68)
- **LCSC Part #**: C91145
- **Features**: Push-to-insert, push-to-eject mechanism, integrated card detection mechanical switch.

### 2.3 3.5 mm Stereo Audio Jack
- **Designator**: J4
- **Component**: PJ-327A / PJ-320A 3.5 mm Stereo Phone Jack SMD
- **Manufacturer**: Korean HRO / CUI Devices
- **LCSC Part #**: C26390
- **Features**: 5 pins (Tip, Ring, Sleeve, Tip Switch, Ring Switch). Switch isolates detect line when jack is inserted.

### 2.4 USB Type-C Receptacle
- **Designator**: J1
- **Component**: TYPE-C-31-M-12 (16-pin / 12-pin USB 2.0 Type-C SMD)
- **Manufacturer**: Korean HRO / ShenXun
- **LCSC Part #**: C165948
- **Features**: 4 through-hole mechanical anchoring shield tabs, dual CC pins, high-reliability gold-plated contacts.

### 2.5 Tactile Pushbuttons
- **Designator**: SW1 – SW7, SW_RST, SW_BOOT
- **Component**: TS-1187A / TS-1088 4-pin SMD Tactile Switch (4.0 mm × 4.0 mm × 1.5 mm, 160 gf actuation)
- **LCSC Part #**: C318884
- **Features**: Sharp tactile feel, rated for 100,000 cycles, compact surface mount profile.
