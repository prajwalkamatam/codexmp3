# ESP32-WROVER-E Smart MP3 Player — Assembly Guide

## 1. Safety & Electrostatic Discharge (ESD) Precautions

- Always work on a grounded static-dissipative ESD mat.
- Wear an ESD wrist strap connected to earth ground with a 1 MΩ safety resistor.
- Lithium-ion cells store significant energy. Never short-circuit battery terminals (`VBAT` and `GND`). Do not connect the battery until power supply rails have passed electrical verification.

---

## 2. Tools & Equipment Required

- Temperature-controlled soldering station with fine conical and chisel tips.
- Hot air rework station with nozzle assortment.
- Low-temperature lead-free solder paste (SAC305 or Sn42Bi58 for delicate parts) and flux pen.
- PCB reflow hot plate (or reflow oven) with temperature profiling.
- High-magnification inspection microscope or digital microscope (10x – 40x).
- Digital Multimeter with continuity, diode check, and sub-millivolt DC range.
- Fine curved ESD tweezers and solder wick (braid).
- Isopropyl Alcohol (IPA >99%) and lint-free antistatic swabs.

---

## 3. Recommended Soldering Sequence

To minimize thermal stress and allow progressive testing, solder components in the following stages:

```
Stage 1: Power Management & Voltage Regulators
  -> USB-C Receptacle (J1), TVS Diode (D10)
  -> TP4056 Charger (U6), Load Sharing FET (Q1), Diode (D1)
  -> AP2112K-3.3 LDO (U9), Associated bypass capacitors
  [VERIFY: Plug in USB-C, confirm clean 3.30 V on VDD_3V3 rail before proceeding!]

Stage 2: USB-to-UART Programming Bridge
  -> CP2102N QFN-24 (U5)
  -> Auto-programming dual NPN BJTs (Q3, Q4)
  -> Passives, Reset (SW_RST) and Boot (SW_BOOT) buttons
  [VERIFY: Connect USB to PC, verify CP2102N USB COM port enumerates!]

Stage 3: Microcontroller Core
  -> ESP32-WROVER-E Module (U1)
  -> Strapping resistors, EN pull-up and timing capacitor
  [VERIFY: Open terminal at 115200 baud, press RST, confirm bootloader banner!]

Stage 4: Audio DAC & Headphone Output
  -> PCM5102A DAC TSSOP-20 (U2) and charge pump capacitors
  -> Ferrite bead (FB1) and analog rail filtering caps
  -> MAX97220A Headphone Amp (U3)
  -> Reconstruction filter resistors and capacitors
  -> 3.5 mm Audio Jack (J4)

Stage 5: Display & Storage Interfaces
  -> MicroSD Push-Push Socket (J3) and SPI pull-up array
  -> ST7789 TFT Interface Header / FPC (J2)
  -> Backlight MOSFET (Q2) and current-limiting resistor (R_BL)

Stage 6: I2C Expander & Tactile Buttons
  -> TCA9534PWR TSSOP-16 (U4)
  -> Navigation Tactile Switches (SW1 – SW7)
  -> Battery monitoring resistors (R_DIV1, R_DIV2)
  -> Battery connector JST-PH 2.0 mm (J_BAT)
```

---

## 4. Critical Component Orientations

| Component | Designator | Package | Pin 1 / Polarity Indicator |
|---|---|---|---|
| **ESP32-WROVER-E** | `U1` | SMD-38 | Pin 1 (GND) is top-left when antenna points UP. Soldered flat on thermal ground pad. |
| **PCM5102A** | `U2` | TSSOP-20 | Circular index dot next to Pin 1 (`CPVDD`). Beveled package edge. |
| **MAX97220A** | `U3` | TSSOP-14 / TQFN-16 | Dot / notch at Pin 1 (`INL+`). |
| **TCA9534** | `U4` | TSSOP-16 | Circular dimple at Pin 1 (`A0`). |
| **CP2102N** | `U5` | QFN-24 | Laser-etched circle on corner corresponding to Pin 1 (`DCD`). Solder center thermal pad to GND. |
| **TP4056** | `U6` | ESOP-8 | Dot at Pin 1 (`TEMP`). Solder exposed thermal belly to PCB heat-sink vias. |
| **AO3401A** | `Q1` | SOT-23 | Pin 1 = Gate, Pin 2 = Source, Pin 3 = Drain. |
| **MBR0520** | `D1` | SOD-123 | Cathode white band connects to `V_SYS`. |
| **LEDs (CHG/STDBY)** | `LED1`, `LED2` | 0805 | Green dot / cathode marking on rear side points to IC open-drain pins. |
| **JST-PH Connector**| `J_BAT` | 2.0 mm 2-Pin | Pin 1 = `VBAT+` (Red wire), Pin 2 = `GND` (Black wire). **VERIFY BATTERY POLARITY WITH DMM BEFORE INSERTING!** |

---

## 5. Reflow Profile (Lead-Free SAC305)

```
Temperature (°C)
  260 |                                         /\  Peak: 245 °C - 250 °C (max 10 s)
      |                                        /  \
  220 |---------------------------------------/----\-- Liquidus: 217 °C
      |                       +--------------+      \  Time above 217 °C: 45 - 60 s
  180 |                      / Soak Window   |       \
      |                     / 150 - 180 °C   |        \
  150 |                    /  60 - 90 s      |         \
      |     +-------------+                  |          \  Cooling Rate: <4 °C/s
      |    / Ramp-up: <2 °C/s                |           \
   25 +---+----------------------------------+------------+---> Time (s)
          0                                 120          210
```

---

## 6. Post-Assembly Cleaning & Inspection

1. Clean residual flux using an ultrasonic bath or brush with 99.8% Isopropyl Alcohol (IPA).
2. Inspect QFN-24 and TSSOP pins under a microscope for solder bridges or micro-whiskers.
3. Verify that the ESP32 antenna area is completely clean of any stray solder balls or conductive debris.
