# ESP32-WROVER-E Smart MP3 Player — Display Interface & Graphic Pipeline

## 1. ST7789 1.3-Inch IPS TFT Overview

- **Display Resolution**: 240 × 240 pixels.
- **Color Depth**: RGB565 (16-bit color, 65,536 colors: 5 bits Red, 6 bits Green, 5 bits Blue).
- **Controller**: Sitronix ST7789V / ST7789H2 high-performance display driver.
- **Physical Active Display Area**: 23.40 mm × 23.40 mm.
- **Physical Pixel Pitch**: 0.0975 mm × 0.0975 mm ($260\text{ PPI}$).

---

## 2. SPI Bus Performance & DMA Sizing

### 2.1 Bandwidth and Frame Rate Calculation
For a 240 × 240 display in RGB565 mode:
- Bytes per frame:
  $$\text{Bytes} = 240 \times 240 \times 2\text{ bytes/pixel} = 115,200\text{ bytes} = 921,600\text{ bits}$$
- Operating SPI clock frequency: $f_{\text{SPI}} = 40.0\text{ MHz}$.
- Time required to transmit one full frame over 4-wire SPI:
  $$t_{\text{frame}} = \frac{921,600\text{ bits}}{40,000,000\text{ bits/second}} \approx 23.04\text{ ms}$$
- Maximum theoretical full-frame refresh rate:
  $$\text{FPS}_{\text{max}} = \frac{1}{0.02304\text{ s}} \approx 43.4\text{ FPS}$$

For real-time UI animation, smooth scrolling of song titles, and volume sliders, 30 FPS to 40 FPS is easily achieved without blocking the CPU.

### 2.2 Memory Allocation Strategy
- **Internal DMA-Capable SRAM**:
  ESP32 SPI DMA hardware requires buffers located in internal DMA-capable SRAM (DRAM), not PSRAM!
  Allocating a full 115 KB frame in internal RAM would strain internal memory needed for Wi-Fi and Bluetooth stacks.
  Therefore, a dual-line partial buffer architecture is used:
  - Buffer Height: 40 lines (one-sixth of the screen: $240 \times 40$ pixels).
  - Buffer Size: $240 \times 40 \times 2 = 19,200\text{ bytes}$ ($18.75\text{ KB}$).
  - Two buffers (`disp_buf1` and `disp_buf2`) totaling $37.5\text{ KB}$ allocated in internal DMA RAM with flag `MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL`.
  - While Buffer 1 is being transmitted to the display over SPI via hardware DMA in the background, Buffer 2 is concurrently rendered by Core 1.
- **PSRAM Allocation**:
  - Full-color album artwork ($240 \times 240$ JPEG/PNG images), decoded audio buffers, and complex font glyph caches are stored in the 8 MB external PSRAM using `heap_caps_malloc(..., MALLOC_CAP_SPIRAM)`.

---

## 3. Backlight Driver Circuit & Efficiency

The TFT backlight consists of 2 or 3 parallel white LEDs requiring approximately $20\text{ mA} - 25\text{ mA}$ at a forward drop of $3.0\text{ V}$.

```
                 VDD_3V3 (3.3 V)
                     |
                     +-------+
                             |
                           [R_BL] 15 Ω, 0805, 0.25 W
                             |
                             v
                       +-----------+
                       |  TFT BLK  | (Cathode / Backlight Return)
                       +-----+-----+
                             |
                             | Drain
                             v
                       +-----------+
    GPIO4 (TFT_BL) --->|  BSS138   | N-Channel MOSFET
      (100 Ω series)   |  (Q2)     | SOT-23
                       +-----+-----+
                             | Source
                             v
                            GND
```

### 3.1 Component Sizing & Current Regulation
- Supply: $V_{\text{DD}} = 3.3\text{ V}$.
- LED forward voltage: $V_f \approx 3.0\text{ V}$.
- MOSFET saturation resistance: $R_{\text{ds(on)}} \approx 1.5\ \Omega$.
- Current-limiting resistor: $R_{\text{BL}} = 15\ \Omega$.
- Backlight current at 100% duty cycle:
  $$I_{\text{BL}} = \frac{3.3\text{ V} - 3.0\text{ V}}{15\ \Omega + 1.5\ \Omega} \approx 18.2\text{ mA}$$
- Power dissipation in $R_{\text{BL}}$:
  $$P_{R} = I^2 R = (0.0182)^2 \times 15 = 4.97\text{ mW}$$
  (Operates well below the 250 mW rating of an 0805 SMD resistor).

### 3.2 PWM Dimming & Power Management
- Driver: ESP32 LEDC (LED Controller) hardware peripheral configured for 10-bit resolution ($0 - 1023$ levels).
- PWM Frequency: $5.0\text{ kHz}$ (high enough to eliminate audible coil whine and display flicker).
- **Power Management States**:
  1. **Active Playback**: Backlight set by user preference ($20\% - 100\%$).
  2. **Inactivity Dimming**: If no buttons pressed for 30 seconds, backlight automatically ramps down smoothly to $10\%$ over 2 seconds.
  3. **Screen Timeout**: If inactive for 60 seconds, backlight ramps to $0\%$ and ST7789 enters deep sleep command `DISPOFF (0x28)` and `SLPIN (0x10)`, saving $\sim 30\text{ mA}$.
  4. **Wake on Input**: Any button press immediately restores backlight to active level.
