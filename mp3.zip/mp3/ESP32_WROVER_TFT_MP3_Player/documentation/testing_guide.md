# ESP32-WROVER-E Smart MP3 Player — Testing & Bring-Up Verification Guide

## 1. Initial Bring-Up & Power Rail Verification

**CRITICAL PRE-POWER SAFETY CHECK**: Never plug in a Lithium-ion battery or high-current USB supply immediately after assembly. Follow these progressive verification steps using a current-limited bench power supply.

```
Step 1: Unpowered Cold Resistance Check
  -> Set Digital Multimeter to Ohms (Ω) range.
  -> Measure resistance from each test point to GND:
     - TP_VBUS to GND:   > 100 kΩ (Check for solder bridges on USB-C J1)
     - TP_VSYS to GND:   > 50 kΩ  (Check load sharing FET and diode)
     - TP_VBAT to GND:   > 100 kΩ (Check battery protection circuit)
     - TP_3V3 to GND:    > 5 kΩ   (Check ESP32, LDO, and peripheral bypass caps)
     - TP_A3V3 to GND:   > 10 kΩ  (Check DAC and Headphone Amp)
  -> PASS CRITERIA: No low-resistance shorts (< 100 Ω) to GND on any power rail.

Step 2: Limited Current Power Injection (Without Battery)
  -> Set bench power supply to 5.00 V with current limit set to 100 mA.
  -> Inject 5.0 V into TP_VBUS and GND.
  -> Monitor quiescent current draw:
     - Expected current: 15 mA – 45 mA (CP2102N + LDO + ESP32 in idle boot state).
  -> Measure DC voltage rails with DMM:
     - TP_VBUS:  5.00 V ± 0.1 V
     - TP_VSYS:  4.65 V ± 0.1 V (5.0 V minus Schottky diode drop)
     - TP_3V3:   3.30 V ± 0.05 V (Main digital logic rail)
     - TP_A3V3:  3.30 V ± 0.05 V (Analog audio rail after FB1)
  -> PASS CRITERIA: All voltage rails within ±2% tolerance with zero thermal hotspots.
```

---

## 2. USB Enumeration & Auto-Programming Verification

1. Connect the board to a PC host using a high-quality USB Type-C to USB-A (or Type-C to Type-C) data cable.
2. Verify host OS detects the Silicon Labs CP2102N bridge:
   - **macOS / Linux**: `ls /dev/cu.usbserial*` or `ls /dev/ttyUSB*`
   - **Windows**: Device Manager $\rightarrow$ Ports (COM & LPT) $\rightarrow$ `Silicon Labs CP210x USB to UART Bridge (COMx)`
3. Open a serial terminal at $115,200\text{ baud}$ ($8\text{-N-}1$):
   ```bash
   python3 -m serial.tools.miniterm /dev/ttyUSB0 115200
   ```
4. Press the hardware `SW_RST` pushbutton on the board.
5. Verify the ESP32 ROM bootloader output banner:
   ```text
   rst:0x1 (POWERON_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)
   configsip: 0, SPIWP:0xee
   clk_drv:0x00,q_drv:0x00,d_drv:0x00,cs0_drv:0x00,hd_drv:0x00,wp_drv:0x00
   mode:DIO, clock div:2
   load:0x3fff0018,len:4
   load:0x3fff001c,len:1044
   load:0x40078000,len:10124
   load:0x40080400,len:5828
   entry 0x400806ac
   ```
   *Verification*: `boot:0x13` confirms strapping pins (GPIO0 HIGH, GPIO12 LOW) were sampled correctly!
6. Verify Auto-Download circuit:
   ```bash
   esptool.py --chip esp32 --port /dev/ttyUSB0 chip_id
   ```
   *Expected Response*:
   ```text
   Detecting chip type... ESP32
   Chip is ESP32-D0WD-V3 (revision 3)
   Features: WiFi, BT, Dual Core, 240MHz, VRef calibration in efuse, Coding Scheme None
   Crystal is 40MHz
   MAC: 24:6f:28:xx:xx:xx
   ```

---

## 3. Peripheral Hardware Verification Tests

### 3.1 Display & Backlight Test
1. Flash firmware. Observe ST7789 TFT initialization.
2. Confirm colors:
   - Red screen test: `#FF0000`
   - Green screen test: `#00FF00`
   - Blue screen test: `#0000FF`
   - White screen test: `#FFFFFF`
3. Backlight PWM test:
   - Command backlight ramp from $0\%$ to $100\%$ duty cycle.
   - Confirm linear illumination increase without acoustic hum or flicker.

### 3.2 MicroSD Storage Test
1. Insert a FAT32-formatted MicroSD card (16 GB – 64 GB, Class 10) containing test `.mp3` files.
2. Observe terminal log:
   ```text
   I (SD): Initializing SD card via SPI...
   I (SD): Card mounted successfully at /sdcard
   I (SD): Volume Name: MP3_MUSIC
   I (SD): Total Space: 30436 MB, Free: 28140 MB
   I (SD): Scanning /sdcard/music ... Found 42 MP3 tracks.
   ```
3. Verify ID3v2 tag extraction (Song Title, Artist, Duration).

### 3.3 Audio DAC & Headphone Output Test
1. Connect $32\ \Omega$ stereo headphones to the 3.5 mm jack `J4`.
2. Generate a $1.0\text{ kHz}$ reference stereo sine wave at $-3\text{ dBFS}$ via firmware:
   - Probe `OUTL` and `OUTR` with an oscilloscope.
   - Confirm clean, undistorted $1.48\text{ Vrms}$ ($4.18\text{ V}_{\text{pp}}$) ground-centered sine wave.
   - Confirm zero DC offset ($V_{\text{DC}} < 2\text{ mV}$) across headphone load.
3. Click/Pop Acoustic Test:
   - Power cycle player while wearing headphones.
   - Confirm complete absence of audible turn-on "thump" or turn-off transient clicks.

### 3.4 Bluetooth A2DP Streaming Test
1. Put standard commercial TWS Bluetooth earbuds (e.g. AirPods, Sony WF-1000XM4, Galaxy Buds) into pairing mode.
2. On the MP3 player UI, navigate to "Bluetooth Devices" and select "Scan".
3. Verify earbud device name appears in list with RSSI.
4. Select "Connect" $\rightarrow$ Verify A2DP Source connects and audio stream switches from 3.5 mm jack to Bluetooth.
5. Walk 10 meters away through line-of-sight: verify audio remains continuous without dropouts or buffer underruns.

### 3.5 Dynamic Power-Path (Load Sharing) Test
1. Connect USB-C charger while playing music over headphones from battery.
2. Verify audio continues without any glitch or reset.
3. Unplug USB-C cable while music is actively playing.
4. Verify P-MOSFET instantly engages battery power without brownout or audio stutter.
5. Observe charging LED: Red when battery < 4.15 V; Green when fully charged (4.20 V).
