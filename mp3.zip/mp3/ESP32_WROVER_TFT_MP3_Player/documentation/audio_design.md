# ESP32-WROVER-E Smart MP3 Player — Audio Subsystem Design & Analysis

## 1. Complete Audio Pipeline Topology

```
+------------------+         +------------------+         +------------------+         +------------------+
|  ESP32-WROVER-E  |   I2S   |  PCM5102A STEREO |  Analog |    MAX97220A     |  Stereo |   3.5 mm STEREO  |
|  Helix MP3 / DMA | ------> |   24-bit DAC     | ------> |  HEADPHONE AMP   | ------> |     PHONE JACK   |
|  (Core 1 Task)   |         | (Integrated PLL) |         | (DirectDrive)    |         |  (Ground-Ref.)   |
+------------------+         +------------------+         +------------------+         +------------------+
         |                                                         ^
         | GPIO14 (AMP_MUTE / Active High EN)                      |
         +---------------------------------------------------------+
```

---

## 2. PCM5102A Hardware Configuration & Clocking

The TI PCM5102A is an advanced 32-bit, 384 kHz stereo audio DAC featuring an integrated phase-locked loop (PLL) that generates its internal master clock (MCLK / SCK) directly from the incoming bit clock (BCK). This avoids routing a high-frequency (11.2896 MHz / 12.288 MHz) master clock line from the ESP32, which would otherwise radiate RF energy and contaminate sensitive analog lines.

### Hardware Pin Configuration
| Pin # | Pin Name | Hardware Connection | Functional Setting |
|---|---|---|---|
| **Pin 8** | `DEMP` | Connected to `DGND` | De-emphasis filter disabled (flat frequency response) |
| **Pin 9** | `FLT` | Connected to `DGND` | Normal latency digital filter (FIR roll-off) |
| **Pin 10** | `SCK` | Connected to `DGND` | Enables internal PLL clock generator derived from BCK |
| **Pin 11** | `BCK` | Connected to `GPIO26` | I2S Bit Clock from ESP32 |
| **Pin 12** | `DIN` | Connected to `GPIO27` | I2S Serial Audio Data |
| **Pin 13** | `LRCK` | Connected to `GPIO25` | I2S Word Select / Left-Right Clock |
| **Pin 14** | `FMT` | Connected to `DGND` | Standard I2S Audio Format (MSB-first, 1 BCK delay) |
| **Pin 15** | `XSMT` | Pull-up 10 kΩ to 3.3 V | Soft mute disabled (unmuted) with external RC ramp |
| **Pin 16** | `LDOO` | 0.1 µF ceramic to `DGND` | Internal digital LDO stabilization |
| **Pin 2** | `CAPP` | 2.2 µF ceramic to `CAPN` | Charge pump flying capacitor (rated 16 V) |
| **Pin 4** | `CAPN` | 2.2 µF ceramic to `CAPP` | Charge pump flying capacitor |
| **Pin 5** | `VNEG` | 2.2 µF ceramic to `AGND` | Negative rail charge pump output (-3.3 V) |

---

## 3. Passive Reconstruction Filter Design

The analog outputs of the PCM5102A (`OUTL` and `OUTR`) are ground-centered $2.1\text{ Vrms}$ signals carrying high-frequency out-of-band delta-sigma modulator quantization noise. To eliminate this out-of-band energy before reaching the headphone amplifier, a 1st-order passive low-pass RC reconstruction filter is placed between the DAC output and amplifier input.

- Filter series resistor: $R_f = 470\ \Omega\ (\pm 1\%)$
- Filter shunt capacitor: $C_f = 2.2\text{ nF}\ (\pm 5\%,\ \text{C0G/NP0 dielectric})$
- Cutoff frequency:
  $$f_c = \frac{1}{2 \pi R_f C_f} = \frac{1}{2 \pi \times 470\ \Omega \times 2.2 \times 10^{-9}\text{ F}} \approx 153.8\text{ kHz}$$

### Filter Frequency Response Performance
- At audio boundary ($20\text{ kHz}$):
  $$\text{Attenuation} = 20 \log_{10} \left( \frac{1}{\sqrt{1 + (20 / 153.8)^2}} \right) \approx -0.07\text{ dB}$$
  (Completely transparent across the entire audible human hearing range $20\text{ Hz} - 20\text{ kHz}$).
- At delta-sigma modulation frequency ($5.6448\text{ MHz}$):
  $$\text{Attenuation} \approx -31.3\text{ dB}$$
  (High-frequency RF energy is suppressed before entering the input stages of the amplifier).

---

## 4. MAX97220A DirectDrive Headphone Amplifier

Standard single-supply headphone amplifiers require massive ($220\ \mu\text{F} - 470\ \mu\text{F}$) electrolytic DC-blocking capacitors in series with the headphone jack to remove the $V_{\text{DD}}/2$ DC bias voltage. These capacitors introduce:
1. Low-frequency roll-off into 16 Ω / 32 Ω headphones (bass loss).
2. Significant non-linear harmonic distortion (THD).
3. Huge board space consumption.

The MAX97220A features an integrated inverting charge pump that creates an internal negative supply rail ($-3.3\text{ V}$) from the positive $+3.3\text{ V}$ input rail. Because the internal amplifiers operate from a bipolar $\pm 3.3\text{ V}$ supply, the output quiescent DC voltage is exactly $0\text{ V}$ (ground-centered). The headphone jack connects directly to the amplifier outputs without any DC-blocking capacitors!

### 4.1 Gain and Input Impedance
- Input AC coupling capacitor: $C_{\text{in}} = 1.0\ \mu\text{F}$ (X7R)
- Input resistor: $R_{\text{in}} = 10\text{ k}\Omega$
- Feedback resistor: $R_{\text{fb}} = 10\text{ k}\Omega$
- Closed-loop voltage gain:
  $$A_v = -\frac{R_{\text{fb}}}{R_{\text{in}}} = -1.0\text{ V/V}\ (0\text{ dB})$$
- Input high-pass cutoff frequency:
  $$f_{\text{HP}} = \frac{1}{2 \pi R_{\text{in}} C_{\text{in}}} = \frac{1}{2 \pi \times 10000\ \Omega \times 1.0 \times 10^{-6}\text{ F}} \approx 15.9\text{ Hz}$$
  (Allows full bass extension down to $16\text{ Hz}$ without phase distortion).

### 4.2 Power Output and Headphone Drive Capability
- Maximum output into 32 Ω load at $V_{\text{DD}} = 3.3\text{ V}$:
  $$P_{\text{out}} = 125\text{ mW per channel}$$
  Equivalent output voltage into 32 Ω:
  $$V_{\text{rms}} = \sqrt{P \times R} = \sqrt{0.125 \times 32} = 2.0\text{ Vrms}$$
- Maximum Sound Pressure Level (SPL) for typical $100\text{ dB/mW}$ sensitivity earbuds:
  $$\text{SPL}_{\text{max}} = 100 + 10 \log_{10}(125) \approx 121\text{ dB SPL}$$
  (Ample headroom for high-impedance studio headphones and low-sensitivity IEMs).

---

## 5. Anti-Click & Anti-Pop Hardware Control Sequence

Clicks and pops occur when rapid DC voltage shifts occur on the output terminals during power-on and power-off transitions. The system eliminates this through firmware-synchronized hardware muting:

```
[System Power Up]
       |
       v
ESP32 Boots: GPIO14 held LOW by 100 kΩ pull-down
MAX97220A SHDN is held LOW (High-Z Output, Complete Silence)
       |
       v
ESP32 initializes I2S peripheral (continuous BCK and WS clocks start)
PCM5102A PLL locks onto BCK (internal charge pump stabilizes to -3.3 V)
PCM5102A outputs settle to 0.00 V DC
       |
       v
Firmware delays 150 ms (waiting for all transients to settle)
       |
       v
Firmware drives GPIO14 HIGH (3.3 V)
MAX97220A internal soft-start click/pop circuit un-mutes outputs smoothly
Zero audible pop heard in headphones!
```

---

## 6. Grounding & PCB Noise Isolation Architecture

Audio SNR is severely degraded if high-frequency digital return currents (from ESP32 Wi-Fi bursts or SPI display refreshes) flow across analog audio return traces.
1. **Dedicated Analog Ground (AGND)**: The PCM5102A analog pins (Pins 5, 6, 7, 19, 20) and MAX97220A ground pins connect to a dedicated, quiet analog audio ground island.
2. **Star Ground Connection**: The analog ground connects to the main system digital ground plane (`GND`) at a single, controlled point located directly underneath the output audio jack via a 0 Ω resistor / direct necked pour.
3. **Ferrite Bead Rail Isolation**: The $+3.3\text{ V}$ analog rail (`AVDD_3V3`) is separated from the main digital 3.3 V rail (`VDD_3V3`) by a high-frequency ferrite bead (FB1, $600\ \Omega\ @\ 100\text{ MHz}$) backed by a $10\ \mu\text{F}$ tantalum/ceramic and $0.1\ \mu\text{F}$ high-frequency ceramic capacitor.
