# ESP32-WROVER-E Smart MP3 Player — System Architecture

## 1. System Overview

The ESP32-WROVER-E Smart MP3 Player is a high-fidelity, handheld, battery-powered portable audio player featuring dual-output audio (wired 3.5 mm stereo headphone jack via high-end I2S DAC and wireless Bluetooth Classic A2DP stereo streaming to TWS earbuds), a 1.3-inch 240×240 IPS TFT display, onboard MicroSD card storage, USB-C connectivity with hardware power-path charging management and automatic UART programming, and 7 ergonomic physical control buttons.

```
+---------------------------------------------------------------------------------------------------+
|                                        USB TYPE-C RECEPTACLE                                      |
|                               (VBUS 5.0 V, CC1/CC2 5.1 k pull-downs, D+/D-)                       |
+-------------------------------------------------+-------------------------------------------------+
                                                  |
                         +------------------------+------------------------+
                         |                                                 |
                         v                                                 v
           +---------------------------+                     +---------------------------+
           |   USBLC6-2SC6 TVS ESD     |                     |    TP4056 CHARGER &       |
           |     PROTECTION ARRAY      |                     |    AO3401A LOAD-SHARING   |
           +-------------+-------------+                     +-------------+-------------+
                         |                                                 |
                         v                                                 v
           +---------------------------+                     +---------------------------+
           |     CP2102N USB-UART      |                     |   SINGLE-CELL Li-ion/LiPo |
           |  (Integrated LDO & Clocks)|                     |   (3.7 V Nom, DW01A Prot) |
           +-------------+-------------+                     +-------------+-------------+
                         |                                                 |
                         | (TXD/RXD, DTR/RTS)                              v
                         |                                   +---------------------------+
                         v                                   |     V_SYS POWER RAIL      |
           +---------------------------+                     |       (3.3 V - 5.0 V)     |
           |    AUTO-RESET TRANSISTORS |                     +-------------+-------------+
           |    (UMH3N Dual NPN BJT)   |                                   |
           +-------------+-------------+                                   v
                         |                                   +---------------------------+
                         | (EN, GPIO0)                       |   AP2112K-3.3 1.0 A LDO   |
                         |                                   |    (Low Dropout, PSRR)    |
                         |                                   +-------------+-------------+
                         |                                                 |
                         +------------------------+------------------------+
                                                  |
                                                  v (VDD_3V3 System Rail)
+---------------------------------------------------------------------------------------------------+
|                                     ESP32-WROVER-E MODULE                                         |
|                                (Xtensa Dual-Core LX6 @ 240 MHz)                                   |
|                                (8 MB SPI Flash + 8 MB PSRAM)                                      |
|                                                                                                   |
|  [ADC1 Channels]          [VSPI Bus]                  [I2S0 Bus]              [I2C0 Bus]          |
|  - GPIO34: BATT_SENSE     - GPIO18: SCLK (Shared)     - GPIO25: WS / LRCK     - GPIO32: SDA       |
|  - GPIO35: IO_INT         - GPIO23: MOSI (Shared)     - GPIO26: BCK           - GPIO33: SCL       |
|  - GPIO36: BTN_PWR        - GPIO19: MISO (SD only)    - GPIO27: DATA          (4.7 k pull-ups)    |
|  - GPIO39: BTN_PLAY       - GPIO5:  TFT_CS            - GPIO14: AMP_MUTE                          |
|                           - GPIO13: SD_CS                                                         |
|                           - GPIO21: TFT_DC                                                        |
|                           - GPIO22: TFT_RST                                                       |
|                           - GPIO4:  TFT_BL (PWM)                                                  |
+------------+--------------------+-------------------------+--------------------+------------------+
             |                    |                         |                    |
             v                    v                         v                    v
     +---------------+    +---------------+         +---------------+    +---------------+
     |  1.3" IPS TFT |    |    MicroSD    |         | PCM5102A DAC  |    | TCA9534 I/O   |
     |  ST7789V SPI  |    |  PUSH-PUSH    |         | (Integrated   |    |   EXPANDER    |
     |   240 x 240   |    |    SOCKET     |         |  PLL, 112 dB) |    +-------+-------+
     +---------------+    +---------------+         +-------+-------+            |
                                                            |                    +-- P0: SW_NEXT
                                                            v                    +-- P1: SW_PREV
                                                    +---------------+            +-- P2: SW_VOLUP
                                                    |   MAX97220A   |            +-- P3: SW_VOLDN
                                                    | HEADPHONE AMP |            +-- P4: SW_MODE
                                                    | (DirectDrive) |            +-- P5: CHG_STAT
                                                    +-------+-------+            +-- P6: SD_CD
                                                            |                    +-- P7: HP_DET
                                                            v
                                                    +---------------+
                                                    |  3.5 mm AUDIO |
                                                    |  STEREO JACK  |
                                                    +---------------+
```

## 2. Subsystem Functional Descriptions

### 2.1 Microcontroller Subsystem
- **Core**: Espressif ESP32-WROVER-E-N16R8 module.
- **Memory**: 16 MB quad-SPI flash running at 80 MHz, 8 MB pseudo-static RAM (PSRAM) running at 80 MHz connected via dedicated internal high-speed memory bus (GPIO16/GPIO17).
- **Processing Partitioning**:
  - **Core 0**: Wi-Fi stack, Bluetooth Classic A2DP source stack, FreeRTOS background tasks, MicroSD FAT32 file streaming.
  - **Core 1**: LVGL graphic rendering engine, ST7789 SPI DMA blitting, MP3 algorithmic decoding, software volume scaling, I2S FIFO streaming.

### 2.2 Audio Pipeline Subsystem
- **Digital Interface**: I2S Philips standard, 16-bit / 24-bit stereo at 44.1 kHz or 48.0 kHz.
- **Digital-to-Analog Converter (DAC)**: Texas Instruments PCM5102A.
  - Generates master clock (MCLK) internally from BCK using an on-chip PLL, eliminating high-frequency MCLK routing across the PCB.
  - True ground-centered 2.1 Vrms stereo output via integrated charge pump.
- **Headphone Amplifier**: Maxim / Analog Devices MAX97220A.
  - DirectDrive ground-referenced architecture eliminates bulky DC-blocking electrolytic capacitors.
  - Delivers 125 mW per channel into 32 Ω headphones with 0.003% THD+N.
  - Active pop/click suppression controlled via GPIO14 (`AMP_MUTE`).
- **Bluetooth A2DP Source**:
  - Encodes decoded PCM frames to SBC format and streams wirelessly to Bluetooth earbuds/headphones.

### 2.3 Display and User Interface
- **Display Module**: 1.3-inch IPS TFT, 240×240 resolution, ST7789 controller.
- **Data Bus**: High-speed SPI operating up to 40 MHz with ESP32 SPI DMA channels.
- **Backlight Control**: N-channel MOSFET driven by ESP32 LEDC PWM on GPIO4 (0–100% duty cycle, 5 kHz PWM frequency).
- **Physical Controls**:
  - Power button (GPIO36) allows power latching / wake-up from deep sleep via ESP32 RTC controller.
  - Play/Pause button (GPIO39) direct low-latency input.
  - Next, Prev, Volume+, Volume-, Mode buttons mapped to Texas Instruments TCA9534 I2C expander.
  - Headphone insertion detection (`HP_DET`) and MicroSD card detection (`SD_CD`) integrated into expander interrupt line.

### 2.4 Power and Battery Subsystem
- **Input**: USB Type-C 5.0 V input with USBLC6-2SC6 ESD protection and separate 5.1 kΩ pull-downs on CC1 and CC2.
- **Battery Charging**: NanJing Top Power TP4056 linear CC/CV charger configured for 500 mA charge rate.
- **Power-Path (Load Sharing)**: P-channel MOSFET (AO3401A) and Schottky barrier diode (MBR0520) automatically disconnect the battery from the system load when USB is plugged in, allowing simultaneous playback and charging without interrupting charge termination.
- **Battery Protection**: DW01A protection IC coupled with FS8205A dual N-channel MOSFET provides over-charge, over-discharge, and short-circuit cutoffs.
- **System Regulation**: AP2112K-3.3 ultra-low dropout (LDO) regulator delivering up to 1.0 A continuous with 250 mV dropout and high PSRR.
- **Audio Rail Filtering**: Analog audio rail (`AVDD_3V3`) isolated from digital switching noise using a high-impedance ferrite bead (600 Ω @ 100 MHz) and low-ESR ceramic decoupling.
