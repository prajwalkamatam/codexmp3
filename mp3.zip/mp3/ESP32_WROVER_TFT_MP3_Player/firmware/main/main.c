#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "nvs_flash.h"

// Component headers
#include "st7789.h"
#include "audio_player.h"
#include "bt_a2dp_source.h"
#include "sd_card.h"
#include "input_manager.h"
#include "power_manager.h"
#include "wifi_manager.h"
#include "ui.h"

static const char *TAG = "MAIN";

static int s_current_track_idx = 0;

static void on_button_event(button_id_t btn, button_event_type_t event)
{
    if (event != BTN_EVENT_PRESS) return;

    switch (btn) {
        case BTN_PLAY_PAUSE:
            ESP_LOGI(TAG, "Event: PLAY/PAUSE Button Triggered");
            audio_player_toggle_play();
            break;

        case BTN_NEXT_TRACK: {
            int total = sd_card_get_track_count();
            if (total > 0) {
                s_current_track_idx = (s_current_track_idx + 1) % total;
                const file_item_t *track = sd_card_get_track(s_current_track_idx);
                if (track) {
                    audio_player_play_file(track->filepath);
                }
            }
            break;
        }

        case BTN_PREV_TRACK: {
            int total = sd_card_get_track_count();
            if (total > 0) {
                s_current_track_idx = (s_current_track_idx - 1 + total) % total;
                const file_item_t *track = sd_card_get_track(s_current_track_idx);
                if (track) {
                    audio_player_play_file(track->filepath);
                }
            }
            break;
        }

        case BTN_VOL_UP: {
            uint8_t vol = audio_player_get_volume();
            if (vol <= 95) audio_player_set_volume(vol + 5);
            else audio_player_set_volume(100);
            break;
        }

        case BTN_VOL_DOWN: {
            uint8_t vol = audio_player_get_volume();
            if (vol >= 5) audio_player_set_volume(vol - 5);
            else audio_player_set_volume(0);
            break;
        }

        case BTN_MODE_SELECT:
            ESP_LOGI(TAG, "Event: MODE / SCREEN CYCLE Triggered");
            ui_next_screen();
            break;

        case BTN_POWER:
            ESP_LOGI(TAG, "Event: POWER Button Triggered");
            // Low power deep sleep entry
            power_manager_enter_deep_sleep();
            break;

        default:
            break;
    }
}

static void on_headphone_event(bool plugged_in)
{
    if (plugged_in) {
        ESP_LOGI(TAG, "3.5mm Headphone plugged in -> Switching audio to WIRED DAC");
        audio_player_set_route(AUDIO_ROUTE_HEADPHONES);
    } else {
        ESP_LOGI(TAG, "3.5mm Headphone removed -> Auto-pausing audio playback");
        audio_player_pause();
    }
}

static void on_sd_card_event(bool inserted)
{
    if (inserted) {
        ESP_LOGI(TAG, "MicroSD inserted -> Scanning music library");
        sd_card_init();
    } else {
        ESP_LOGI(TAG, "MicroSD removed -> Stopping audio playback");
        audio_player_stop();
        sd_card_unmount();
    }
}

static void ui_render_task(void *arg)
{
    ESP_LOGI(TAG, "UI Graphic Render Task started on Core 1 (30 FPS)");
    const TickType_t frame_period = pdMS_TO_TICKS(33); // ~30 FPS

    while (1) {
        TickType_t start_time = xTaskGetTickCount();
        ui_render_tick();
        vTaskDelayUntil(&start_time, frame_period);
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "==========================================================");
    ESP_LOGI(TAG, "  ESP32-WROVER-E SMART MP3 PLAYER — FIRMWARE INITIALIZING");
    ESP_LOGI(TAG, "==========================================================");

    // 1. Initialize NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        nvs_flash_init();
    }

    // 2. Report Hardware & Memory Capabilities
    size_t free_internal = heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
    size_t free_psram = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
    ESP_LOGI(TAG, "Internal SRAM Free: %u bytes", free_internal);
    ESP_LOGI(TAG, "External PSRAM Free: %u bytes (8 MB Chip Verified)", free_psram);

    // 3. Initialize Power Management (ADC Battery Fuel Gauge)
    power_manager_init();

    // 4. Initialize ST7789 IPS Display Subsystem (240x240 RGB565)
    st7789_init();

    // 5. Initialize MicroSD Storage Subsystem
    sd_card_init();

    // 6. Initialize Audio Player Subsystem (PCM5102A + MAX97220A)
    audio_player_init();

    // 7. Initialize Bluetooth Classic A2DP Source Subsystem
    bt_a2dp_source_init();

    // 8. Initialize Wi-Fi Subsystem
    wifi_manager_init();

    // 9. Initialize Input Manager (TCA9534 I2C Expander + Tactile Buttons)
    input_manager_init();
    input_manager_register_button_cb(on_button_event);
    input_manager_register_hp_cb(on_headphone_event);
    input_manager_register_sd_cb(on_sd_card_event);

    // 10. Start playing first track if available
    if (sd_card_get_track_count() > 0) {
        const file_item_t *first_track = sd_card_get_track(0);
        if (first_track) {
            audio_player_play_file(first_track->filepath);
        }
    }

    // 11. Initialize UI
    ui_init();

    // 12. Create UI Render Task pinned to Core 1
    xTaskCreatePinnedToCore(ui_render_task, "ui_render", 4096, NULL, 3, NULL, 1);

    ESP_LOGI(TAG, "System initialization complete. Music player ready.");
}
