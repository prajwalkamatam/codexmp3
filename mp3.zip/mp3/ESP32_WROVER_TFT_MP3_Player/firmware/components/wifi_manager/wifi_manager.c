#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "wifi_manager.h"

static const char *TAG = "WIFI_MGR";

static wifi_state_t s_wifi_state = WIFI_STATE_DISCONNECTED;
static char s_connected_ssid[33] = "Disconnected";
static int8_t s_rssi = 0;

static void wifi_event_handler(void* arg, esp_event_base_t event_base,
                                int32_t event_id, void* event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        ESP_LOGI(TAG, "Wi-Fi Station started");
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        s_wifi_state = WIFI_STATE_DISCONNECTED;
        strcpy(s_connected_ssid, "Disconnected");
        ESP_LOGI(TAG, "Wi-Fi disconnected");
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        s_wifi_state = WIFI_STATE_CONNECTED;
        ESP_LOGI(TAG, "Wi-Fi Got IP: " IPSTR, IP2STR(&event->ip_info.ip));
    }
}

esp_err_t wifi_manager_init(void)
{
    ESP_LOGI(TAG, "Initializing Wi-Fi Subsystem...");

    esp_netif_init();
    esp_event_loop_create_default();
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_err_t ret = esp_wifi_init(&cfg);
    if (ret != ESP_OK) return ret;

    esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL);
    esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL, NULL);

    esp_wifi_set_mode(WIFI_MODE_STA);
    esp_wifi_start();

    s_wifi_state = WIFI_STATE_DISCONNECTED;
    ESP_LOGI(TAG, "Wi-Fi initialized in Station Mode");
    return ESP_OK;
}

int wifi_manager_scan(void)
{
    ESP_LOGI(TAG, "Starting Wi-Fi network scan...");
    s_wifi_state = WIFI_STATE_SCANNING;

    wifi_scan_config_t scan_config = {
        .ssid = 0,
        .bssid = 0,
        .channel = 0,
        .show_hidden = true
    };
    esp_wifi_scan_start(&scan_config, true);

    uint16_t ap_count = 0;
    esp_wifi_scan_get_ap_num(&ap_count);
    ESP_LOGI(TAG, "Wi-Fi scan completed. Found %u APs.", ap_count);

    s_wifi_state = WIFI_STATE_DISCONNECTED;
    return ap_count;
}

esp_err_t wifi_manager_connect(const char *ssid, const char *password)
{
    if (!ssid) return ESP_ERR_INVALID_ARG;
    ESP_LOGI(TAG, "Connecting to Wi-Fi SSID '%s'...", ssid);
    s_wifi_state = WIFI_STATE_CONNECTING;

    wifi_config_t wifi_config;
    memset(&wifi_config, 0, sizeof(wifi_config));
    strncpy((char*)wifi_config.sta.ssid, ssid, sizeof(wifi_config.sta.ssid) - 1);
    if (password) {
        strncpy((char*)wifi_config.sta.password, password, sizeof(wifi_config.sta.password) - 1);
    }

    esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    strncpy(s_connected_ssid, ssid, sizeof(s_connected_ssid) - 1);
    return esp_wifi_connect();
}

void wifi_manager_disconnect(void)
{
    esp_wifi_disconnect();
    s_wifi_state = WIFI_STATE_DISCONNECTED;
    strcpy(s_connected_ssid, "Disconnected");
}

wifi_state_t wifi_manager_get_state(void)
{
    return s_wifi_state;
}

bool wifi_manager_is_connected(void)
{
    return (s_wifi_state == WIFI_STATE_CONNECTED);
}

const char* wifi_manager_get_ssid(void)
{
    return s_connected_ssid;
}

int8_t wifi_manager_get_rssi(void)
{
    if (s_wifi_state == WIFI_STATE_CONNECTED) {
        wifi_ap_record_t ap_info;
        if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {
            s_rssi = ap_info.rssi;
        }
    }
    return s_rssi;
}
