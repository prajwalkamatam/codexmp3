#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    WIFI_STATE_DISCONNECTED,
    WIFI_STATE_SCANNING,
    WIFI_STATE_CONNECTING,
    WIFI_STATE_CONNECTED,
    WIFI_STATE_ERROR
} wifi_state_t;

/**
 * @brief Initialize Wi-Fi Station stack and event loop.
 * @return ESP_OK on success.
 */
esp_err_t wifi_manager_init(void);

/**
 * @brief Scan for available 2.4 GHz Wi-Fi access points.
 * @return Number of networks found.
 */
int wifi_manager_scan(void);

/**
 * @brief Connect to Wi-Fi access point with SSID and password.
 * @param ssid Network SSID.
 * @param password Network WPA2/WPA3 password.
 * @return ESP_OK on success.
 */
esp_err_t wifi_manager_connect(const char *ssid, const char *password);

/**
 * @brief Disconnect from Wi-Fi.
 */
void wifi_manager_disconnect(void);

/**
 * @brief Get current Wi-Fi connection state.
 * @return Active state.
 */
wifi_state_t wifi_manager_get_state(void);

/**
 * @brief Check if Wi-Fi has acquired an IP address and is connected to internet.
 * @return True if connected.
 */
bool wifi_manager_is_connected(void);

/**
 * @brief Get currently connected SSID.
 * @return SSID string or "Disconnected".
 */
const char* wifi_manager_get_ssid(void);

/**
 * @brief Get Wi-Fi RSSI signal strength in dBm.
 * @return Signal strength (e.g. -65 dBm).
 */
int8_t wifi_manager_get_rssi(void);

#ifdef __cplusplus
}
#endif

#endif // WIFI_MANAGER_H
