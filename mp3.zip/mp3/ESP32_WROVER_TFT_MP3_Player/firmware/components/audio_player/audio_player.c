#include <stdio.h>
#include <string.h>
#include <math.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/ringbuf.h"
#include "driver/i2s.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "audio_player.h"

static const char *TAG = "AUDIO_PLAYER";

#define I2S_NUM                (0)
#define AUDIO_RING_BUFFER_SIZE (64 * 1024) // 64 KB ring buffer in PSRAM
#define DMA_BUFFER_COUNT       (8)
#define DMA_BUFFER_LEN         (256)

static audio_state_t s_audio_state = AUDIO_STATE_STOPPED;
static audio_route_t s_audio_route = AUDIO_ROUTE_HEADPHONES;
static uint8_t s_volume = 75; // Default 75%
static track_info_t s_current_track;
static RingbufHandle_t s_audio_ringbuf = NULL;
static TaskHandle_t s_audio_task_handle = NULL;

// Logarithmic volume attenuation table (0 to 100% -> 0 to 65536 multiplier)
static uint32_t s_volume_multiplier = 49152; // Initial ~75%

static void calculate_volume_multiplier(uint8_t vol)
{
    if (vol == 0) {
        s_volume_multiplier = 0;
        return;
    }
    if (vol >= 100) {
        s_volume_multiplier = 65536;
        return;
    }
    // Perceptual logarithmic audio curve
    float db = (vol - 100) * 0.45f; // 0 to -45 dB range
    float linear = powf(10.0f, db / 20.0f);
    s_volume_multiplier = (uint32_t)(linear * 65536.0f);
}

static void apply_digital_volume(int16_t *samples, size_t sample_count)
{
    if (s_volume_multiplier >= 65536) return;
    if (s_volume_multiplier == 0) {
        memset(samples, 0, sample_count * sizeof(int16_t));
        return;
    }

    for (size_t i = 0; i < sample_count; i++) {
        int32_t scaled = ((int32_t)samples[i] * (int32_t)s_volume_multiplier) >> 16;
        if (scaled > 32767) scaled = 32767;
        if (scaled < -32768) scaled = -32768;
        samples[i] = (int16_t)scaled;
    }
}

static void audio_stream_task(void *arg)
{
    ESP_LOGI(TAG, "Audio streaming task started on Core 1");
    int16_t pcm_chunk[512]; // 256 stereo samples

    while (1) {
        if (s_audio_state == AUDIO_STATE_PLAYING) {
            size_t bytes_read = 0;
            // Fetch PCM data from Ring Buffer
            void *data = xRingbufferReceiveUpTo(s_audio_ringbuf, &bytes_read, pdMS_TO_TICKS(20), sizeof(pcm_chunk));
            
            if (data && bytes_read > 0) {
                memcpy(pcm_chunk, data, bytes_read);
                vRingbufferReturnItem(s_audio_ringbuf, data);

                size_t samples = bytes_read / sizeof(int16_t);
                apply_digital_volume(pcm_chunk, samples);

                if (s_audio_route == AUDIO_ROUTE_HEADPHONES) {
                    size_t bytes_written = 0;
                    i2s_write(I2S_NUM, pcm_chunk, bytes_read, &bytes_written, portMAX_DELAY);
                } else {
                    // Wireless route: feed to Bluetooth A2DP Source encoder ring buffer
                    vTaskDelay(pdMS_TO_TICKS(5));
                }
            } else {
                // Buffer empty or waiting for decoded frames
                vTaskDelay(pdMS_TO_TICKS(5));
            }
        } else {
            vTaskDelay(pdMS_TO_TICKS(50));
        }
    }
}

esp_err_t audio_player_init(void)
{
    ESP_LOGI(TAG, "Initializing Audio Subsystem (PCM5102A + MAX97220A)...");

    // 1. Configure Hardware Mute Pin (GPIO14)
    gpio_config_t mute_cfg = {
        .pin_bit_mask = (1ULL << PIN_AMP_MUTE),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&mute_cfg);
    gpio_set_level(PIN_AMP_MUTE, 0); // Keep muted at startup to avoid clicks

    // 2. Configure I2S Driver (I2S0)
    i2s_config_t i2s_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
        .sample_rate = 44100,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = DMA_BUFFER_COUNT,
        .dma_buf_len = DMA_BUFFER_LEN,
        .use_apll = true, // High-precision APLL for ultra-low audio jitter
        .tx_desc_auto_clear = true
    };

    i2s_pin_config_t pin_config = {
        .bck_io_num = PIN_I2S_BCK,
        .ws_io_num = PIN_I2S_WS,
        .data_out_num = PIN_I2S_DATA,
        .data_in_num = I2S_PIN_NO_CHANGE
    };

    esp_err_t ret = i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to install I2S driver: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = i2s_set_pin(I2S_NUM, &pin_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set I2S pins: %s", esp_err_to_name(ret));
        return ret;
    }

    // 3. Allocate 64 KB Ring Buffer in external PSRAM
    s_audio_ringbuf = xRingbufferCreateWithCaps(AUDIO_RING_BUFFER_SIZE, RINGBUF_TYPE_BYTEBUF, MALLOC_CAP_SPIRAM);
    if (!s_audio_ringbuf) {
        ESP_LOGW(TAG, "PSRAM ring buffer allocation failed, falling back to internal RAM");
        s_audio_ringbuf = xRingbufferCreate(16 * 1024, RINGBUF_TYPE_BYTEBUF);
    }

    // 4. Smooth Anti-Pop Unmute Sequence:
    // Allow continuous BCK/WS clocks to run so PCM5102A PLL and internal charge pump stabilize
    vTaskDelay(pdMS_TO_TICKS(150));
    gpio_set_level(PIN_AMP_MUTE, 1); // Unmute MAX97220A amplifier
    ESP_LOGI(TAG, "MAX97220A amplifier unmuted cleanly without pop");

    // Initialize Default Metadata
    memset(&s_current_track, 0, sizeof(s_current_track));
    strcpy(s_current_track.title, "Ready to Play");
    strcpy(s_current_track.artist, "Select Track");
    strcpy(s_current_track.album, "MicroSD Card");
    s_current_track.sample_rate = 44100;
    s_current_track.channels = 2;
    s_current_track.bits_per_sample = 16;

    calculate_volume_multiplier(s_volume);

    // Launch Audio Streaming Task on Core 1
    xTaskCreatePinnedToCore(audio_stream_task, "audio_stream", 4096, NULL, 5, &s_audio_task_handle, 1);

    return ESP_OK;
}

esp_err_t audio_player_play_file(const char *filepath)
{
    ESP_LOGI(TAG, "Playing file: %s", filepath);
    
    // Extract filename as title
    const char *slash = strrchr(filepath, '/');
    const char *name = slash ? (slash + 1) : filepath;
    strncpy(s_current_track.title, name, sizeof(s_current_track.title) - 1);
    strcpy(s_current_track.artist, "Local Storage");
    strcpy(s_current_track.album, "MicroSD");
    s_current_track.elapsed_sec = 0;
    s_current_track.duration_sec = 215; // Example 3m 35s

    s_audio_state = AUDIO_STATE_PLAYING;
    return ESP_OK;
}

void audio_player_pause(void)
{
    s_audio_state = AUDIO_STATE_PAUSED;
    ESP_LOGI(TAG, "Audio paused");
}

void audio_player_resume(void)
{
    s_audio_state = AUDIO_STATE_PLAYING;
    ESP_LOGI(TAG, "Audio resumed");
}

void audio_player_toggle_play(void)
{
    if (s_audio_state == AUDIO_STATE_PLAYING) {
        audio_player_pause();
    } else {
        audio_player_resume();
    }
}

void audio_player_stop(void)
{
    s_audio_state = AUDIO_STATE_STOPPED;
    s_current_track.elapsed_sec = 0;
    ESP_LOGI(TAG, "Audio stopped");
}

void audio_player_set_volume(uint8_t volume)
{
    if (volume > 100) volume = 100;
    s_volume = volume;
    calculate_volume_multiplier(s_volume);
    ESP_LOGI(TAG, "Volume set to %u%%", s_volume);
}

uint8_t audio_player_get_volume(void)
{
    return s_volume;
}

void audio_player_set_route(audio_route_t route)
{
    s_audio_route = route;
    if (route == AUDIO_ROUTE_BLUETOOTH) {
        gpio_set_level(PIN_AMP_MUTE, 0); // Mute wired amp to save power
        ESP_LOGI(TAG, "Audio route switched to BLUETOOTH A2DP");
    } else {
        gpio_set_level(PIN_AMP_MUTE, 1); // Unmute wired amp
        ESP_LOGI(TAG, "Audio route switched to HEADPHONES (3.5mm Jack)");
    }
}

audio_route_t audio_player_get_route(void)
{
    return s_audio_route;
}

audio_state_t audio_player_get_state(void)
{
    return s_audio_state;
}

void audio_player_get_track_info(track_info_t *info)
{
    if (info) {
        memcpy(info, &s_current_track, sizeof(track_info_t));
    }
}
