#ifndef AUDIO_PLAYER_H
#define AUDIO_PLAYER_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// Audio Hardware Pinout
#define PIN_I2S_BCK       26
#define PIN_I2S_WS        25
#define PIN_I2S_DATA      27
#define PIN_AMP_MUTE      14 // Active High Enable, Active Low Mute

// Audio State
typedef enum {
    AUDIO_STATE_STOPPED,
    AUDIO_STATE_PLAYING,
    AUDIO_STATE_PAUSED
} audio_state_t;

// Audio Output Route
typedef enum {
    AUDIO_ROUTE_HEADPHONES, // Wired 3.5mm Jack (PCM5102A + MAX97220A)
    AUDIO_ROUTE_BLUETOOTH   // Wireless Bluetooth A2DP Source
} audio_route_t;

// Track Metadata Structure
typedef struct {
    char title[64];
    char artist[64];
    char album[64];
    uint32_t duration_sec;
    uint32_t elapsed_sec;
    uint32_t sample_rate;
    uint8_t channels;
    uint8_t bits_per_sample;
} track_info_t;

/**
 * @brief Initialize Audio Subsystem (I2S driver, hardware muting, PSRAM ring buffer).
 * @return ESP_OK on success.
 */
esp_err_t audio_player_init(void);

/**
 * @brief Start playback of an MP3 file from MicroSD storage.
 * @param filepath Full absolute path to file (e.g. "/sdcard/music/song.mp3").
 * @return ESP_OK on success.
 */
esp_err_t audio_player_play_file(const char *filepath);

/**
 * @brief Pause audio playback.
 */
void audio_player_pause(void);

/**
 * @brief Resume audio playback.
 */
void audio_player_resume(void);

/**
 * @brief Toggle between Play and Pause.
 */
void audio_player_toggle_play(void);

/**
 * @brief Stop audio playback completely.
 */
void audio_player_stop(void);

/**
 * @brief Set digital volume level (0 to 100).
 * @param volume Volume percentage (0 = Mute, 100 = 0 dBFS full scale).
 */
void audio_player_set_volume(uint8_t volume);

/**
 * @brief Get current digital volume level (0 to 100).
 * @return Current volume.
 */
uint8_t audio_player_get_volume(void);

/**
 * @brief Switch audio output destination.
 * @param route AUDIO_ROUTE_HEADPHONES or AUDIO_ROUTE_BLUETOOTH.
 */
void audio_player_set_route(audio_route_t route);

/**
 * @brief Get current active audio route.
 * @return Active route.
 */
audio_route_t audio_player_get_route(void);

/**
 * @brief Get current audio playback state.
 * @return Current state.
 */
audio_state_t audio_player_get_state(void);

/**
 * @brief Get metadata for current active track.
 * @param info Pointer to track_info_t structure to receive data.
 */
void audio_player_get_track_info(track_info_t *info);

#ifdef __cplusplus
}
#endif

#endif // AUDIO_PLAYER_H
