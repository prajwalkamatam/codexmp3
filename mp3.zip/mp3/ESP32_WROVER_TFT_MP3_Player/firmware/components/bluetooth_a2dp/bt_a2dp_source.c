#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_bt_device.h"
#include "esp_gap_bt_api.h"
#include "esp_a2dp_api.h"
#include "bt_a2dp_source.h"

static const char *TAG = "BT_A2DP_SRC";

static bt_a2dp_state_t s_bt_state = BT_A2DP_STATE_IDLE;
static char s_connected_device_name[32] = "None";
static uint8_t s_peer_bda[6] = {0};

static void bt_a2d_source_cb(esp_a2d_cb_event_t event, esp_a2d_cb_param_t *param)
{
    switch (event) {
        case ESP_A2D_CONNECTION_STATE_EVT: {
            esp_a2d_cb_param_t *a2d = (esp_a2d_cb_param_t *)param;
            if (a2d->conn_stat.state == ESP_A2D_CONNECTION_STATE_CONNECTED) {
                s_bt_state = BT_A2DP_STATE_CONNECTED;
                memcpy(s_peer_bda, a2d->conn_stat.bda, 6);
                snprintf(s_connected_device_name, sizeof(s_connected_device_name), "TWS Earbuds");
                ESP_LOGI(TAG, "A2DP Connected to [%02x:%02x:%02x:%02x:%02x:%02x]",
                         s_peer_bda[0], s_peer_bda[1], s_peer_bda[2], s_peer_bda[3], s_peer_bda[4], s_peer_bda[5]);
            } else if (a2d->conn_stat.state == ESP_A2D_CONNECTION_STATE_DISCONNECTED) {
                s_bt_state = BT_A2DP_STATE_DISCONNECTED;
                strcpy(s_connected_device_name, "None");
                ESP_LOGI(TAG, "A2DP Disconnected");
            }
            break;
        }
        case ESP_A2D_AUDIO_STATE_EVT: {
            esp_a2d_cb_param_t *a2d = (esp_a2d_cb_param_t *)param;
            if (a2d->audio_stat.state == ESP_A2D_AUDIO_STATE_STARTED) {
                s_bt_state = BT_A2DP_STATE_STREAMING;
                ESP_LOGI(TAG, "A2DP Audio Streaming active");
            } else {
                if (s_bt_state == BT_A2DP_STATE_STREAMING) {
                    s_bt_state = BT_A2DP_STATE_CONNECTED;
                }
            }
            break;
        }
        default:
            break;
    }
}

static int32_t bt_a2d_data_cb(uint8_t *data, int32_t len)
{
    if (len <= 0 || !data) return 0;
    // In actual streaming, read PCM samples from audio player ring buffer
    memset(data, 0, len);
    return len;
}

esp_err_t bt_a2dp_source_init(void)
{
    ESP_LOGI(TAG, "Initializing Bluetooth Classic A2DP Source Stack...");

    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    esp_err_t ret = esp_bt_controller_init(&bt_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize BT controller: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_bt_controller_enable(ESP_BT_MODE_BTDM);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to enable BT controller: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_bluedroid_init();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize Bluedroid: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_bluedroid_enable();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to enable Bluedroid: %s", esp_err_to_name(ret));
        return ret;
    }

    // Set friendly Bluetooth Device Name
    esp_bt_dev_set_device_name("ESP32_Smart_MP3");

    // Initialize A2DP Source
    esp_a2d_register_callback(&bt_a2d_source_cb);
    esp_a2d_source_register_data_callback(&bt_a2d_data_cb);
    esp_a2d_source_init();

    s_bt_state = BT_A2DP_STATE_IDLE;
    ESP_LOGI(TAG, "Bluetooth A2DP Source initialized successfully");
    return ESP_OK;
}

void bt_a2dp_source_start_discovery(uint8_t duration_sec)
{
    ESP_LOGI(TAG, "Starting Bluetooth device discovery for %u seconds...", duration_sec);
    s_bt_state = BT_A2DP_STATE_DISCOVERING;
    esp_bt_gap_start_discovery(ESP_BT_INQ_MODE_GENERAL_INQUIRY, duration_sec, 0);
}

void bt_a2dp_source_connect(const uint8_t *bda)
{
    if (!bda) return;
    memcpy(s_peer_bda, bda, 6);
    s_bt_state = BT_A2DP_STATE_CONNECTING;
    ESP_LOGI(TAG, "Connecting to A2DP sink [%02x:%02x:%02x:%02x:%02x:%02x]...",
             bda[0], bda[1], bda[2], bda[3], bda[4], bda[5]);
    esp_a2d_source_connect(s_peer_bda);
}

void bt_a2dp_source_disconnect(void)
{
    if (s_bt_state == BT_A2DP_STATE_CONNECTED || s_bt_state == BT_A2DP_STATE_STREAMING) {
        ESP_LOGI(TAG, "Disconnecting A2DP source...");
        esp_a2d_source_disconnect(s_peer_bda);
    }
}

bt_a2dp_state_t bt_a2dp_source_get_state(void)
{
    return s_bt_state;
}

const char* bt_a2dp_source_get_connected_name(void)
{
    return s_connected_device_name;
}

bool bt_a2dp_source_is_connected(void)
{
    return (s_bt_state == BT_A2DP_STATE_CONNECTED || s_bt_state == BT_A2DP_STATE_STREAMING);
}
