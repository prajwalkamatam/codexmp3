#ifndef BT_A2DP_SOURCE_H
#define BT_A2DP_SOURCE_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    BT_A2DP_STATE_IDLE,
    BT_A2DP_STATE_DISCOVERING,
    BT_A2DP_STATE_CONNECTING,
    BT_A2DP_STATE_CONNECTED,
    BT_A2DP_STATE_STREAMING,
    BT_A2DP_STATE_DISCONNECTED
} bt_a2dp_state_t;

typedef struct {
    char name[32];
    uint8_t bda[6];
    int rssi;
} bt_device_info_t;

/**
 * @brief Initialize Bluetooth Controller and Bluedroid A2DP Source stack.
 * @return ESP_OK on success.
 */
esp_err_t bt_a2dp_source_init(void);

/**
 * @brief Start inquiry/discovery for nearby Bluetooth A2DP audio sinks (earbuds/speakers).
 * @param duration_sec Discovery timeout in seconds (e.g. 10s).
 */
void bt_a2dp_source_start_discovery(uint8_t duration_sec);

/**
 * @brief Connect to a specific Bluetooth audio sink device by its MAC address.
 * @param bda 6-byte Bluetooth Device Address.
 */
void bt_a2dp_source_connect(const uint8_t *bda);

/**
 * @brief Disconnect from current Bluetooth audio sink.
 */
void bt_a2dp_source_disconnect(void);

/**
 * @brief Get current Bluetooth A2DP connection state.
 * @return Current state.
 */
bt_a2dp_state_t bt_a2dp_source_get_state(void);

/**
 * @brief Get name of connected Bluetooth audio sink.
 * @return Device name string or "None".
 */
const char* bt_a2dp_source_get_connected_name(void);

/**
 * @brief Check if Bluetooth audio sink is currently connected.
 * @return True if connected.
 */
bool bt_a2dp_source_is_connected(void);

#ifdef __cplusplus
}
#endif

#endif // BT_A2DP_SOURCE_H
