#include <stdio.h>
#include <string.h>
#include <sys/unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"
#include "sd_card.h"

static const char *TAG = "SD_CARD";

static sdmmc_card_t *s_card = NULL;
static bool s_is_mounted = false;
static file_item_t s_track_list[MAX_TRACKS_STORED];
static int s_track_count = 0;

esp_err_t sd_card_init(void)
{
    ESP_LOGI(TAG, "Mounting MicroSD card over SPI at %s...", MOUNT_POINT);

    esp_vfs_fat_sdmmc_mount_config_t mount_config = {
        .format_if_mount_failed = false,
        .max_files = 5,
        .allocation_unit_size = 16 * 1024
    };

    // SDSPI Host configuration
    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.max_freq_khz = 20000; // 20 MHz SPI clock for reliable FAT32 streaming

    sdspi_device_config_t slot_config = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_config.gpio_cs = PIN_SD_CS;
    slot_config.host_id = SPI2_HOST;

    esp_err_t ret = esp_vfs_fat_sdspi_mount(MOUNT_POINT, &host, &slot_config, &mount_config, &s_card);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to mount FATFS filesystem: %s", esp_err_to_name(ret));
        s_is_mounted = false;
        return ret;
    }

    s_is_mounted = true;
    sdmmc_card_print_info(stdout, s_card);
    ESP_LOGI(TAG, "MicroSD card mounted successfully!");

    // Scan for files automatically
    sd_card_scan_music_files(MOUNT_POINT);

    return ESP_OK;
}

void sd_card_unmount(void)
{
    if (s_is_mounted) {
        esp_vfs_fat_sdcard_unmount(MOUNT_POINT, s_card);
        s_is_mounted = false;
        s_card = NULL;
        ESP_LOGI(TAG, "MicroSD unmounted successfully");
    }
}

bool sd_card_is_mounted(void)
{
    return s_is_mounted;
}

static bool is_mp3_file(const char *name)
{
    size_t len = strlen(name);
    if (len < 4) return false;
    const char *ext = name + len - 4;
    return (strcasecmp(ext, ".mp3") == 0);
}

int sd_card_scan_music_files(const char *path)
{
    if (!s_is_mounted) return 0;

    ESP_LOGI(TAG, "Scanning directory '%s' for MP3 music files...", path);
    DIR *dir = opendir(path);
    if (!dir) {
        ESP_LOGE(TAG, "Cannot open directory: %s", path);
        return 0;
    }

    s_track_count = 0;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL && s_track_count < MAX_TRACKS_STORED) {
        if (entry->d_type == DT_REG && is_mp3_file(entry->d_name)) {
            file_item_t *item = &s_track_list[s_track_count];
            snprintf(item->filepath, sizeof(item->filepath), "%s/%s", path, entry->d_name);
            strncpy(item->filename, entry->d_name, sizeof(item->filename) - 1);
            
            struct stat st;
            if (stat(item->filepath, &st) == 0) {
                item->filesize = (uint32_t)st.st_size;
            } else {
                item->filesize = 0;
            }

            ESP_LOGI(TAG, "Found track [%d]: %s (%u KB)", s_track_count + 1, item->filename, item->filesize / 1024);
            s_track_count++;
        }
    }
    closedir(dir);

    ESP_LOGI(TAG, "Scan completed. Found %d MP3 tracks.", s_track_count);
    return s_track_count;
}

int sd_card_get_track_count(void)
{
    return s_track_count;
}

const file_item_t* sd_card_get_track(int index)
{
    if (index >= 0 && index < s_track_count) {
        return &s_track_list[index];
    }
    return NULL;
}
