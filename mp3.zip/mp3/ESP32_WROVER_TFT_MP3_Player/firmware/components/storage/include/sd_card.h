#ifndef SD_CARD_H
#define SD_CARD_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MOUNT_POINT "/sdcard"

#define PIN_SD_MISO   19
#define PIN_SD_MOSI   23
#define PIN_SD_SCLK   18
#define PIN_SD_CS     13

#define MAX_TRACKS_STORED 128

typedef struct {
    char filepath[128];
    char filename[64];
    uint32_t filesize;
} file_item_t;

/**
 * @brief Initialize SPI bus and mount MicroSD card filesystem at /sdcard.
 * @return ESP_OK on success.
 */
esp_err_t sd_card_init(void);

/**
 * @brief Unmount MicroSD card filesystem safely.
 */
void sd_card_unmount(void);

/**
 * @brief Check if MicroSD card is currently mounted.
 * @return True if mounted.
 */
bool sd_card_is_mounted(void);

/**
 * @brief Scan MicroSD card directory recursively for MP3 audio files.
 * @param path Directory path to scan (e.g. "/sdcard" or "/sdcard/music").
 * @return Number of MP3 tracks discovered.
 */
int sd_card_scan_music_files(const char *path);

/**
 * @brief Get total number of indexed tracks.
 * @return Track count.
 */
int sd_card_get_track_count(void);

/**
 * @brief Get track item by index.
 * @param index 0-based index.
 * @return Pointer to file_item_t or NULL if out of bounds.
 */
const file_item_t* sd_card_get_track(int index);

#ifdef __cplusplus
}
#endif

#endif // SD_CARD_H
