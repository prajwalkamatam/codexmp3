#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_sleep.h"
#include "driver/gpio.h"
#include "esp_adc/adc_oneshot.h"
#include "power_manager.h"

static const char *TAG = "PWR_MGR";

static adc_oneshot_unit_handle_t adc1_handle;
static uint16_t s_battery_mv = 3850; // Initial 3.85V nominal
static uint8_t s_battery_pct = 75;

static uint8_t calculate_soc(uint16_t mv)
{
    // Typical LiPo discharge curve
    if (mv >= 4180) return 100;
    if (mv >= 4050) return 90;
    if (mv >= 3950) return 80;
    if (mv >= 3850) return 70;
    if (mv >= 3780) return 60;
    if (mv >= 3730) return 50;
    if (mv >= 3680) return 40;
    if (mv >= 3630) return 30;
    if (mv >= 3570) return 20;
    if (mv >= 3480) return 10;
    if (mv >= 3350) return 5;
    return 0;
}

static void battery_monitor_task(void *arg)
{
    ESP_LOGI(TAG, "Battery voltage monitoring task started on ADC1_CH6");

    while (1) {
        int raw = 0;
        uint32_t sum = 0;
        const int samples = 16;

        for (int i = 0; i < samples; i++) {
            adc_oneshot_read(adc1_handle, ADC_CHANNEL_6, &raw);
            sum += raw;
            vTaskDelay(pdMS_TO_TICKS(5));
        }

        uint32_t avg_raw = sum / samples;
        // ADC 12-bit (4095 = ~2450 mV at 11 dB attenuation)
        // With 100k/100k divider (ratio 0.5): V_BAT = V_ADC * 2.0
        uint32_t adc_mv = (avg_raw * 2450) / 4095;
        s_battery_mv = (uint16_t)(adc_mv * 2);
        s_battery_pct = calculate_soc(s_battery_mv);

        ESP_LOGD(TAG, "Battery: %u mV (%u%%)", s_battery_mv, s_battery_pct);

        vTaskDelay(pdMS_TO_TICKS(3000)); // Sample every 3 seconds
    }
}

esp_err_t power_manager_init(void)
{
    ESP_LOGI(TAG, "Initializing Battery ADC & Power Manager...");

    adc_oneshot_unit_init_cfg_t init_config1 = {
        .unit_id = ADC_UNIT_1,
        .ulp_mode = ADC_ULP_MODE_DISABLE,
    };
    esp_err_t ret = adc_oneshot_new_unit(&init_config1, &adc1_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize ADC1 unit: %s", esp_err_to_name(ret));
        return ret;
    }

    adc_oneshot_chan_cfg_t config = {
        .bitwidth = ADC_BITWIDTH_12,
        .atten = ADC_ATTEN_DB_11, // 0 to ~3.1V input range
    };
    ret = adc_oneshot_config_channel(adc1_handle, ADC_CHANNEL_6, &config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to configure ADC channel 6: %s", esp_err_to_name(ret));
        return ret;
    }

    // Launch monitoring task
    xTaskCreatePinnedToCore(battery_monitor_task, "batt_monitor", 2048, NULL, 2, NULL, 0);

    return ESP_OK;
}

uint16_t power_manager_get_battery_voltage_mv(void)
{
    return s_battery_mv;
}

uint8_t power_manager_get_battery_percentage(void)
{
    return s_battery_pct;
}

void power_manager_enter_deep_sleep(void)
{
    ESP_LOGI(TAG, "Entering low-power deep sleep mode...");
    // Configure Power Button (GPIO36) as RTC wake-up source (Level 0 = LOW / Pressed)
    esp_sleep_enable_ext0_wakeup((gpio_num_t)36, 0);
    vTaskDelay(pdMS_TO_TICKS(50));
    esp_deep_sleep_start();
}
