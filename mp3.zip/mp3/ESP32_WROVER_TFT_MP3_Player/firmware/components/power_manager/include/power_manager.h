#ifndef POWER_MANAGER_H
#define POWER_MANAGER_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PIN_BATT_SENSE    34 // ADC1_CH6

/**
 * @brief Initialize Battery ADC measurement and power management unit.
 * @return ESP_OK on success.
 */
esp_err_t power_manager_init(void);

/**
 * @brief Get filtered battery terminal voltage in millivolts.
 * @return Battery voltage (e.g. 3700 mV for 3.70 V).
 */
uint16_t power_manager_get_battery_voltage_mv(void);

/**
 * @brief Get battery State-of-Charge (SoC) percentage (0% to 100%).
 * @return Percentage 0 - 100.
 */
uint8_t power_manager_get_battery_percentage(void);

/**
 * @brief Enter low-power deep sleep mode with Power button as RTC wakeup trigger.
 */
void power_manager_enter_deep_sleep(void);

#ifdef __cplusplus
}
#endif

#endif // POWER_MANAGER_H
