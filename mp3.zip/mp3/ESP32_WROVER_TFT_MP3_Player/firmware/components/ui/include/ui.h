#ifndef UI_H
#define UI_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SCREEN_NOW_PLAYING,
    SCREEN_MUSIC_LIBRARY,
    SCREEN_BLUETOOTH,
    SCREEN_WIFI,
    SCREEN_SETTINGS,
    SCREEN_DEVICE_INFO
} ui_screen_t;

/**
 * @brief Initialize Graphical User Interface and display elements.
 * @return ESP_OK on success.
 */
esp_err_t ui_init(void);

/**
 * @brief Switch active UI screen.
 * @param screen Target screen enum.
 */
void ui_switch_screen(ui_screen_t screen);

/**
 * @brief Cycle to next screen (Mode button trigger).
 */
void ui_next_screen(void);

/**
 * @brief Main UI rendering tick function (called periodically by UI task).
 */
void ui_render_tick(void);

#ifdef __cplusplus
}
#endif

#endif // UI_H
