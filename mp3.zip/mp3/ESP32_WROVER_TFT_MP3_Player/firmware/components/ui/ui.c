#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "st7789.h"
#include "audio_player.h"
#include "bluetooth_a2dp.h"
#include "power_manager.h"
#include "wifi_manager.h"
#include "sd_card.h"
#include "ui.h"

static const char *TAG = "UI";

static ui_screen_t s_current_screen = SCREEN_NOW_PLAYING;
static uint32_t s_frame_count = 0;

static void render_status_bar(void)
{
    // Status Bar Background (Top 24 pixels)
    st7789_fill_rect(0, 0, 240, 24, COLOR_NAVY);

    // Battery Indicator (Right side: X=190 to 235)
    uint8_t batt_pct = power_manager_get_battery_percentage();
    uint16_t batt_color = (batt_pct > 20) ? COLOR_GREEN : COLOR_RED;
    
    // Battery shell
    st7789_fill_rect(200, 6, 26, 12, COLOR_WHITE);
    st7789_fill_rect(226, 9, 3, 6, COLOR_WHITE); // Battery nipple
    st7789_fill_rect(202, 8, 22, 8, COLOR_BLACK); // Inner hollow
    // Battery fill
    int fill_w = (batt_pct * 20) / 100;
    if (fill_w > 0) {
        st7789_fill_rect(203, 9, fill_w, 6, batt_color);
    }

    // Audio Output Mode Indicator (Left side: X=8)
    audio_route_t route = audio_player_get_route();
    if (route == AUDIO_ROUTE_BLUETOOTH) {
        bool bt_conn = bt_a2dp_source_is_connected();
        st7789_fill_rect(8, 6, 12, 12, bt_conn ? COLOR_CYAN : COLOR_DARKGREY);
    } else {
        // Wired 3.5mm Headphone icon indicator
        st7789_fill_rect(8, 6, 12, 12, COLOR_GREENYELLOW);
    }

    // Wi-Fi Indicator (X=30)
    bool wifi_conn = wifi_manager_is_connected();
    st7789_fill_rect(30, 6, 10, 12, wifi_conn ? COLOR_GREEN : COLOR_DARKGREY);

    // Separator line
    st7789_fill_rect(0, 24, 240, 1, COLOR_LIGHTGREY);
}

static void render_now_playing_screen(void)
{
    track_info_t track;
    audio_player_get_track_info(&track);
    audio_state_t state = audio_player_get_state();

    // 1. Album Artwork Box (100x100 centered: X=70, Y=35 to 135)
    st7789_fill_rect(68, 33, 104, 104, COLOR_LIGHTGREY);
    st7789_fill_rect(70, 35, 100, 100, COLOR_BG_DARK);
    // Dynamic graphical visualizer bars inside album box
    for (int b = 0; b < 8; b++) {
        int bar_h = 10 + ((s_frame_count * (b + 3) * 7) % 65);
        if (state != AUDIO_STATE_PLAYING) bar_h = 4;
        st7789_fill_rect(76 + b * 11, 130 - bar_h, 8, bar_h, COLOR_ACCENT_BLUE);
    }

    // 2. Track Title Box (X=10, Y=145)
    st7789_fill_rect(10, 142, 220, 18, COLOR_BLACK);
    // Draw Title Accent Box
    st7789_fill_rect(15, 148, 4, 12, COLOR_GREEN);

    // 3. Artist Box (X=10, Y=165)
    st7789_fill_rect(10, 162, 220, 14, COLOR_BLACK);

    // 4. Playback Progress Bar (X=20, Y=185, W=200, H=6)
    st7789_fill_rect(20, 185, 200, 6, COLOR_DARKGREY);
    uint32_t progress_w = 0;
    if (track.duration_sec > 0) {
        progress_w = (track.elapsed_sec * 200) / track.duration_sec;
    }
    if (progress_w > 200) progress_w = 200;
    st7789_fill_rect(20, 185, progress_w, 6, COLOR_ACCENT_BLUE);

    // 5. Volume Bar (Bottom: X=20, Y=205, W=200, H=4)
    uint8_t vol = audio_player_get_volume();
    st7789_fill_rect(20, 205, 200, 4, COLOR_DARKGREY);
    st7789_fill_rect(20, 205, (vol * 2), 4, COLOR_ORANGE);

    // 6. Play / Pause State Icon (Centered: X=112, Y=216)
    if (state == AUDIO_STATE_PLAYING) {
        // Double pause bars
        st7789_fill_rect(112, 218, 5, 14, COLOR_WHITE);
        st7789_fill_rect(123, 218, 5, 14, COLOR_WHITE);
    } else {
        // Play triangle
        for (int i = 0; i < 14; i++) {
            st7789_fill_rect(114 + i/2, 218 + i/2, 2, 14 - i, COLOR_WHITE);
        }
    }
}

static void render_music_library_screen(void)
{
    st7789_fill_rect(0, 25, 240, 215, COLOR_BLACK);
    int count = sd_card_get_track_count();
    
    // Header
    st7789_fill_rect(10, 30, 220, 16, COLOR_NAVY);

    for (int i = 0; i < 6 && i < count; i++) {
        const file_item_t *item = sd_card_get_track(i);
        if (item) {
            int row_y = 55 + i * 28;
            st7789_fill_rect(10, row_y, 220, 24, (i == 0) ? COLOR_ACCENT_BLUE : COLOR_BG_DARK);
            // Track number indicator
            st7789_fill_rect(14, row_y + 4, 16, 16, COLOR_WHITE);
        }
    }
}

static void render_bluetooth_screen(void)
{
    st7789_fill_rect(0, 25, 240, 215, COLOR_BLACK);
    st7789_fill_rect(10, 32, 220, 20, COLOR_NAVY);

    bool connected = bt_a2dp_source_is_connected();
    const char *dev_name = bt_a2dp_source_get_connected_name();

    st7789_fill_rect(15, 65, 210, 45, connected ? COLOR_DARKGREEN : COLOR_BG_DARK);
    st7789_fill_rect(20, 75, 24, 24, COLOR_CYAN); // BT Logo box
}

static void render_wifi_screen(void)
{
    st7789_fill_rect(0, 25, 240, 215, COLOR_BLACK);
    st7789_fill_rect(10, 32, 220, 20, COLOR_NAVY);

    bool connected = wifi_manager_is_connected();
    const char *ssid = wifi_manager_get_ssid();

    st7789_fill_rect(15, 65, 210, 45, connected ? COLOR_DARKGREEN : COLOR_BG_DARK);
}

static void render_device_info_screen(void)
{
    st7789_fill_rect(0, 25, 240, 215, COLOR_BLACK);
    st7789_fill_rect(10, 32, 220, 20, COLOR_NAVY);

    // Technical Specs Cards
    st7789_fill_rect(10, 60, 220, 25, COLOR_BG_DARK);
    st7789_fill_rect(10, 90, 220, 25, COLOR_BG_DARK);
    st7789_fill_rect(10, 120, 220, 25, COLOR_BG_DARK);
    st7789_fill_rect(10, 150, 220, 25, COLOR_BG_DARK);
    st7789_fill_rect(10, 180, 220, 25, COLOR_BG_DARK);
}

void ui_render_tick(void)
{
    s_frame_count++;
    render_status_bar();

    switch (s_current_screen) {
        case SCREEN_NOW_PLAYING:
            render_now_playing_screen();
            break;
        case SCREEN_MUSIC_LIBRARY:
            render_music_library_screen();
            break;
        case SCREEN_BLUETOOTH:
            render_bluetooth_screen();
            break;
        case SCREEN_WIFI:
            render_wifi_screen();
            break;
        case SCREEN_DEVICE_INFO:
        case SCREEN_SETTINGS:
            render_device_info_screen();
            break;
    }
}

void ui_switch_screen(ui_screen_t screen)
{
    s_current_screen = screen;
    st7789_fill_screen(COLOR_BLACK);
    ESP_LOGI(TAG, "Switched to screen: %d", (int)screen);
}

void ui_next_screen(void)
{
    s_current_screen = (ui_screen_t)((s_current_screen + 1) % 6);
    st7789_fill_screen(COLOR_BLACK);
    ESP_LOGI(TAG, "Cycled to next screen: %d", (int)s_current_screen);
}

esp_err_t ui_init(void)
{
    ESP_LOGI(TAG, "Initializing Graphical UI subsystem (240x240 color IPS)...");
    st7789_fill_screen(COLOR_BLACK);
    ui_switch_screen(SCREEN_NOW_PLAYING);
    return ESP_OK;
}
