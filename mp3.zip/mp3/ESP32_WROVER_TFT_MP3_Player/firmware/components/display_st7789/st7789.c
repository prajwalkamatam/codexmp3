#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "esp_log.h"
#include "st7789.h"

static const char *TAG = "ST7789";

static spi_device_handle_t spi_dev;
static uint16_t *line_buffer = NULL;

#define ST7789_CMD_NOP       0x00
#define ST7789_CMD_SWRESET   0x01
#define ST7789_CMD_SLPIN     0x10
#define ST7789_CMD_SLPOUT    0x11
#define ST7789_CMD_NORON     0x13
#define ST7789_CMD_INVOFF    0x20
#define ST7789_CMD_INVON     0x21
#define ST7789_CMD_DISPOFF   0x28
#define ST7789_CMD_DISPON    0x29
#define ST7789_CMD_CASET     0x2A
#define ST7789_CMD_RASET     0x2B
#define ST7789_CMD_RAMWR     0x2C
#define ST7789_CMD_MADCTL    0x36
#define ST7789_CMD_COLMOD    0x3A

#define MADCTL_MY  0x80
#define MADCTL_MX  0x40
#define MADCTL_MV  0x20
#define MADCTL_ML  0x10
#define MADCTL_RGB 0x00
#define MADCTL_BGR 0x08
#define MADCTL_MH  0x04

static void st7789_send_cmd(uint8_t cmd)
{
    gpio_set_level(PIN_TFT_DC, 0); // Command mode
    spi_transaction_t t;
    memset(&t, 0, sizeof(t));
    t.length = 8;
    t.tx_buffer = &cmd;
    spi_device_polling_transmit(spi_dev, &t);
}

static void st7789_send_data(const uint8_t *data, int len)
{
    if (len <= 0) return;
    gpio_set_level(PIN_TFT_DC, 1); // Data mode
    spi_transaction_t t;
    memset(&t, 0, sizeof(t));
    t.length = len * 8;
    t.tx_buffer = data;
    spi_device_polling_transmit(spi_dev, &t);
}

static void st7789_send_data_byte(uint8_t val)
{
    st7789_send_data(&val, 1);
}

static void backlight_pwm_init(void)
{
    ledc_timer_config_t ledc_timer = {
        .speed_mode       = LEDC_LOW_SPEED_MODE,
        .timer_num        = LEDC_TIMER_0,
        .duty_resolution  = LEDC_TIMER_10_BIT,
        .freq_hz          = 5000,
        .clk_cfg          = LEDC_AUTO_CLK
    };
    ledc_timer_config(&ledc_timer);

    ledc_channel_config_t ledc_channel = {
        .speed_mode     = LEDC_LOW_SPEED_MODE,
        .channel        = LEDC_CHANNEL_0,
        .timer_sel      = LEDC_TIMER_0,
        .intr_type      = LEDC_INTR_DISABLE,
        .gpio_num       = PIN_TFT_BL,
        .duty           = 0,
        .hpoint         = 0
    };
    ledc_channel_config(&ledc_channel);
}

void st7789_set_backlight(uint8_t brightness)
{
    if (brightness > 100) brightness = 100;
    uint32_t duty = (brightness * 1023) / 100;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
}

esp_err_t st7789_init(void)
{
    ESP_LOGI(TAG, "Initializing ST7789 IPS 240x240 Display subsystem...");

    // Configure GPIO pins (DC, RST, CS)
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << PIN_TFT_DC) | (1ULL << PIN_TFT_RST) | (1ULL << PIN_TFT_CS),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&io_conf);

    // Initial pin states
    gpio_set_level(PIN_TFT_CS, 0); // Keep CS asserted for single SPI slave or managed by SPI driver
    gpio_set_level(PIN_TFT_DC, 1);

    // Initialize Backlight PWM (Starts at 0% to prevent white flash)
    backlight_pwm_init();
    st7789_set_backlight(0);

    // Hardware Reset Sequence
    gpio_set_level(PIN_TFT_RST, 0);
    vTaskDelay(pdMS_TO_TICKS(50));
    gpio_set_level(PIN_TFT_RST, 1);
    vTaskDelay(pdMS_TO_TICKS(150));

    // Configure SPI Bus
    spi_bus_config_t buscfg = {
        .miso_io_num = -1,
        .mosi_io_num = PIN_TFT_MOSI,
        .sclk_io_num = PIN_TFT_SCLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = ST7789_WIDTH * 40 * sizeof(uint16_t) + 8
    };

    esp_err_t ret = spi_bus_initialize(SPI2_HOST, &buscfg, SPI_DMA_CH_AUTO);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize SPI bus: %s", esp_err_to_name(ret));
        return ret;
    }

    spi_device_interface_config_t devcfg = {
        .clock_speed_hz = 40 * 1000 * 1000, // 40 MHz high-speed SPI
        .mode = 0,                          // SPI mode 0
        .spics_io_num = PIN_TFT_CS,         // CS pin
        .queue_size = 7,
        .flags = SPI_DEVICE_NO_DUMMY
    };

    ret = spi_bus_add_device(SPI2_HOST, &devcfg, &spi_dev);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to add SPI device: %s", esp_err_to_name(ret));
        return ret;
    }

    // Allocate DMA-capable line buffer for drawing operations
    line_buffer = heap_caps_malloc(ST7789_WIDTH * sizeof(uint16_t), MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
    if (!line_buffer) {
        ESP_LOGE(TAG, "Failed to allocate display DMA buffer");
        return ESP_ERR_NO_MEM;
    }

    // ST7789 Controller Initialization Sequence
    st7789_send_cmd(ST7789_CMD_SWRESET);
    vTaskDelay(pdMS_TO_TICKS(150));

    st7789_send_cmd(ST7789_CMD_SLPOUT);
    vTaskDelay(pdMS_TO_TICKS(120));

    st7789_send_cmd(ST7789_CMD_COLMOD);
    st7789_send_data_byte(0x55); // 16-bit RGB565

    st7789_send_cmd(ST7789_CMD_MADCTL);
    st7789_send_data_byte(0x00); // Standard orientation

    st7789_send_cmd(ST7789_CMD_INVON); // Inversion on for IPS panels
    vTaskDelay(pdMS_TO_TICKS(10));

    st7789_send_cmd(ST7789_CMD_NORON);
    vTaskDelay(pdMS_TO_TICKS(10));

    st7789_fill_screen(COLOR_BLACK);

    st7789_send_cmd(ST7789_CMD_DISPON);
    vTaskDelay(pdMS_TO_TICKS(100));

    // Ramp backlight to 80% default brightness
    st7789_set_backlight(80);

    ESP_LOGI(TAG, "ST7789 display initialized successfully (240x240 RGB565)");
    return ESP_OK;
}

void st7789_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
    // Clamp coordinates
    if (x1 >= ST7789_WIDTH) x1 = ST7789_WIDTH - 1;
    if (y1 >= ST7789_HEIGHT) y1 = ST7789_HEIGHT - 1;

    uint8_t caset[4] = { (uint8_t)(x0 >> 8), (uint8_t)(x0 & 0xFF), (uint8_t)(x1 >> 8), (uint8_t)(x1 & 0xFF) };
    uint8_t raset[4] = { (uint8_t)(y0 >> 8), (uint8_t)(y0 & 0xFF), (uint8_t)(y1 >> 8), (uint8_t)(y1 & 0xFF) };

    st7789_send_cmd(ST7789_CMD_CASET);
    st7789_send_data(caset, 4);

    st7789_send_cmd(ST7789_CMD_RASET);
    st7789_send_data(raset, 4);

    st7789_send_cmd(ST7789_CMD_RAMWR);
}

void st7789_draw_bitmap(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, const uint16_t *buffer)
{
    uint32_t len = (x1 - x0 + 1) * (y1 - y0 + 1);
    st7789_set_window(x0, y0, x1, y1);
    gpio_set_level(PIN_TFT_DC, 1);

    spi_transaction_t t;
    memset(&t, 0, sizeof(t));
    t.length = len * 16;
    t.tx_buffer = buffer;
    spi_device_polling_transmit(spi_dev, &t);
}

void st7789_fill_screen(uint16_t color)
{
    st7789_fill_rect(0, 0, ST7789_WIDTH, ST7789_HEIGHT, color);
}

void st7789_fill_rect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > ST7789_WIDTH) w = ST7789_WIDTH - x;
    if (y + h > ST7789_HEIGHT) h = ST7789_HEIGHT - y;
    if (w <= 0 || h <= 0) return;

    // Byte swap for big-endian display transmission
    uint16_t swapped_color = (color >> 8) | (color << 8);
    for (int i = 0; i < w; i++) {
        line_buffer[i] = swapped_color;
    }

    st7789_set_window(x, y, x + w - 1, y + h - 1);
    gpio_set_level(PIN_TFT_DC, 1);

    for (int line = 0; line < h; line++) {
        spi_transaction_t t;
        memset(&t, 0, sizeof(t));
        t.length = w * 16;
        t.tx_buffer = line_buffer;
        spi_device_polling_transmit(spi_dev, &t);
    }
}

void st7789_draw_pixel(int16_t x, int16_t y, uint16_t color)
{
    if (x < 0 || x >= ST7789_WIDTH || y < 0 || y >= ST7789_HEIGHT) return;
    uint16_t swapped = (color >> 8) | (color << 8);
    st7789_set_window(x, y, x, y);
    st7789_send_data((uint8_t*)&swapped, 2);
}

void st7789_sleep_enter(void)
{
    st7789_set_backlight(0);
    st7789_send_cmd(ST7789_CMD_DISPOFF);
    vTaskDelay(pdMS_TO_TICKS(20));
    st7789_send_cmd(ST7789_CMD_SLPIN);
    vTaskDelay(pdMS_TO_TICKS(120));
}

void st7789_sleep_exit(void)
{
    st7789_send_cmd(ST7789_CMD_SLPOUT);
    vTaskDelay(pdMS_TO_TICKS(120));
    st7789_send_cmd(ST7789_CMD_DISPON);
    vTaskDelay(pdMS_TO_TICKS(20));
    st7789_set_backlight(80);
}
