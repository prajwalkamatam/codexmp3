#ifndef ST7789_H
#define ST7789_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// Display Dimensions
#define ST7789_WIDTH   240
#define ST7789_HEIGHT  240

// Hardware Pinout Definitions
#define PIN_TFT_MISO   -1         // Unused for write-only TFT
#define PIN_TFT_MOSI   23         // VSPI MOSI
#define PIN_TFT_SCLK   18         // VSPI SCLK
#define PIN_TFT_CS     5          // ST7789 Chip Select (Active Low)
#define PIN_TFT_DC     21         // Data / Command Control
#define PIN_TFT_RST    22         // Hardware Reset
#define PIN_TFT_BL     4          // Backlight PWM via N-MOSFET

// Color Definitions (RGB565)
#define COLOR_BLACK       0x0000
#define COLOR_NAVY        0x000F
#define COLOR_DARKGREEN   0x03E0
#define COLOR_DARKCYAN    0x03EF
#define COLOR_MAROON      0x7800
#define COLOR_PURPLE      0x780F
#define COLOR_OLIVE       0x7BE0
#define COLOR_LIGHTGREY   0xC618
#define COLOR_DARKGREY    0x39E7
#define COLOR_BLUE        0x001F
#define COLOR_GREEN       0x07E0
#define COLOR_CYAN        0x07FF
#define COLOR_RED         0xF800
#define COLOR_MAGENTA     0xF81F
#define COLOR_YELLOW      0xFFE0
#define COLOR_WHITE       0xFFFF
#define COLOR_ORANGE      0xFD20
#define COLOR_GREENYELLOW 0xAFE5
#define COLOR_ACCENT_BLUE 0x247F
#define COLOR_BG_DARK     0x10A2

/**
 * @brief Initialize ST7789 display controller and SPI master bus.
 * @return ESP_OK on success.
 */
esp_err_t st7789_init(void);

/**
 * @brief Set display backlight brightness level (0 to 100%).
 * @param brightness Brightness percentage (0 = OFF, 100 = Full).
 */
void st7789_set_backlight(uint8_t brightness);

/**
 * @brief Set address drawing window on ST7789.
 * @param x0 Start X coordinate.
 * @param y0 Start Y coordinate.
 * @param x1 End X coordinate.
 * @param y1 End Y coordinate.
 */
void st7789_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);

/**
 * @brief Push a block of RGB565 pixels to the display via DMA.
 * @param x0 Start X coordinate.
 * @param y0 Start Y coordinate.
 * @param x1 End X coordinate.
 * @param y1 End Y coordinate.
 * @param buffer Pointer to RGB565 pixel buffer.
 */
void st7789_draw_bitmap(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, const uint16_t *buffer);

/**
 * @brief Fill the entire 240x240 screen with a single solid RGB565 color.
 * @param color RGB565 color value.
 */
void st7789_fill_screen(uint16_t color);

/**
 * @brief Draw a filled rectangle with specified RGB565 color.
 * @param x X origin.
 * @param y Y origin.
 * @param w Width.
 * @param h Height.
 * @param color RGB565 color.
 */
void st7789_fill_rect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);

/**
 * @brief Draw a single pixel.
 * @param x X coordinate.
 * @param y Y coordinate.
 * @param color RGB565 color.
 */
void st7789_draw_pixel(int16_t x, int16_t y, uint16_t color);

/**
 * @brief Put display controller into low-power sleep mode.
 */
void st7789_sleep_enter(void);

/**
 * @brief Wake display controller from sleep mode.
 */
void st7789_sleep_exit(void);

#ifdef __cplusplus
}
#endif

#endif // ST7789_H
