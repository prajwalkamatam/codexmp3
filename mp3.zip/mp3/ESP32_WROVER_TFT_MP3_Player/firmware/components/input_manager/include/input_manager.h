#ifndef INPUT_MANAGER_H
#define INPUT_MANAGER_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// Pin Assignments
#define PIN_I2C_SDA       32
#define PIN_I2C_SCL       33
#define PIN_IO_INT        35
#define PIN_BTN_PWR       36 // SENSOR_VP
#define PIN_BTN_PLAY      39 // SENSOR_VN

// TCA9534 I2C Address (A0=0, A1=0, A2=0)
#define TCA9534_I2C_ADDR  0x20

// Button ID
typedef enum {
    BTN_NONE = 0,
    BTN_POWER,
    BTN_PLAY_PAUSE,
    BTN_NEXT_TRACK,
    BTN_PREV_TRACK,
    BTN_VOL_UP,
    BTN_VOL_DOWN,
    BTN_MODE_SELECT
} button_id_t;

// Button Event Type
typedef enum {
    BTN_EVENT_PRESS,
    BTN_EVENT_RELEASE,
    BTN_EVENT_LONG_PRESS
} button_event_type_t;

typedef void (*button_callback_t)(button_id_t btn, button_event_type_t event);
typedef void (*headphone_callback_t)(bool plugged_in);
typedef void (*sd_card_detect_callback_t)(bool inserted);

/**
 * @brief Initialize TCA9534 I2C expander and GPIO button inputs.
 * @return ESP_OK on success.
 */
esp_err_t input_manager_init(void);

/**
 * @brief Register callback for button events.
 * @param cb Callback function.
 */
void input_manager_register_button_cb(button_callback_t cb);

/**
 * @brief Register callback for 3.5mm headphone jack insertion/removal events.
 * @param cb Callback function.
 */
void input_manager_register_hp_cb(headphone_callback_t cb);

/**
 * @brief Register callback for MicroSD card insertion/removal events.
 * @param cb Callback function.
 */
void input_manager_register_sd_cb(sd_card_detect_callback_t cb);

/**
 * @brief Check if headphones are currently inserted into the 3.5mm jack.
 * @return True if inserted.
 */
bool input_manager_is_headphone_inserted(void);

/**
 * @brief Check if MicroSD card is physically inserted into the socket.
 * @return True if inserted.
 */
bool input_manager_is_sd_card_inserted(void);

/**
 * @brief Check if battery charger is currently actively charging.
 * @return True if charging.
 */
bool input_manager_is_charging(void);

#ifdef __cplusplus
}
#endif

#endif // INPUT_MANAGER_H
