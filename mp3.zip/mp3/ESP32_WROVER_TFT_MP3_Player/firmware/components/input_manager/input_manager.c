#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/i2c.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "input_manager.h"

static const char *TAG = "INPUT_MGR";

#define I2C_MASTER_NUM              I2C_NUM_0
#define I2C_MASTER_FREQ_HZ          400000 // 400 kHz Fast-Mode
#define TCA9534_REG_INPUT           0x00
#define TCA9534_REG_OUTPUT          0x01
#define TCA9534_REG_POLARITY_INV    0x02
#define TCA9534_REG_CONFIG          0x03

static button_callback_t s_btn_callback = NULL;
static headphone_callback_t s_hp_callback = NULL;
static sd_card_detect_callback_t s_sd_callback = NULL;

static bool s_hp_inserted = false;
static bool s_sd_inserted = false;
static bool s_charging = false;

static esp_err_t tca9534_write_byte(uint8_t reg, uint8_t val)
{
    uint8_t write_buf[2] = {reg, val};
    return i2c_master_write_to_device(I2C_MASTER_NUM, TCA9534_I2C_ADDR, write_buf, 2, pdMS_TO_TICKS(50));
}

static esp_err_t tca9534_read_byte(uint8_t reg, uint8_t *val)
{
    return i2c_master_write_read_device(I2C_MASTER_NUM, TCA9534_I2C_ADDR, &reg, 1, val, 1, pdMS_TO_TICKS(50));
}

static void input_poll_task(void *arg)
{
    ESP_LOGI(TAG, "Input polling & debounce task started");
    uint8_t last_tca_state = 0xFF;
    int last_pwr = 1;
    int last_play = 1;

    while (1) {
        // 1. Read Native GPIO Buttons (Active Low)
        int pwr = gpio_get_level(PIN_BTN_PWR);
        int play = gpio_get_level(PIN_BTN_PLAY);

        if (pwr == 0 && last_pwr == 1) {
            ESP_LOGI(TAG, "Button: POWER Pressed");
            if (s_btn_callback) s_btn_callback(BTN_POWER, BTN_EVENT_PRESS);
        }
        last_pwr = pwr;

        if (play == 0 && last_play == 1) {
            ESP_LOGI(TAG, "Button: PLAY/PAUSE Pressed");
            if (s_btn_callback) s_btn_callback(BTN_PLAY_PAUSE, BTN_EVENT_PRESS);
        }
        last_play = play;

        // 2. Read TCA9534 Expander Ports
        uint8_t tca_in = 0xFF;
        if (tca9534_read_byte(TCA9534_REG_INPUT, &tca_in) == ESP_OK) {
            uint8_t changed = tca_in ^ last_tca_state;
            if (changed) {
                // P0: Next Track
                if ((changed & (1 << 0)) && !(tca_in & (1 << 0))) {
                    ESP_LOGI(TAG, "Button: NEXT TRACK Pressed");
                    if (s_btn_callback) s_btn_callback(BTN_NEXT_TRACK, BTN_EVENT_PRESS);
                }
                // P1: Prev Track
                if ((changed & (1 << 1)) && !(tca_in & (1 << 1))) {
                    ESP_LOGI(TAG, "Button: PREV TRACK Pressed");
                    if (s_btn_callback) s_btn_callback(BTN_PREV_TRACK, BTN_EVENT_PRESS);
                }
                // P2: Vol+
                if ((changed & (1 << 2)) && !(tca_in & (1 << 2))) {
                    ESP_LOGI(TAG, "Button: VOL UP Pressed");
                    if (s_btn_callback) s_btn_callback(BTN_VOL_UP, BTN_EVENT_PRESS);
                }
                // P3: Vol-
                if ((changed & (1 << 3)) && !(tca_in & (1 << 3))) {
                    ESP_LOGI(TAG, "Button: VOL DOWN Pressed");
                    if (s_btn_callback) s_btn_callback(BTN_VOL_DOWN, BTN_EVENT_PRESS);
                }
                // P4: Mode / BT
                if ((changed & (1 << 4)) && !(tca_in & (1 << 4))) {
                    ESP_LOGI(TAG, "Button: MODE / BT Pressed");
                    if (s_btn_callback) s_btn_callback(BTN_MODE_SELECT, BTN_EVENT_PRESS);
                }
                // P5: Charger Status
                s_charging = !(tca_in & (1 << 5));
                // P6: MicroSD Card Detect
                bool sd_now = !(tca_in & (1 << 6));
                if (sd_now != s_sd_inserted) {
                    s_sd_inserted = sd_now;
                    ESP_LOGI(TAG, "MicroSD Card %s", s_sd_inserted ? "INSERTED" : "REMOVED");
                    if (s_sd_callback) s_sd_callback(s_sd_inserted);
                }
                // P7: Headphone Jack Detect
                bool hp_now = !(tca_in & (1 << 7));
                if (hp_now != s_hp_inserted) {
                    s_hp_inserted = hp_now;
                    ESP_LOGI(TAG, "Headphones %s", s_hp_inserted ? "PLUGGED IN" : "UNPLUGGED");
                    if (s_hp_callback) s_hp_callback(s_hp_inserted);
                }
                last_tca_state = tca_in;
            }
        }

        vTaskDelay(pdMS_TO_TICKS(20)); // 50 Hz debounce polling
    }
}

esp_err_t input_manager_init(void)
{
    ESP_LOGI(TAG, "Initializing Input Manager & TCA9534 I2C Expander...");

    // 1. Configure Native Input-Only GPIO Buttons (GPIO36 & GPIO39)
    gpio_config_t btn_cfg = {
        .pin_bit_mask = (1ULL << PIN_BTN_PWR) | (1ULL << PIN_BTN_PLAY) | (1ULL << PIN_IO_INT),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&btn_cfg);

    // 2. Configure Master I2C Interface
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = PIN_I2C_SDA,
        .scl_io_num = PIN_I2C_SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ
    };
    esp_err_t ret = i2c_param_config(I2C_MASTER_NUM, &conf);
    if (ret != ESP_OK) return ret;

    ret = i2c_driver_install(I2C_MASTER_NUM, conf.mode, 0, 0, 0);
    if (ret != ESP_OK) return ret;

    // 3. Configure TCA9534: All 8 pins (P0-P7) set as inputs (0xFF)
    ret = tca9534_write_byte(TCA9534_REG_CONFIG, 0xFF);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "TCA9534 I2C write failed (Check device presence at 0x20)");
    } else {
        ESP_LOGI(TAG, "TCA9534 expander initialized (All 8 pins configured as input)");
    }

    // Launch Polling Task
    xTaskCreatePinnedToCore(input_poll_task, "input_poll", 3072, NULL, 4, NULL, 0);

    return ESP_OK;
}

void input_manager_register_button_cb(button_callback_t cb)
{
    s_btn_callback = cb;
}

void input_manager_register_hp_cb(headphone_callback_t cb)
{
    s_hp_callback = cb;
}

void input_manager_register_sd_cb(sd_card_detect_callback_t cb)
{
    s_sd_callback = cb;
}

bool input_manager_is_headphone_inserted(void)
{
    return s_hp_inserted;
}

bool input_manager_is_sd_card_inserted(void)
{
    return s_sd_inserted;
}

bool input_manager_is_charging(void)
{
    return s_charging;
}
