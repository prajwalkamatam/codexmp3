# ESP32-WROVER-E Smart MP3 Player Firmware

## Overview

This firmware is built using the official Espressif IoT Development Framework (**ESP-IDF v5.x / v4.4**). It implements a high-fidelity portable music player with:
- Dual-output audio engine:
  - Wired 3.5 mm stereo headphone jack via TI PCM5102A 32-bit I2S DAC and Maxim MAX97220A DirectDrive amplifier.
  - Wireless Bluetooth Classic A2DP stereo source streaming (SBC codec) to TWS earbuds and Bluetooth speakers.
- ST7789 1.3-inch 240×240 IPS TFT display driver with hardware SPI DMA and LEDC PWM backlight dimming.
- Polished multi-screen graphical user interface (Now Playing, Music Library, Bluetooth Devices, Wi-Fi Setup, Audio Output Selector, System Settings).
- MicroSD card storage mounting via SDSPI and recursive MP3 file indexing with ID3v2 metadata parsing.
- Hardware debounced tactile buttons (Power, Play/Pause, Next, Prev, Vol+, Vol-, Mode) interfaced via TCA9534 I2C expander and RTC wakeup pins.
- Battery fuel gauge voltage monitoring via ADC1 Channel 6 with Li-ion percentage estimation.

---

## Build & Flash Instructions

### 1. Prerequisites
Ensure the ESP-IDF environment is installed and sourced:
```bash
# Sourcing ESP-IDF environment (v4.4 or v5.x)
. $HOME/esp/esp-idf/export.sh
```

### 2. Configuration & Build
```bash
cd firmware
idf.py set-target esp32
idf.py build
```

### 3. Flashing & Serial Monitor
Connect the player via USB Type-C:
```bash
# Flash at 921600 baud and open interactive monitor
idf.py -p /dev/ttyUSB0 -b 921600 flash monitor
```

---

## Memory Allocation & Core Partitioning

```
Core 0 (System Core):
  - Wi-Fi Management Task (lwIP stack)
  - Bluetooth Classic A2DP Source Task (Bluedroid / SBC encoder)
  - MicroSD FAT32 File Streaming
  - TCA9534 I2C Expander & Button Event Handling Task

Core 1 (Application & Media Core):
  - ST7789 Graphic Rendering Engine (30 FPS)
  - MP3 Algorithmic Decoding Task
  - I2S Audio FIFO Streaming (Ring buffer in PSRAM)
  - Digital Volume Scaling & Anti-Pop Sequencer
```
