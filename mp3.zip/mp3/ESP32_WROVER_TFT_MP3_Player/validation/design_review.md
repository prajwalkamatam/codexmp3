# ESP32-WROVER-E Smart MP3 Player — Multidisciplinary Design Review

## 1. Executive Engineering Summary

This design review summarizes the multidisciplinary verification performed on the **ESP32-WROVER-E Smart MP3 Player (Rev 1.0)**. The design integrates an Espressif ESP32-WROVER-E module (8 MB PSRAM, 16 MB Flash), a 1.3-inch 240×240 IPS ST7789 TFT display, MicroSD FAT32 storage, TI PCM5102A 32-bit I2S DAC, Maxim MAX97220A DirectDrive headphone amplifier, Bluetooth Classic A2DP stereo source streaming, USB-C power-path battery management, and 7 ergonomic tactile buttons.

---

## 2. Subsystem Engineering Reviews

### 2.1 Embedded Systems & Microcontroller Review
- **Module Variant**: Verified as ESP32-WROVER-E-N16R8.
- **PSRAM Bus Protection**: Pins GPIO16 and GPIO17 are completely omitted from external routing, protecting the internal high-speed 80 MHz memory bus.
- **Strapping Pin Verification**:
  - `GPIO0`: Fitted with 10 kΩ pull-up to 3.3 V and connected to auto-programming dual-transistor circuit. Default state = SPI flash boot.
  - `GPIO12 (MTDI)`: Kept pulled down via 10 kΩ resistor. Guarantees 3.3 V VDD_SDIO flash voltage at boot.
  - `GPIO2`: Pulled LOW via 10 kΩ resistor. Prevents spurious download mode hangs.
  - `GPIO15`: Pulled HIGH via 10 kΩ resistor. ROM boot messages enabled.
- **Input-Only Pins (GPI 34–39)**: All input-only pins (GPIO34, 35, 36, 39) have external 10 kΩ pull-ups or precision divider biasing.
- **ADC Conflict Mitigation**: Battery voltage sensing is mapped to ADC1 Channel 6 (GPIO34), avoiding ADC2 which is disabled during Wi-Fi / Bluetooth transmissions.

### 2.2 Audio Electronics Review
- **DAC Clocking & Architecture**: TI PCM5102A operates using its integrated PLL to generate internal master clock (SCK) directly from bit clock (BCK). Removes high-frequency 12.288 MHz clock traces from PCB.
- **Amplifier Topology**: MAX97220A DirectDrive creates an internal negative supply rail, eliminating large DC-blocking capacitors on headphone outputs. Headphone jack sleeve connects directly to system analog ground (AGND).
- **Anti-Pop Hardware Sequencing**: GPIO14 (`AMP_MUTE`) keeps the MAX97220A shutdown input LOW during power-up until I2S clocks stabilize, eliminating startup and shutdown clicks.
- **Noise Isolation**: Dedicated analog ground island (AGND) tied to digital ground at a single star point beneath the headphone jack; analog 3.3 V supply rail filtered through a 600 Ω @ 100 MHz ferrite bead (FB1) and ceramic bypass capacitors.

### 2.3 Power Electronics & Battery Management Review
- **USB-C Upstream Facing Port (UFP)**: Dual independent 5.1 kΩ 1% pull-down resistors on CC1 and CC2 guarantee full compatibility with USB-C chargers and E-marked cables.
- **Dynamic Power-Path (Load Sharing)**: P-channel MOSFET (AO3401A) and Schottky diode (MBR0520) isolate the Li-ion battery from system load when USB 5 V is plugged in, allowing simultaneous playback and charging while preserving TP4056 charge termination accuracy.
- **Battery Protection**: Onboard DW01A protection IC and FS8205A dual N-channel MOSFET provide hardware cutoffs for over-charge (4.3 V), over-discharge (2.4 V), and short circuits (>3 A).
- **System LDO**: AP2112K-3.3 delivers up to 1.0 A peak with 250 mV dropout, enabling battery discharge down to 3.55 V under load before dropout occurs.

### 2.4 Radio Frequency (RF) & Antenna Clearance Review
- **Antenna Region**: ESP32 inverted-F PCB antenna is positioned along the top edge of the board.
- **Keep-Out Enforcement**: All copper (signal, power, and ground) on all four layers is cleared for an area of 18.0 mm × 6.5 mm beneath and around the antenna. No metal mounting screws or battery brackets are placed within 15 mm of the antenna.

### 2.5 PCB Layout & Mechanical Review
- **Form Factor**: 55.00 mm × 85.00 mm with 3.0 mm rounded corners (credit card dimensions).
- **Stack-up**: 4-Layer (F.Cu signal, In1.Cu continuous GND, In2.Cu split power planes, B.Cu signal).
- **Component Placement**:
  - Front: 1.3-inch ST7789 IPS TFT display centered in upper half; 7 ergonomic buttons arranged below display.
  - Bottom Edge: USB-C receptacle, 3.5 mm headphone jack, and MicroSD push-push socket easily accessible.
  - Mounting: 4x M2.5 mounting holes with 5.0 mm annular ring clearances.

---

## 3. Residual Engineering Risks & Mitigations

| Risk Identified | Severity | Mitigation Implemented | Verification Method |
|---|---|---|---|
| **RF Noise on Audio Rail** | Medium | Ferrite bead $\pi$-filter on AVDD_3V3; dedicated AGND island | Audio SNR measurement during active Wi-Fi transmission |
| **MicroSD SPI Contention with TFT** | Low | Independent chip selects (TFT_CS GPIO5, SD_CS GPIO13) | DMA buffer transfers synchronized to display VSYNC |
| **High Ambient In-Rush on USB-C Plug-in** | Low | 10 µF input ceramic cap + TVS clamp diode array (USBLC6-2SC6) | 5 V plug-in transient capture with oscilloscope |
| **Battery Over-Discharge during Storage** | Low | Deep sleep mode draws <120 µA; DW01A cutoff at 2.4 V | Quiescent current measurement in sleep mode |
