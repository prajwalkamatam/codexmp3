# ESP32-WROVER-E Smart MP3 Player — Complete Engineering Project

## 1. Project Overview

This repository contains the complete, production-ready hardware, PCB, firmware, and manufacturing package for the **ESP32-WROVER-E Smart MP3 Player**.

Designed as a high-fidelity portable handheld audio player, the system features:
- **Main MCU**: Espressif ESP32-WROVER-E with **8 MB PSRAM** and **16 MB SPI Flash**.
- **Display**: 1.3-inch 240×240 IPS Color TFT display with Sitronix ST7789 controller over high-speed 40 MHz SPI with DMA and hardware LEDC PWM backlight dimming.
- **Dual Audio Output**:
  1. **Wired 3.5 mm Stereo Jack**: TI PCM5102A 32-bit I2S DAC (integrated PLL, 112 dB SNR) + Maxim MAX97220A DirectDrive ground-referenced 125 mW headphone amplifier with active anti-pop muting.
  2. **Wireless Bluetooth A2DP**: Bluetooth Classic A2DP stereo source streaming (SBC codec) to commercial TWS wireless earbuds and Bluetooth speakers.
- **Local Storage**: MicroSD card push-push socket supporting FAT32 filesystem and ID3v2 metadata parsing.
- **USB-C Connectivity**: USB Type-C receptacle with separate 5.1 kΩ pull-downs on CC1/CC2, USBLC6-2SC6 TVS ESD protection, and Silicon Labs CP2102N USB-UART bridge with automatic DTR/RTS bootloader programming.
- **Battery Management & Power-Path**: Single-cell Li-ion/LiPo charging via TP4056 (500 mA) with automatic P-channel MOSFET (AO3401A) load-sharing power-path and DW01A/FS8205A battery protection.
- **System Power**: AP2112K-3.3 1.0 A ultra-low dropout regulator with ferrite-bead isolated analog audio rail (AVDD_3V3).
- **User Interface**: 7 ergonomic tactile pushbuttons (Power/Wake, Play/Pause, Next Track, Prev Track, Vol+, Vol-, Mode) interfaced through a Texas Instruments TCA9534 I2C I/O expander and RTC wakeup pins.
- **PCB**: Compact 4-layer 55.0 mm × 85.0 mm board with continuous ground plane, split power planes, and dedicated antenna keep-out.

```
+---------------------------------------------------------------------------------------------------+
|                                        USB TYPE-C RECEPTACLE                                      |
|                               (VBUS 5.0 V, CC1/CC2 5.1 k pull-downs, D+/D-)                       |
+-------------------------------------------------+-------------------------------------------------+
                                                  |
                         +------------------------+------------------------+
                         |                                                 |
                         v                                                 v
           +---------------------------+                     +---------------------------+
           |   USBLC6-2SC6 TVS ESD     |                     |    TP4056 CHARGER &       |
           |     PROTECTION ARRAY      |                     |    AO3401A LOAD-SHARING   |
           +-------------+-------------+                     +-------------+-------------+
                         |                                                 |
                         v                                                 v
           +---------------------------+                     +---------------------------+
           |     CP2102N USB-UART      |                     |   SINGLE-CELL Li-ion/LiPo |
           |  (Integrated LDO & Clocks)|                     |   (3.7 V Nom, DW01A Prot) |
           +-------------+-------------+                     +-------------+-------------+
                         |                                                 |
                         | (TXD/RXD, DTR/RTS)                              v
                         |                                   +---------------------------+
                         v                                   |     V_SYS POWER RAIL      |
           +---------------------------+                     |       (3.3 V - 5.0 V)     |
           |    AUTO-RESET TRANSISTORS |                     +-------------+-------------+
           |    (UMH3N Dual NPN BJT)   |                                   |
           +-------------+-------------+                                   v
                         |                                   +---------------------------+
                         | (EN, GPIO0)                       |   AP2112K-3.3 1.0 A LDO   |
                         |                                   |    (Low Dropout, PSRR)    |
                         |                                   +-------------+-------------+
                         |                                                 |
                         +------------------------+------------------------+
                                                  |
                                                  v (VDD_3V3 System Rail)
+---------------------------------------------------------------------------------------------------+
|                                     ESP32-WROVER-E MODULE                                         |
|                                (Xtensa Dual-Core LX6 @ 240 MHz)                                   |
|                                (8 MB SPI Flash + 8 MB PSRAM)                                      |
|                                                                                                   |
|  [ADC1 Channels]          [VSPI Bus]                  [I2S0 Bus]              [I2C0 Bus]          |
|  - GPIO34: BATT_SENSE     - GPIO18: SCLK (Shared)     - GPIO25: WS / LRCK     - GPIO32: SDA       |
|  - GPIO35: IO_INT         - GPIO23: MOSI (Shared)     - GPIO26: BCK           - GPIO33: SCL       |
|  - GPIO36: BTN_PWR        - GPIO19: MISO (SD only)    - GPIO27: DATA          (4.7 k pull-ups)    |
|  - GPIO39: BTN_PLAY       - GPIO5:  TFT_CS            - GPIO14: AMP_MUTE                          |
|                           - GPIO13: SD_CS                                                         |
|                           - GPIO21: TFT_DC                                                        |
|                           - GPIO22: TFT_RST                                                       |
|                           - GPIO4:  TFT_BL (PWM)                                                  |
+------------+--------------------+-------------------------+--------------------+------------------+
             |                    |                         |                    |
             v                    v                         v                    v
     +---------------+    +---------------+         +---------------+    +---------------+
     |  1.3" IPS TFT |    |    MicroSD    |         | PCM5102A DAC  |    | TCA9534 I/O   |
     |  ST7789V SPI  |    |  PUSH-PUSH    |         | (Integrated   |    |   EXPANDER    |
     |   240 x 240   |    |    SOCKET     |         |  PLL, 112 dB) |    +-------+-------+
     +---------------+    +---------------+         +-------+-------+            |
                                                            |                    +-- P0: SW_NEXT
                                                            v                    +-- P1: SW_PREV
                                                    +---------------+            +-- P2: SW_VOLUP
                                                    |   MAX97220A   |            +-- P3: SW_VOLDN
                                                    | HEADPHONE AMP |            +-- P4: SW_MODE
                                                    | (DirectDrive) |            +-- P5: CHG_STAT
                                                    +-------+-------+            +-- P6: SD_CD
                                                            |                    +-- P7: HP_DET
                                                            v
                                                    +---------------+
                                                    |  3.5 mm AUDIO |
                                                    |  STEREO JACK  |
                                                    +---------------+
```

---

## 2. Hardware Specifications

| Specification | Implementation Details |
|---|---|
| **MCU** | Espressif ESP32-WROVER-E-N16R8 (Dual-Core Xtensa LX6 @ 240 MHz) |
| **Memory** | 8 MB PSRAM (80 MHz memory bus), 16 MB QSPI Flash |
| **Display** | 1.3-inch 240 × 240 IPS TFT (ST7789V controller, 4-wire SPI @ 40 MHz) |
| **Storage** | MicroSD card push-push socket (SPI mode, FAT32 mount) |
| **Wired Audio** | TI PCM5102A 32-bit DAC + Maxim MAX97220A DirectDrive 125 mW headphone amp |
| **Wireless Audio** | Bluetooth Classic v4.2 BR/EDR A2DP Stereo Source (SBC codec) |
| **Wi-Fi** | 802.11 b/g/n (2.4 GHz) station mode |
| **USB Interface** | USB Type-C 2.0 with separate 5.1 kΩ CC pull-downs & USBLC6-2SC6 ESD protection |
| **UART Programming** | Silicon Labs CP2102N with dual NPN transistor auto-download reset circuit |
| **Battery Charger** | TP4056 500 mA linear charger + AO3401A / MBR0520 load-sharing power-path |
| **Battery Protection** | DW01A protection IC + FS8205A dual N-MOSFET (Over-charge, over-discharge, short-circuit) |
| **System LDO** | AP2112K-3.3 (1.0 A peak, 250 mV dropout, 65 dB PSRR) |
| **Controls** | 7 Tactile buttons (Power, Play/Pause, Next, Prev, Vol+, Vol-, Mode) |
| **I/O Expander** | Texas Instruments TCA9534PWR 8-bit I2C expander with interrupt |
| **PCB Form Factor** | 55.00 mm × 85.00 mm, 4 Layers (1.6 mm thickness, ENIG surface finish) |

---

## 3. Master GPIO Allocation

| GPIO Pin | Function | Electrical Biasing | Subsystem Connection |
|---|---|---|---|
| **GPIO0** | `BOOT_SW` / Strap | Pull-up 10 kΩ | Auto-programming BJT Q4 & Manual BOOT button |
| **GPIO1** | `UART0_TXD` | High | ESP32 serial console TX to CP2102N RXD |
| **GPIO2** | Boot Strap | Pull-down 10 kΩ | Strapping pin (must be low for download) |
| **GPIO3** | `UART0_RXD` | High | ESP32 serial console RX from CP2102N TXD |
| **GPIO4** | `TFT_BL` | Pull-down 10 kΩ | ST7789 Backlight PWM via BSS138 N-MOSFET |
| **GPIO5** | `TFT_CS` | Pull-up 10 kΩ | ST7789 SPI Chip Select (Active Low) |
| **GPIO6–11** | `SPI_FLASH` | Internal | Dedicated to internal 16 MB SPI Flash |
| **GPIO12** | `MTDI` Strap | Pull-down 10 kΩ | Strapping pin: Flash voltage (must remain 0 at reset) |
| **GPIO13** | `SD_CS` | Pull-up 10 kΩ | MicroSD Card SPI Chip Select (Active Low) |
| **GPIO14** | `AMP_MUTE` | Pull-down 100 kΩ | MAX97220A Shutdown / Anti-Pop Mute (Active High EN) |
| **GPIO15** | `MTDO` Strap | Pull-up 10 kΩ | Boot logging enable strap |
| **GPIO16–17** | `PSRAM` | Internal | Dedicated to internal 8 MB PSRAM bus |
| **GPIO18** | `SPI_SCK` | Output | Master SPI Clock (Shared ST7789 TFT & MicroSD) |
| **GPIO19** | `SPI_MISO` | Pull-up 10 kΩ | Master SPI MISO (MicroSD data in) |
| **GPIO21** | `TFT_DC` | Output | ST7789 Data / Command select line |
| **GPIO22** | `TFT_RST` | Pull-up 10 kΩ | ST7789 Hardware Reset line |
| **GPIO23** | `SPI_MOSI` | Output | Master SPI MOSI (Shared ST7789 TFT & MicroSD) |
| **GPIO25** | `I2S_WS` | Output | I2S Word Select / Left-Right Clock to PCM5102A |
| **GPIO26** | `I2S_BCK` | Output | I2S Bit Clock to PCM5102A (Feeds internal PLL) |
| **GPIO27** | `I2S_DATA` | Output | I2S Serial Audio Data to PCM5102A DIN |
| **GPIO32** | `I2C_SDA` | Pull-up 4.7 kΩ | I2C Data bus for TCA9534 I/O Expander |
| **GPIO33** | `I2C_SCL` | Pull-up 4.7 kΩ | I2C Clock bus for TCA9534 I/O Expander |
| **GPIO34** | `BATT_SENSE` | Analog Input | ADC1 Channel 6: 100k/100k battery divider with 100nF cap |
| **GPIO35** | `IO_INT` | Pull-up 10 kΩ | Active-low interrupt from TCA9534 Expander |
| **GPIO36** | `BTN_PWR` | Pull-up 10 kΩ | Power button / RTC Deep Sleep Wakeup (ext0) |
| **GPIO39** | `BTN_PLAY` | Pull-up 10 kΩ | Play / Pause button input |

---

## 4. Directory Structure

```text
ESP32_WROVER_TFT_MP3_Player/
│
├── hardware/
│   ├── ESP32_WROVER_TFT_MP3_Player.kicad_pro    # KiCad 7/8 Project file
│   ├── ESP32_WROVER_TFT_MP3_Player.kicad_sch    # Complete native KiCad schematic
│   ├── ESP32_WROVER_TFT_MP3_Player.kicad_pcb    # Complete 4-layer routed KiCad PCB
│   ├── libraries/                               # KiCad symbols and footprints
│   └── 3d_models/                              # 3D models directory
│
├── firmware/
│   ├── CMakeLists.txt                          # Top-level ESP-IDF CMakeLists
│   ├── sdkconfig.defaults                      # Target, PSRAM, BT, Clock configuration
│   ├── README.md                               # Firmware architecture documentation
│   ├── main/
│   │   ├── CMakeLists.txt
│   │   └── main.c                              # Main application entry point
│   └── components/
│       ├── audio_player/                       # I2S driver, volume, muting & streaming
│       ├── bluetooth_a2dp/                     # Bluedroid A2DP source & discovery
│       ├── display_st7789/                     # ST7789 SPI DMA & PWM backlight driver
│       ├── ui/                                 # 240x240 color graphical user interface
│       ├── storage/                            # SDSPI driver & FAT32 file indexer
│       ├── input_manager/                      # TCA9534 expander & button debounce
│       ├── power_manager/                      # ADC fuel gauge & deep sleep controller
│       └── wifi_manager/                       # Wi-Fi station mode & scanning
│
├── manufacturing/
│   ├── gerbers/                                # RS-274X Gerber production files (9 layers)
│   ├── drill_files/                            # Excellon drill files (.drl)
│   ├── BOM.csv                                 # Production Bill of Materials with LCSC part #s
│   ├── CPL.csv                                 # Centroid Pick and Place file for automated SMT
│   └── assembly_notes.md                       # Fabrication notes for JLCPCB / PCBWay
│
├── validation/
│   ├── ERC_report.txt                          # Electrical Rules Check report
│   ├── DRC_report.txt                          # Design Rules Check report
│   ├── firmware_build_report.txt               # Memory usage & compilation report
│   └── design_review.md                        # Multidisciplinary engineering review
│
└── documentation/
    ├── architecture.md                         # Detailed system block diagram & architecture
    ├── gpio_mapping.md                         # Complete GPIO allocation & constraints
    ├── component_selection.md                  # Sourcing, datasheets & part justifications
    ├── power_design.md                         # Power budget, load sharing & runtime analysis
    ├── audio_design.md                         # DAC PLL, reconstruction filter & headphone amp
    ├── display_design.md                       # ST7789 timing, DMA buffers & backlight
    ├── schematic_explanation.md                # Comprehensive circuit walkthrough
    ├── assembly_guide.md                       # Step-by-step soldering & inspection guide
    └── testing_guide.md                        # Progressive bring-up test procedure
```

---

## 5. Fabrication & Assembly Quick-Start

1. **PCB Fabrication**:
   - Upload the ZIP of `manufacturing/gerbers/` and `manufacturing/drill_files/` to JLCPCB or PCBWay.
   - Choose: 4 Layers, 1.6 mm thickness, ENIG surface finish, Matte Black or Green solder mask.
2. **SMT Assembly**:
   - Provide `manufacturing/BOM.csv` and `manufacturing/CPL.csv` for automated pick-and-place assembly.
3. **Flashing Firmware**:
   - Connect the board via USB-C to a host computer.
   - Run:
     ```bash
     cd firmware
     idf.py set-target esp32
     idf.py build
     idf.py -p /dev/ttyUSB0 -b 921600 flash monitor
     ```
