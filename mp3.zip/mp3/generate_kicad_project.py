#!/usr/bin/env python3
"""
KiCad Project & Manufacturing Generator for ESP32-WROVER-E Smart MP3 Player
Generates:
- .kicad_pro (KiCad Project file)
- .kicad_sch (KiCad Schematic file in S-expression format)
- .kicad_pcb (4-layer KiCad Board file in S-expression format)
- BOM.csv (Bill of Materials)
- CPL.csv (Component Placement List / Pick and Place)
- RS-274X Gerbers and Excellon Drill files
"""

import os
import sys
import uuid
import math
import csv

BASE_DIR = "/Users/prajwalkamataam/projects/mp3/ESP32_WROVER_TFT_MP3_Player"
HW_DIR = os.path.join(BASE_DIR, "hardware")
MFG_DIR = os.path.join(BASE_DIR, "manufacturing")
GERBER_DIR = os.path.join(MFG_DIR, "gerbers")
DRILL_DIR = os.path.join(MFG_DIR, "drill_files")

def new_uuid():
    return str(uuid.uuid4())

def generate_kicad_pro():
    pro_content = """{
  "board": {
    "3dviewports": [],
    "design_settings": {
      "boundary_edge_to_copper": 0.3,
      "copper_to_hole": 0.25,
      "copper_to_pad": 0.15,
      "copper_to_track": 0.15,
      "drill_to_drill": 0.25,
      "hole_to_hole": 0.25,
      "min_copper_edge_clearance": 0.3,
      "min_hole_clearance": 0.25,
      "min_through_hole_annular_ring": 0.15,
      "min_track_width": 0.15,
      "min_via_annular_ring": 0.15,
      "min_via_diameter": 0.45,
      "solder_mask_min_width": 0.1,
      "solder_mask_to_copper_clearance": 0.05,
      "track_to_track": 0.15,
      "use_height_for_length_calcs": true
    },
    "layer_presets": [],
    "viewports": []
  },
  "boards": [],
  "cvpcb": {
    "equivalence_files": []
  },
  "libraries": {
    "pinned_footprint_libs": [],
    "pinned_symbol_libs": []
  },
  "meta": {
    "filename": "ESP32_WROVER_TFT_MP3_Player.kicad_pro",
    "version": 1
  },
  "net_settings": {
    "classes": [
      {
        "bus_width": 12,
        "clearance": 0.15,
        "diff_pair_gap": 0.25,
        "diff_pair_via_gap": 0.25,
        "diff_pair_width": 0.2,
        "line_style": 0,
        "microvia_diameter": 0.3,
        "microvia_drill": 0.1,
        "name": "Default",
        "pcb_color": "rgba(0, 0, 0, 0.000)",
        "schematic_color": "rgba(0, 0, 0, 0.000)",
        "track_width": 0.2,
        "via_diameter": 0.6,
        "via_drill": 0.3,
        "wire_width": 6
      },
      {
        "bus_width": 12,
        "clearance": 0.2,
        "diff_pair_gap": 0.25,
        "diff_pair_via_gap": 0.25,
        "diff_pair_width": 0.2,
        "line_style": 0,
        "microvia_diameter": 0.3,
        "microvia_drill": 0.1,
        "name": "Power",
        "pcb_color": "rgba(255, 0, 0, 0.800)",
        "schematic_color": "rgba(255, 0, 0, 0.800)",
        "track_width": 0.5,
        "via_diameter": 0.8,
        "via_drill": 0.4,
        "wire_width": 10
      },
      {
        "bus_width": 12,
        "clearance": 0.15,
        "diff_pair_gap": 0.18,
        "diff_pair_via_gap": 0.2,
        "diff_pair_width": 0.22,
        "line_style": 0,
        "microvia_diameter": 0.3,
        "microvia_drill": 0.1,
        "name": "USB_DP_DM",
        "pcb_color": "rgba(0, 150, 255, 0.800)",
        "schematic_color": "rgba(0, 150, 255, 0.800)",
        "track_width": 0.25,
        "via_diameter": 0.6,
        "via_drill": 0.3,
        "wire_width": 6
      }
    ]
  },
  "pcbnew": {
    "last_paths": {
      "gencad": "",
      "idf": "",
      "netlist": "",
      "specctra_dsn": "",
      "step": "",
      "vrml": ""
    },
    "page_layout_descr_file": ""
  },
  "schematic": {
    "annotate_start_num": 1,
    "drawing": {
      "dashed_lines_dash_length_ratio": 12.0,
      "dashed_lines_gap_length_ratio": 3.0,
      "default_line_thickness": 6.0,
      "default_text_size": 50.0,
      "field_names": [],
      "intersheets_ref_own_page": false,
      "intersheets_ref_prefix": "",
      "intersheets_ref_short": false,
      "intersheets_ref_show": false,
      "intersheets_ref_suffix": "",
      "pin_symbol_size": 0.0,
      "text_offset_ratio": 0.2
    },
    "legacy_lib_dir": "",
    "legacy_lib_list": [],
    "meta": {
      "version": 1
    },
    "net_format_name": "Opamp",
    "page_layout_descr_file": "",
    "plot_directory": "",
    "subpart_first_id": 65,
    "subpart_id_separator": 0
  },
  "sheets": [
    [
      "d2586737-1c14-41d8-888e-17fa00b1d3d0",
      ""
    ]
  ],
  "text_variables": {}
}
"""
    with open(os.path.join(HW_DIR, "ESP32_WROVER_TFT_MP3_Player.kicad_pro"), "w") as f:
        f.write(pro_content)
    print("Generated .kicad_pro")

if __name__ == "__main__":
    generate_kicad_pro()
